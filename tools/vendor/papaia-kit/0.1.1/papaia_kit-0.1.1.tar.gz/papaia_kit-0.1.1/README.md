# papaia-kit

Shared contract package of the papaia platform. Every module, add-on and server
reads the contract from here instead of keeping its own copy: schemas, readers
and writers for the shared formats, the license policy and the conformance
checks that run in each repository's CI.

The kit is a library. It runs no service of its own.

## Layout

| Path | Content |
|---|---|
| `schemas/` | Contract schemas (JSON Schema 2020-12), see `schemas/README.md` |
| `policy/` | License policy shared by all repositories |
| `py/papaia_kit/` | Python package `papaia-kit` |
| `js/` | TypeScript package `@papaia/kit` for user interfaces |
| `contract/` | Normative prose accompanying the schemas |
| `glossary/` | Glossary binding for user-facing texts |
| `tokens/` | Design tokens |
| `testing/` | Test doubles, fixtures and shared test vectors (`testing/vectors/`) |
| `probe-addon/` | Minimal example add-on proving the contract end to end |

Python subpackages: `catalog`, `exchange`, `authz`, `audit`, `erasure`,
`errors`, `assertion`, `conformance`, `names`, `ui`, plus `licenses` and `repo`
for the repository checks below.

`papaia_kit.data_classes` reads the one data class scale
(`schemas/data-classes.json`) and compares classes by their order; see
`contract/data-classes.md`.

## Audit format and correlation id

Every write, send or delete produces one `papaia.audit/1` event that carries the
request's correlation id. The format is `schemas/audit.v1.schema.json`, the rules
are in `contract/audit.md`:

```python
from papaia_kit.audit import validate_event
from papaia_kit.correlation import correlation_headers, correlation_id_from_headers

correlation_id = correlation_id_from_headers(request.headers)  # keeps or replaces
outgoing = correlation_headers(correlation_id)  # for every follow-up call
validate_event(event)  # raises AuditEventError naming fields, never values
```

## Audit writer

`papaia_kit.audit.writer.AuditWriter` writes each event into the source's
outbox table `audit_outbox`, in the caller's own transaction, and a delivery
loop sends the outbox in order to `papaia-audit` over mutual TLS. Rows are
deleted only after `papaia-audit` acknowledged them. There is no read route:
events are read only from `papaia-audit`. Details and the ingest format are in
`contract/audit.md` ("Writer and ingest").

```python
import threading
from papaia_kit.audit.transport import HttpsIngestTransport
from papaia_kit.audit.writer import AuditWriter

transport = HttpsIngestTransport(
    cert_file="/run/secrets/audit-client.crt",  # client certificate of the platform PKI
    key_file="/run/secrets/audit-client.key",
    ca_file="/run/secrets/platform-ca.crt",
)  # https://papaia-audit:8443/v1/ingest by default; http:// is refused
writer = AuditWriter(pool.connection, transport, dialect="postgres")
writer.ensure_schema()  # or run papaia_kit.audit.outbox.outbox_ddl("postgres") in a migration

with pool.connection() as conn:  # the transaction of the effect
    apply_the_change(conn)
    writer.write(conn, event)  # same transaction; returns source_seq

stop = threading.Event()
threading.Thread(target=writer.run, args=(stop,), daemon=True).start()
```

For asyncio applications (FastAPI) use `AsyncAuditWriter` with an async
connection (psycopg `AsyncConnection`, aiosqlite) and
`ThreadedIngestTransport(transport)`; start `writer.run(stop)` as a task in the
lifespan handler and set `stop` on shutdown.

A source without a database of its own (an MCP server in front of a remote
service) keeps the outbox in a SQLite file on a persistent volume and writes
each row in a transaction of its own, right after the remote call returns:

```python
from papaia_kit.audit.writer import FileAuditWriter

writer = FileAuditWriter("/var/lib/mcp-paperless/audit/outbox.sqlite3", transport)
principal = chain.check(token, request)
result = call_the_remote_service()
writer.record({**row_of_the_operation, **principal.audit_fields()})  # committed on return
```

`principal.audit_fields()` adds the token times `token_iat`,
`token_auth_time` and `token_remaining_s` to the server's row, never the
token. An asyncio server calls `record` through `asyncio.to_thread`.

The `postgres` dialect works with psycopg 3 (sync and async) and psycopg2;
`sqlite` with `sqlite3` and aiosqlite. `write` locks the source's counter row
until the caller's transaction ends, so keep transactions that write audit
rows short.

## Development

Requirements: [uv](https://docs.astral.sh/uv/) and Node.js 22 or later.

```sh
make bootstrap   # uv sync --locked, npm ci
make lint        # ruff, mypy, yamllint, shellcheck, typecheck, wording, licenses
make test        # pytest
make release TAG=vX.Y.Z REGISTRY=/abs/path   # see "Building a release"
```

## Erasure journal

`papaia_kit.erasure` is the only writer of the erasure journal. Each module with
personal data keeps one journal so that deletions survive a restore.

```python
from papaia_kit.erasure import ErasureJournal, ErasureKey, Kind

journal = ErasureJournal(
    "assist",
    key=ErasureKey.from_file(Path("/run/secrets/erasure-hmac")),
    target_dir=Path("/backup/erasure-journal"),  # <backup target>/erasure-journal
    local_dir=Path("/var/lib/papaia-erasure"),  # volume papaia-erasure, backup: exclude
    mirror_dir=None,  # optional --erasure-mirror
)

with db.transaction() as tx:
    entry = journal.record(Kind.ERASE, object_ref="memory:41", sub=sub, reason="user_request")
    tx.delete_memory(41)
    tx.set_applied_erasure_seq(entry.seq)
```

### Format and key

- One JSON line per entry in `<module>.jsonl`: `id`, `module`, `seq` (gap-free
  per module), `kind`, `object_ref`,
  `subject_ref`, `at` (UTC), `reason`, and `provisional_seq` only on a
  renumbered entry (below). Schema: `schemas/erasure-journal-entry.v1.schema.json`.
  Readers refuse unknown fields, duplicate JSON keys and malformed lines.
- `kind` per journal (`kinds_for(module)`; readers refuse any other kind):
  module journals hold `erase`, `erase_subject`, `delivery` and `revoke` (a
  delegation revoked at its holder; `erasure-replay` revokes it again). The core
  sources use the same format: `identity` holds `account_disable`,
  `account_delete`, `role_revoke`, `session_revoke` and `credential_reset`;
  `core-chat` holds `erase` and `erase_subject`; `model-gateway` holds those two
  and `key_revoke` (the key id, never the key value).
- `subject_ref` is `HMAC-SHA256(erasure-hmac, sub)`; the journal never holds the
  `sub` or the key. `ErasureKey.matches(sub, subject_ref)` resolves a reference
  only with the key.
- The key file `erasure-hmac` holds the key as hexadecimal text: 64 to 2048
  digits (32 to 1024 bytes), optionally followed by one line break. Generate it
  with `openssl rand -hex 32`. Raw binary content is refused, so every component
  that reads the key computes the same `subject_ref`.
- `object_ref` and `reason` are identifiers and short codes; spaces and free
  text are refused so that no content reaches the journal.

### Caller contract

- Call `record` in the same transaction as the deletion, before it commits, and
  store the returned `entry.seq` as the module's applied erasure seq in that
  transaction. Without it the module sits behind its own journal after the first
  deletion, and the start check and `doctor state_epoch` report it as older than
  the journal.
- If `record` raises, the deletion must not go ahead: the local copy is missing,
  not writable or damaged.
- If the deletion rolls back after `record` returned, the entry stays in the
  journal. It is not removed: a replay later deletes the object, which is safe
  because the person asked for the deletion. Retry the deletion; it writes a new
  entry.
- `record` writes no audit row. The caller writes the `papaia.audit/1` row of
  the deletion. `StartGate` and `LifecycleHandler` (below) hand their rows to
  the sink the caller passes.

### Places and backlog

- The backup target assigns the final `seq`. If the target is unreachable,
  read-only or holds a damaged file, the deletion goes ahead: the entry stays in
  the local copy with a provisional `seq` (the highest number the local copy and
  a reachable mirror know, plus one) and the next `record` or `flush()` delivers
  it. `status().ok` stays false until then.
- Delivery compares entries by `id`, never by `seq` alone. If the target already
  holds the provisional number for another entry (the local copy came from the
  same VM backup as the module, or was lost), the entry is delivered under the
  next free `seq` and carries `provisional_seq`; `status().renumbered_from` is
  set and `replay` rewinds behind that number, so deletions journaled at the
  target after the backup apply as well.
- The target's line of an entry is final. The local copy and the mirror append
  it when theirs differs (in one file the last line of an entry wins; files are
  never rewritten), and readers prefer it over any other place.
- Once the local copy holds the target's line of an entry, that line is final
  for the writer too (marker `.<module>.final` in the local copy: every line up
  to that `seq` is the target's). If the target later shows another `seq` for
  such an entry (for example two entries with swapped `seq`), the target is
  `conflict`: nothing is delivered to it, the local copy and the mirror keep
  their lines, deletions go ahead with the entry in the local copy and the
  mirror, and `entries()` refuses to read. Only an entry the local copy holds
  under a provisional `seq` may arrive at the target under another one.
- While the target is not usable, entries that only the mirror holds (the local
  copy was restored or lost) are taken into the local copy; one whose `seq` the
  local copy already uses gets the next free provisional `seq`. No write leaves
  two entries under one `seq` in a place; a line that would is held back and
  reported.
- `status()` never raises for a place: `local`, `target` and `mirror` are
  `ok`, `unreachable`, `corrupt` or `conflict`, with the backlog per place and
  `problems` (file and line number, never content). It runs the same check as
  `entries()` on the places as the next delivery leaves them, so `ok` is never
  true while a replay would fail. Entries of a damaged local copy or mirror
  count towards `target_pending`. It is the input of `doctor erasure_journal`
  and does not wait for the writer lock.
- The writer never creates the target or mirror directory, so a missing mount
  shows as unreachable. Journal files are opened without following symlinks.
  Concurrent writers of one module are serialised with a lock file in the local
  copy.

### Mounts of the target and the mirror

`record` reads and appends to the target and the mirror inside the deletion. A
network mount that hangs instead of failing would hold up every deletion of the
module. Mount both so that a dead server returns an error within seconds:

- NFS: `soft,timeo=50,retrans=2`, never
  `hard` (nfs(5): linear back-off, an error after about 30 seconds).
- SMB/CIFS: `soft` (the default) with `echo_interval=10`.

These values come from the documentation (nfs(5), mount.cifs(8)) and have not
been tested against a dead server yet. Check the time until `record` returns
with the target stopped before relying on them.
- Anything else: mount it on the host, check it there and bind-mount the
  directory only while the check passes.

A place that returns an error counts as unreachable and the deletion goes ahead
with the entry in the local copy. `status()` takes no lock, but it still reads
each place, so the same mount options keep `doctor` from hanging.

### Operator repair

| `status()` shows | Effect | Repair |
|---|---|---|
| `target` or `mirror` `unreachable` | Deletions continue; entries wait in the local copy. | Mount the place or restore write access; run `flush()` (any deletion does it as well). |
| `target` or `mirror` `corrupt` | Deletions continue; nothing is written to that place; a replay refuses to run. | Move the file aside, keep a copy for inspection, remove the line named in `problems` (or two entries with one `seq`), put the file back; run `flush()`. |
| `local` `corrupt` | Deletions of the module are blocked. | Move `<module>.jsonl` out of the volume `papaia-erasure` for inspection; the next `flush()` rebuilds the local copy from target and mirror. Entries that existed only in the damaged copy must be delivered by hand. |
| `local` or `mirror` `conflict` | Deletions continue; a replay refuses to run. One entry differs in content between this place and the target (or the local copy), or two entries would share one `seq`. | Compare the files by `id` (`problems` names the places, not the content). Find out which line was changed; the target's file is not trustworthy by default, since every module can write it (residual risk below). Fix the changed line, run `flush()`. |
| `renumbered_from` set | The module state may be older than the journal. | Run `papaia-ctl recover-snapshot`; after a successful replay call `acknowledge_renumbering()`. |

### Replay after a restore

Module action `erasure-replay`:

```python
from papaia_kit.erasure import ReplayTrigger, replay

read = journal.entries()  # delivers pending entries, then target + mirror + local copy
if read.provisional:
    ...  # target unavailable: mark the run provisional (sicherheit 4.9 (2), (2a) (v))
result = replay(
    read.entries, applied_seq=db_applied_seq, handler=apply_entry, trigger=ReplayTrigger.RESTORE
)
```

Without a writer instance, `read_journal(module, [d for d in (target_dir, local_dir,
mirror_dir) if d is not None])` reads the configured places. Pass the target
first: for one entry the line of the first directory wins. It is strict: a
missing or unreadable directory raises `JournalUnavailableError` (an unmounted
target never looks like an empty journal); inside an existing directory a
missing file is an empty journal. Run `flush()` first if a place was down, or
use `journal.entries()`, which delivers before it reads. A stale local copy
that still holds an undelivered entry under a `seq` the target gave another
entry makes `read_journal` raise `JournalConflictError` until the next
`flush()`; a restore path should use `journal.entries()`. `read_journal` has
no final marker: it does not detect a `seq` rewritten at the target, while the
writer does.

`replay` applies every entry after the module's applied `seq` in order and
refuses a journal with a missing `seq`, two entries for one `seq` or one entry
with different content. The handler deletes (`erase`, `erase_subject`) or marks
a reminder delivered (`delivery`), is idempotent and stores the applied `seq` in
the same transaction. `ReplayResult` carries the counts per kind,
`replayed_from`, `journal_end` and `journal_behind` (the journal is shorter than
the module state, for example a target replaced by an older copy) for the audit
event and `doctor`. Only `papaia-ctl restore`, `rollback`, `recover-snapshot`
and the core start gate (`lifecycle`) trigger a replay; no module replays on its
own.

### State epoch check at module start

A module state can come back without `restore`: a hypervisor restores a VM
backup, or volumes are copied back by hand. No `erasure-replay` runs then. At
start each module compares the erasure `seq` it applied (kept in its own
database, see the caller contract) with the journal:

```python
from papaia_kit.erasure import LifecycleHandler, StartGate

gate = StartGate(journal, db.applied_erasure_seq, audit=audit_writer_sink, writer="assist")
gate.check()  # before serving anything; not ready until then

gate.require_ready()  # every request except POST /internal/lifecycle
if gate.background_allowed():  # before every step, schedule, delivery, erasure run
    ...
gate.check_if_due()  # every minute; rechecks a provisional result every 15 min
gate.health()  # body of GET /healthz: ok, degraded or down
```

Sources are the journal at the backup target with its `epoch` file, the mirror
and the local copy. `<backup target>/erasure-journal/epoch`
(`schemas/erasure-epoch.v1.schema.json`) is written by the core only
(`write_epoch`): `generation` of the installation and the last `seq` per module
and core source. Results (`doctor state_epoch`):

| State | When | Ready | `doctor` |
|---|---|---|---|
| `current` | target and `epoch` readable, no entry beyond the applied `seq` | yes | `pass` (`warn` if the journal is shorter than the module state) |
| `unverified` | target unreachable, damaged or `epoch` damaged; no source that could be read shows a backlog | yes, provisionally; checked again every 15 min | `warn`, audit `state_epoch_unverified` |
| `behind` | any source that could be read holds an entry beyond the applied `seq` (a damaged or conflicting target, mirror or local copy included: their intact lines count), `epoch` names a higher `seq`, or an entry was renumbered | no requests, no background work | `fail`, audit `state_epoch_behind` |
| `unknown` | neither target nor mirror nor local copy usable, or the applied `seq` is unreadable | no | `fail`, audit `state_epoch_unknown` |

Behind the journal the module shows: "Datenstand älter als das Löschjournal
(z. B. nach Rückspielen einer VM-Sicherung). Ausführen: papaia-ctl
recover-snapshot". It never replays on its own. Refused requests get the
envelope `PK-UPSTREAM-001` (503, `Retry-After: 60`) from
`ModuleNotReadyError.envelope(correlation_id)`.

`POST /internal/lifecycle` carries the core's actions `{"action":
"erasure-replay"}` and `{"action": "post-restore"}` (nothing else; at most
1 KiB). The module's server terminates mTLS and passes the caller from the
verified client certificate:

```python
handler = LifecycleHandler(
    journal=journal,
    gate=gate,
    applied_seq=db.applied_erasure_seq,
    apply_entry=apply_entry,  # idempotent, stores entry.seq in the same transaction
    post_restore=post_restore,  # returns counts only, or None for a module without one
    audit=audit_writer_sink,
    writer="assist",
)
response = handler.handle(body, caller=peer_identity, correlation_id=header_value)
```

Only `papaia-lifecycle` is served by default (`403 PK-ACCESS-001` otherwise);
a malformed body gets `400 PK-INPUT-001`, an unreachable journal `503
PK-UPSTREAM-001`, a damaged one `409 PK-CONFLICT-001`, a failing handler `500
PK-INTERNAL-001`. If clearing the renumbering marker or checking the gate
again fails after the entries were applied, the answer is `503
PK-UPSTREAM-001` (local copy not writable) or `500 PK-INTERNAL-001`, with an
`erasure_replayed` submission of result `error` that counts the applied
entries. A successful replay checks the gate again and answers with
counts only: `applied`, `applied_seq`, `by_kind`, `provisional`,
`journal_behind`, `state`, `ready`. Each request hands one `papaia.audit/1`
submission (without `source_seq`, which the audit writer assigns) to `audit`:
`erasure_replayed`, `post_restore_applied` or `lifecycle_request_rejected`.
Pass the audit writer as the sink, for example
`audit=lambda event: audit_writer.write(conn, event)` inside the module's
transaction.

### Residual risk

All modules mount the shared `erasure-journal` directory read-write, so a module
can change or delete the journal of another module and the core's `epoch` file
there. Two effects follow:

- Loss: a module can truncate or rewrite another module's journal. The writer
  limits the effect (a damaged file at the target or mirror blocks no deletion,
  the local copy re-delivers its own entries, a mirror keeps a second copy, a
  changed `seq` of an entry the local copy holds as final marks the target
  `conflict`), but entries recorded while a module's local copy was lost can be
  lost with it. Not detected: a `seq` rewritten for an entry the local copy
  holds only under a provisional `seq`, or while the local copy has no valid
  final marker (it was replaced without it); the local copy and the mirror then
  take the target's line over and a replay can skip a deletion.
- Injection: a compromised module can append a valid `erase` or
  `erase_subject` line to another module's journal at the next free `seq`. The
  line is a well-formed entry, so the writer accepts it and delivers it to the
  local copy; a later restore or rollback replays it and deletes data of the
  other module. The writer cannot tell such a line from a real one.

Until each module has its own mount at the target (its own journal read-write,
other modules' journals not mounted or read-only, `epoch` writable only for
the core), run the journal with one module per target directory, or treat it
as a single-module setup. A shared read-write directory is not fit for
production with several modules.

## Repository checks

The kit ships the checks every papaia repository runs in CI:

```sh
# Dependency licenses against the shared policy (Python environment of the
# project, npm lock files, or JSON records)
uv run --locked papaia-kit licenses check --python-project . --npm-lock js/package-lock.json

# Regenerate THIRD_PARTY_LICENSES.md (CI runs the same with --check)
uv run --locked papaia-kit licenses render --python-project . --npm-lock js/package-lock.json

# Denied terms in tracked and new files (optionally against a frozen
# baseline, see below)
uv run --locked papaia-kit repo words

# Author, committer, sign-off and wording of every commit in a range
uv run --locked papaia-kit repo commits origin/main..HEAD
```

## Catalog reader

`papaia_kit.catalog` is the one reader of the platform catalog
(`platform/services.json`) and the group list (`platform/groups.json`). It
checks size, strict JSON, the schema, unique ids and every entry's
`content_hash` (RFC 8785), keeps the last valid state when a file is invalid,
reports added, changed and removed entries, and derives the switcher with
`visible_modules(catalog, roles)` and link states with `link_state`. Behaviour
and shared vectors (`contract/vectors/`) are described in
`contract/catalog-reader.md`.

```python
from papaia_kit.catalog import ServicesReader, visible_modules

reader = ServicesReader("/etc/papaia/platform/services.json")
catalog = reader.get()  # checks the file at most every 30 s
if catalog is not None:
    switcher = visible_modules(catalog, id_token_claims["roles"])
```

## Check chain

`papaia_kit.authz.CheckChain` checks every bearer token on the server: RS256 or
ES256 signature against the realm keys, exact issuer, access token type, one audience (several
only for `trust: platform` and the chat client), `azp` in the allow list
`azp-allowlist.json` of the own audience (an empty list refuses every token),
identity kind, revocation list (`global_since`, revoked `sub`), module role and
the effect released for the `azp`. The `scope` claim is never a rights source.
A refusal raises `AuthzDenied` with an error envelope and hands one
`papaia.audit/1` row with result `denied` to the audit writer. `origin_azp`
comes from the configured upstream origins; the `X-Papaia-Origin-Azp` header is
information only, a mismatch is recorded as `origin_header_mismatch`. Details:
`contract/authz.md`.

## Conformance suites

`papaia-kit conformance <suite>` runs a conformance suite and writes JUnit XML
with `--junit`; every module runs the suites for the contract surfaces it
provides or consumes in its own CI. Checks, driver protocol and recording format
are described in `contract/conformance.md`.

```sh
# Section exposes: of an add-on: schema, naming register, checks beyond the schema
uv run --locked papaia-kit conformance manifest papaia-app.yaml --compose docker-compose.yml --junit conformance-manifest.xml

# The exposes.yaml of core profiles (no module name)
uv run --locked papaia-kit conformance manifest --core-profile src/*/*/exposes.yaml --junit conformance-manifest.xml

# Shared catalog reader vectors against the kit reader, or a reader behind a driver command
uv run --locked papaia-kit conformance catalog-consumer --junit conformance-catalog.xml

# A provider recording against its format and the pinned digest
uv run --locked papaia-kit conformance recording tests/golden/probe/recording.json --pin sha256:<digest>

# Server code: no generated code execution, no built query text or scopes, no model names
uv run --locked papaia-kit conformance static src/ --junit conformance-static.xml
```

The `static` suite takes exceptions only from the repository's
`static-exceptions.toml`: one entry per place (file, enclosing function or
class, subject, count) with reason, input source, expiry date and approval.
It reports how many files it left out per reason; `--include-dir` reads a
skipped directory such as `site-packages` of an image. The kit runs it over
its own package (`make check-static`). `--require-approved` rejects entries
whose `approved_by` does not name the security officer or still says
pending (a wording check; the joint acceptance, which runs the suite with
it, still reads the countersignatures).
The rules are heuristics; their known limits are listed in
[`contract/conformance.md`](contract/conformance.md).
`papaia-kit conformance realm` checks the separation rule of the realm: the
clients with token exchange and the audiences (including audiences from client
roles) intersect in exactly `{papaia-data}`. It reads a realm export or, with
the token of a read-only admin account, the admin API:

```sh
uv run --locked papaia-kit conformance realm --export realm-export.json --junit conformance-realm.xml
PAPAIA_KIT_ADMIN_TOKEN=... uv run --locked papaia-kit conformance realm --admin-url https://id.example.org --junit conformance-realm.xml
```

`papaia-kit conformance server` checks a running MCP server against its
declaration in the CI of the server: `tools/list` against `operations[]`,
`describe_access` and `check_access` without content, the error envelope, one
audit row per write and the refusal of tokens for a foreign audience, of a
foreign `azp` and with several audiences. Tokens come from the kit test issuer
(`testing/issuer/`, CI only):

```sh
uv run --locked papaia-kit conformance server papaia-app.yaml --url http://127.0.0.1:8000/mcp \
  --issuer http://127.0.0.1:8080 --azp papaia-studio-gateway --role probe-user \
  --calls conformance-calls.json --audit-file audit/server.jsonl --junit conformance-server.xml
```

With `--record FILE --image-digest sha256:<digest>` the run is also written as
the provider recording (request and response pairs, schema version, image
digest, no credentials), but only when every check passed; otherwise a file
an earlier run left there is removed, so the file is valid only on exit 0. The
command prints
the digest of the recording; consumers pin it and check their copy with
`papaia-kit conformance recording FILE --pin sha256:<digest>`.

## Naming register

`papaia_kit.names` holds the binding names of audiences, exchange scopes,
clients, roles, service accounts, core services and core networks, each with its
owning repository, plus the rule for new names and the list of removed names.
`exchange_scope(audience)` is the only way to build `aud-<audience>`;
`person_id(claims)` applies the person identifier rule (`sub`). Rules, removed
names and the `papaia-kit names` commands are described in `contract/names.md`.

CI also scans the full history for secrets (`make secrets`, gitleaks) and the
lock files for known vulnerabilities (`make vulns`, osv-scanner); both tools are
pinned by version and sha256 in the workflow.

### Python dependencies

`--python-project` reads every third-party package of the project's `uv.lock`
and takes its license from the project's environment, so the command must run
in that environment (`uv run --locked` inside the project, or the environment
named by `UV_PROJECT_ENVIRONMENT`); otherwise it fails. It also fails for every
locked package that is missing from the environment or installed at another
version. A package that an environment marker excludes on the checking platform
needs a `[[verified]]` entry.

Scopes: the closure of the dependencies and of the extras is `runtime`;
dependency groups named `test`, `tests` or `testing` are `test`; every other
group, and extras named like a development group (`dev`, `lint`, `docs`,
`typing`, `test`), are `build`. A package reached from several of them takes
the strictest scope (runtime, then build, then test).

The license is read from `License-Expression`, then `License`, then the license
classifiers, plus the files in the `licenses/` folder of the dist-info. Several
license classifiers are combined with AND. A `License` field that is neither a
known name nor an SPDX expression is never dropped: next to classifiers it adds
`LicenseRef-unparsed-license-field`; only pure pointers such as `see LICENSE` or
`UNKNOWN` give way to the classifiers. GNU GPL, LGPL or AGPL named in the license
files (any letter case; fixed passages of the PSF and MPL-2.0 texts excepted)
adds `LicenseRef-GPL-family-text-in-license-files` unless every choice of the
expression already includes a GPL-family license. These parts, and classifiers
without a version (`BSD License`, `Apache Software License`), need a
`[[verified]]` entry.

### Denied terms

`repo words` reports tool and vendor names, private tooling and key prefixes.
A few fixed contexts that name no tool are allowed (HTTP header names, key
daemons, the CSS pointer-shape property and utility classes, attribute access
on code objects); see `ALLOWED_CONTEXTS_B64` in `py/papaia_kit/repo`.

### Frozen baseline of the word check

A repository whose existing texts use a denied term as product vocabulary
freezes those places in a baseline file instead of rewriting them. The kit
itself has no baseline; its own term list stays encoded in the package.

```sh
# Once: list every current hit with one reason (refuses an existing file)
uv run --locked papaia-kit repo words --baseline words-baseline.toml \
    --write-baseline --reason "product term of the chat interface"

# In CI: listed hits pass, every other hit and every stale entry fails
uv run --locked papaia-kit repo words --baseline words-baseline.toml
```

Each `[[entry]]` holds `path` (relative to the repository root), `term` (as
found), `fingerprint` (SHA-256 of the line text without surrounding white
space), `count` (hits of this term on lines with this text in that file,
default 1; a line that holds the term twice counts twice) and `reason` (one
line, no denied term). Unknown keys, duplicate entries and malformed values
make the file unusable (exit 2). `--write-baseline` refuses (exit 2, no file)
what the check would reject: more than 10 000 entries, a `count` above 1 000,
more than 1 MiB, or a hit that is no valid `term`.

- A hit passes only when an entry has the same path, term and fingerprint. A
  line that moved or changed its indentation keeps its fingerprint; an edited
  line, the same text in another file, or one more copy of the line than
  `count` fails.
- An entry with fewer hits than its `count` is stale and fails until it is
  removed, so the list only shrinks.
- In the baseline file itself only the `term = "<term>"` lines of listed terms
  and the `path = "<path>"` lines of listed paths, exactly as `--write-baseline`
  writes them, are exempt; comments and every other line are checked. So the
  baseline can live in the repository even when a listed path holds a term.
- `--write-baseline` creates the file once. Afterwards entries are removed
  freely, but every added or changed entry needs a reviewed change with its own
  reason for that place.

## License policy

`policy/license-policy.toml` sorts SPDX identifiers into classes and decides
per scope (`runtime`, `build`, `test`, `service`) which classes are allowed,
allowed only with an exception, or denied. In short:

1. Own code and own images use permissive licenses only (fonts OFL-1.1, data
   and icons CC-BY-4.0 with attribution).
2. Weak copyleft only unmodified, as a separate file or dynamically loaded,
   with an exception entry and an ADR per package.
3. GPL, AGPL, SSPL, BUSL, Elastic, RSAL, non-commercial or no-derivatives terms
   and unknown licenses never enter own code or images.
4. Third-party services that run separately (own container, network protocols
   only): permissive and weak copyleft freely; GPL and AGPL only unmodified with
   source provision; source-available licenses only with written approval of
   the owner; proprietary only in tests or when procured by the operator.
5. Build and test tools may carry any free license, fonts and attribution
   licenses included, as long as they never enter an artefact.

Exceptions live in each repository's `license-exceptions.toml`: one entry per
package and exact version with scope, reason, ADR, expiry date and approval. An
exception never lifts a denied class. Empty or ambiguous package metadata is
resolved with a `[[verified]]` entry naming the https source where the license
was checked.

## Error envelope

Every module answers errors with one envelope, `schemas/error.v1.schema.json`:
the body of an `application/problem+json` response (RFC 9457) or the
`error.data` of an MCP JSON-RPC error.

```json
{
  "type": "https://schemas.papaia.dev/errors/forbidden_or_not_found",
  "title": "Nicht gefunden oder nicht erlaubt",
  "status": 404,
  "code": "PK-ACCESS-001",
  "class": "forbidden_or_not_found",
  "message": "Der Inhalt ist nicht vorhanden oder nicht für Sie freigegeben.",
  "hint": "Fragen Sie Ihre Ansprechstelle, wenn Sie Zugriff brauchen.",
  "correlation_id": "c0a8-4e2f-91",
  "retryable": false
}
```

| Class | HTTP | Retryable |
|---|---|---|
| `unauthenticated` | 401 | no |
| `forbidden_or_not_found` | 404 (default) or 403; the target decides, the answer never tells whether the object exists | no |
| `invalid_input` | 422 (default) or 400 | no |
| `conflict` | 409 (default) or 412 | no |
| `rate_limited` | 429, `retry_after` and `Retry-After` required | yes |
| `upstream_unavailable` | 503 (default), 502 or 504; `retry_after` optional | yes |
| `identity_revoked` | 401 | no |
| `class_exceeded` | 403 | no |
| `contract_mismatch` | 409 | no |
| `budget_exceeded` | 429 | no |
| `internal_error` | 500; generic class of every unknown code | no |

Module codes (`<MODULE>-<AREA>-<NR>`, modules `FLOW`, `DATA`, `STUDIO`,
`ASSIST`, `ME`, `CONNECTIONS`, `MCP`; `PK` is the kit) map to exactly one class
in `contract/errors.yaml`. A well-formed code that is not listed keeps its name
and gets the class and texts of `PK-INTERNAL-001`; a malformed code is replaced
by `PK-INTERNAL-001`.

```python
from papaia_kit.errors import build_envelope, display_text, display_text_for, parse_envelope

# Sending side
envelope = build_envelope("PK-ACCESS-001", correlation_id=request_correlation_id, lang="de")
response_body, response_headers = envelope.to_dict(), envelope.http_headers()

text = display_text(
    "PK-ACCESS-001", correlation_id=envelope.correlation_id, params={"contact": "die IT-Abteilung"}
)
text.parts()  # (what happened + consequence, what to do, "Kennung: c0a8-4e2f-91")

# Receiving side
received = parse_envelope(json_body)  # strict; raises ValueError
shown = display_text_for(received, lang="de")  # the only way to show it to a person
```

- On the sending side `title`, `message` and `hint` come only from
  `contract/messages/codes.{de,en}.yaml`; `build_envelope` takes no free text.
- On the receiving side, never show the received `title`, `message` or
  `hint`. `parse_envelope` rejects texts with a forbidden pattern or a control,
  format (bidi, zero-width), private-use or separator character, and a known
  code that carries another class; a well-formed unknown code may carry any
  class. Only `display_text_for(received)` produces text for a person: it
  rebuilds all three parts from `code` and `class` (an unknown code gets the
  texts of the kit code of its class). Together these keep source content,
  credentials and raw server or model output away from people, also when the
  other side is faulty or foreign.
- A missing or invalid correlation id (more than 64 characters, other than
  `[A-Za-z0-9-]`, or shaped like a token or prefixed key) is replaced by a new
  UUIDv7. The envelope uses the same rule as `papaia_kit.correlation` and the
  audit schema (`contract/audit.md`).
- Placeholder values (`{contact}`, `{role}`, `{n}`, `{step}`) come from
  configuration (`branding.contact`, role names of the interface) or from names
  the person may see anyway (a workflow step, a count), never from the content,
  title or owner of a source object. They are length-checked, must pass the
  forbidden patterns and must not contain control, format, private-use or
  separator characters. `check_params` raises on a bad value (use it when
  loading configuration); `display_text`, `display_text_for` and
  `build_envelope` drop bad values instead, so the error path never fails:
  `{contact}` falls back to `contact_default`, `{role}` to the reviewer role of
  the code's module (`Studio-Prüfer`, `Flow-Prüfer`, `Data-Prüfer`, else
  `Prüfer`). Parts 1 and 2 only use these two placeholders; a consequence
  sentence without its `{n}` or `{step}` falls back to its `_unnamed` variant
  or is left out.
- `contract/messages/consequences.{de,en}.yaml` holds the closed list of
  consequence sentences that a code may append to part 1.
- `contract/forbidden-patterns.yaml` lists patterns that never appear in visible
  text (codes outside part 3, a status code on its own, identifiers and key
  names, stack traces, opaque values); `find_forbidden_patterns(text)` applies
  it, and the tests run it over every text of the catalog.

## Token exchange

`papaia_kit.exchange` is the only builder of token exchange requests: RFC 8693
with `audience=<a>` and `scope=aud-<a>`, exactly one audience per token. A
received token is exchanged further only for audiences declared as `downstream`
(chain holder only), with the informational header `X-Papaia-Origin-Azp`.
Exchanged tokens are cached per `sub` and audience and never beyond their
lifetime; a refusal after revocation is `identity_revoked`, and modules call
`forget(sub)` on the lifecycle signal. The chain holder never exchanges a token
of its own. Client authentication is `private_key_jwt`, a client secret only as
a fallback. Details in `contract/exchange.md`.

## Releases and pinning

- Versions follow Semantic Versioning; tags are `vX.Y.Z`. Every release has a
  dated entry in [`CHANGELOG.md`](CHANGELOG.md).
- The Python package and the TypeScript package always carry the same version.
- One version always means the same bytes: new content gets a new version
  (0.1.x before the first joint delivery), and a version is never rebuilt
  from another commit.
- Every consumer pins the kit by exact version **and** sha256 digest of the
  released artefact (wheel or source tarball). Without a package index the
  files are vendored under `vendor/papaia-kit/<version>/`, bound as a path
  source in `pyproject.toml` (`[tool.uv.sources]`) and listed in `kit.lock`
  with their sha256; `uv.lock` carries the same digest. Shape of `kit.lock`:
  [`release/kit.lock.example`](release/kit.lock.example). With an index the
  pin reads
  `papaia-kit @ https://<release host>/papaia_kit-0.1.1-py3-none-any.whl#sha256=<digest>`.
- Runtime dependencies take ranges so that consumers can apply security
  patches; `cryptography` has no upper bound, so no consumer needs an
  override for it.
- Images that contain the kit carry the label `de.fidonis.platform-kit=<version>`.

### Building a release

After the release commit is tagged:

```sh
make release TAG=v0.1.1 REGISTRY=/abs/path/to/registry
make release-verify TAG=v0.1.1 REGISTRY=/abs/path/to/registry
```

`release/kit_release.py` exports exactly the tagged commit (`git archive`, not
the work tree), checks that the tag, `py/papaia_kit/__init__.py`,
`js/package.json` and `CHANGELOG.md` agree on the version, and builds wheel and
source tarball with `uv build` and `SOURCE_DATE_EPOCH` set to the commit time.
The build backend and its dependencies are pinned with sha256 in
`release/build-constraints.txt` (`--require-hashes`). The result goes to:

```text
<registry>/papaia-kit/<version>/papaia_kit-<version>-py3-none-any.whl
<registry>/papaia-kit/<version>/papaia_kit-<version>.tar.gz
<registry>/papaia-kit/<version>/SHA256SUMS
<registry>/papaia-kit/<version>/kit.lock
```

The registry is a plain directory outside the repository (usable as
`--find-links`). A version already there is never replaced: an identical
rebuild changes nothing, other content is refused (exit 1). `release-verify`
checks the files against `SHA256SUMS`, rebuilds the tag locally and fails
(exit 1) when any digest differs. Invalid input (tag not `vX.Y.Z`, unknown
tag, relative path, registry inside the repository, symlinked registry
folder) exits 2 before anything is written.

## License

Apache License 2.0, see `LICENSE` and `NOTICE`. Third-party components are
listed in `THIRD_PARTY_LICENSES.md`.
