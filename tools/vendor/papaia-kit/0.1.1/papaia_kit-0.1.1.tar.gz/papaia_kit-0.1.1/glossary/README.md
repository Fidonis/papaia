# Glossary

The German and English glossary binding for all user-facing texts of the
platform, with the replacement lists used by the wording check.
