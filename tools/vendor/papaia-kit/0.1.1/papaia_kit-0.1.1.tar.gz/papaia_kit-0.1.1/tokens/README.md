# Design tokens

Design tokens (colours, spacing, type scale) shared by all user interfaces of
the platform, published as CSS custom properties.
