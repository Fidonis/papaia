# Probe add-on

A minimal example add-on with a small MCP server (read, write, delete, event,
personal setting). It proves that the integration contract works end to end and
serves as the reference for add-on authors.
