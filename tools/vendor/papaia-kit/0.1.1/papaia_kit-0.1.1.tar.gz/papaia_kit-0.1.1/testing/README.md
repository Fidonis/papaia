# Test support

Test doubles and fixtures that modules use in their own test suites, such as the
test model service and recorded provider responses. Nothing in this directory is
used at runtime.

## Kit test issuer

`issuer/` is a minimal OIDC token issuer for the server suite
(`papaia-kit conformance server`) and other CI test stacks. It is never part
of a product image; see [`issuer/README.md`](issuer/README.md).

## Test vectors

`vectors/` holds valid and invalid examples of the contract formats. Every
implementation of a format runs them: each valid vector must pass, each invalid
vector must be rejected. An invalid audit vector marked `"checked_by": "validator"`
is valid JSON Schema and is rejected by the additional checks in
`contract/audit.md` ("Checks beyond the schema"). The wheel ships them under `papaia_kit/_data/vectors`
(`papaia_kit.vectors_dir()`).

| File | Format |
|---|---|
| `vectors/audit.v1.json` | `papaia.audit/1` events (`schemas/audit.v1.schema.json`) |
| `vectors/correlation-id.json` | values of the `X-Papaia-Correlation-Id` header |
