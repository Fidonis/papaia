"""Conformance suites for consumers and providers of the contract, with test vectors.

``papaia-kit conformance <suite>`` runs a suite and writes JUnit XML:

- ``manifest``: the section ``exposes:`` against the schema, names against the
  register and the checks beyond the schema (``contract/exposes.md``);
- ``catalog-consumer``: the shared catalog reader vectors against the kit reader
  or a module's own reader behind a driver command;
- ``recording``: a provider recording against its format and a pinned digest;
- ``static``: server code against the rules on generated code execution, built
  queries, built scopes and hard-coded model names;
- ``realm``: clients with token exchange versus audiences, read from a realm
  export or read-only from the admin API (separation rule, security 1.2);
- ``server``: a running MCP server against its declaration, with tokens of the
  kit test issuer (``tools/list``, standard operations, error envelope, audit
  row per write, refusal of foreign audience, foreign ``azp`` and several
  audiences); with ``--record`` it also writes the provider recording.

See ``contract/conformance.md``.
"""

from papaia_kit.conformance.catalog_consumer import (
    CommandDriver,
    DriverError,
    DriverFactory,
    KitReaderDriver,
    Observation,
    ReaderDriver,
    run_catalog_consumer,
)
from papaia_kit.conformance.ecma_regex import ecma_pattern_error
from papaia_kit.conformance.manifest import (
    DELEGATION_HOLDERS,
    MANIFEST_CHECKS,
    DelegationHolder,
    ManifestError,
    check_manifest_documents,
    check_manifest_files,
    load_compose_volumes,
    load_manifest,
)
from papaia_kit.conformance.realm import (
    CHAIN_HOLDER,
    NEVER_AUDIENCE,
    REALM_CHECKS,
    Fetch,
    Realm,
    RealmError,
    UrllibFetch,
    audiences,
    check_realm,
    check_realm_export_file,
    exchange_clients,
    load_realm_export,
    read_realm_admin,
    realm_from_export,
)
from papaia_kit.conformance.recording import (
    RECORDING_FORMAT,
    RecordingError,
    check_recording_file,
    dump_recording,
    load_recording,
    recording_digest,
    schema_version,
)
from papaia_kit.conformance.result import Case, SuiteResult, junit_xml
from papaia_kit.conformance.server import (
    RECORDING_CHECK,
    SERVER_CHECKS,
    IssuerTokens,
    Provider,
    ServerSuiteError,
    ServerTarget,
    TokenSource,
    load_calls,
    record_server_suite,
    run_server_suite,
    select_entry,
)
from papaia_kit.conformance.static import (
    EXCEPTION_INPUTS,
    SKIP_REASONS,
    SKIPPABLE_DIRS,
    STATIC_RULES,
    Finding,
    Sources,
    StaticException,
    StaticExceptionError,
    collect_sources,
    load_static_exceptions,
    run_static,
    scan_source,
)

__all__ = [
    "CHAIN_HOLDER",
    "DELEGATION_HOLDERS",
    "MANIFEST_CHECKS",
    "NEVER_AUDIENCE",
    "REALM_CHECKS",
    "RECORDING_CHECK",
    "RECORDING_FORMAT",
    "SERVER_CHECKS",
    "Case",
    "CommandDriver",
    "EXCEPTION_INPUTS",
    "SKIPPABLE_DIRS",
    "SKIP_REASONS",
    "STATIC_RULES",
    "DelegationHolder",
    "DriverError",
    "DriverFactory",
    "Finding",
    "Fetch",
    "IssuerTokens",
    "KitReaderDriver",
    "ManifestError",
    "Observation",
    "Provider",
    "ReaderDriver",
    "Realm",
    "RealmError",
    "RecordingError",
    "Sources",
    "StaticException",
    "StaticExceptionError",
    "ServerSuiteError",
    "ServerTarget",
    "SuiteResult",
    "TokenSource",
    "UrllibFetch",
    "audiences",
    "check_manifest_documents",
    "check_manifest_files",
    "check_realm",
    "check_realm_export_file",
    "check_recording_file",
    "collect_sources",
    "dump_recording",
    "ecma_pattern_error",
    "exchange_clients",
    "junit_xml",
    "load_calls",
    "load_compose_volumes",
    "load_manifest",
    "load_realm_export",
    "load_recording",
    "load_static_exceptions",
    "read_realm_admin",
    "realm_from_export",
    "record_server_suite",
    "recording_digest",
    "run_catalog_consumer",
    "run_static",
    "scan_source",
    "run_server_suite",
    "schema_version",
    "select_entry",
]
