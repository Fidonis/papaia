"""Location of the data directories shipped with the kit.

An installed wheel carries the directories under ``papaia_kit/_data``. A source
checkout (editable install) keeps them once in the repository, shared with the
other language bindings, so the lookup falls back to that location.
"""

from __future__ import annotations

from pathlib import Path

_PACKAGE_DIR = Path(__file__).resolve().parent
_SOURCE_ROOT = _PACKAGE_DIR.parent.parent


def _data_dir(name: str, source: str | None = None) -> Path:
    for candidate in (_PACKAGE_DIR / "_data" / name, _SOURCE_ROOT / (source or name)):
        if candidate.is_dir():
            return candidate
    raise FileNotFoundError(f"papaia-kit data directory {name!r} is missing")


def schemas_dir() -> Path:
    """Directory holding the contract schemas (JSON Schema 2020-12)."""
    return _data_dir("schemas")


def policy_dir() -> Path:
    """Directory holding the license policy shared by all repositories."""
    return _data_dir("policy")


def contract_dir() -> Path:
    """Directory holding the contract data next to the schemas (codes, texts, patterns)."""
    return _data_dir("contract")


def vectors_dir() -> Path:
    """Directory holding the shared test vectors (valid and invalid contract examples)."""
    return _data_dir("vectors", "testing/vectors")
