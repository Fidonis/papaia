# Audit events `papaia.audit/1` and the correlation id

Schema: [`../schemas/audit.v1.schema.json`](../schemas/audit.v1.schema.json).
Test vectors: [`../testing/vectors/audit.v1.json`](../testing/vectors/audit.v1.json) and
[`../testing/vectors/correlation-id.json`](../testing/vectors/correlation-id.json).
Python: `papaia_kit.audit.validate_event`, `papaia_kit.correlation`.

## Who writes what

Every module and every server writes one event per `write`, `send` and
`delete` operation, per rejection, per call under a service account, and per
event type listed in the schema (`$defs/event`). Caller and server both write:
one operation produces one event at the calling module (`role: caller`) and one
at the server (`role: server`), with the same `correlation_id` and `sub`.

A source hands each event to the kit's audit writer, which stores it in the
source's outbox and delivers it to `papaia-audit`. `papaia-audit` is the only
store that can be read.

## Writer and ingest

Python: `papaia_kit.audit.writer` (`AuditWriter`, `AsyncAuditWriter`),
`papaia_kit.audit.outbox`, `papaia_kit.audit.transport`.

**Outbox.** A source keeps two tables in its own database (`outbox_ddl`
creates them for SQLite and PostgreSQL):

| Table | Columns |
|---|---|
| `audit_outbox_state` | one row: `id = 1`, `last_source_seq` |
| `audit_outbox` | `source_seq` (key), `created_at` (the event's `time`), `body` (compact JSON) |

`write(conn, event)` runs in the caller's open transaction, next to the effect
it records: it validates the event as a submission, increments
`last_source_seq` and inserts the row. The caller commits or rolls back both
together. The counter row stays locked until the transaction ends, so
`source_seq` is gapless (a rollback returns its number) and rows commit in
`source_seq` order. The price is throughput: all transactions that write audit
rows for one source run one after another, so a caller keeps such a
transaction short and calls `write` as late in it as possible. The event must not carry `source_seq` (the writer assigns
it) nor `source`, `seq`, `prev_hash` or `hash` (assigned by `papaia-audit`).

**Delivery.** One loop per source reads the oldest rows, at most 500, and sends
them in `source_seq` order. A row is deleted only after `papaia-audit`
acknowledged it with the `seq` it assigned. A failed call keeps every row and
is retried with exponential backoff (1 s doubling up to 60 s, with jitter); the
next call starts again at the lowest unacknowledged row. Delivery is
therefore at least once, and `source_seq` is the idempotency key:
`papaia-audit` stores each `(source, source_seq)` once and acknowledges a
repeat with the `seq` it already assigned. Nothing is lost on restart, because
the outbox is the source's own database. While `papaia-audit` is unreachable
the source keeps working and the outbox grows; `status()` reports depth and
the oldest `time` for `papaia_audit_outbox_depth{source}`.

**Request.** `POST https://papaia-audit:8443/v1/ingest` over TLS with the
source's client certificate from the platform PKI; plaintext is refused, the
server certificate must chain to the platform CA and match the host name.
`papaia-audit` takes `source` from the client certificate. Body:
`Content-Type: application/x-ndjson`, 1 to 500 lines, one compact submission
per line, ascending `source_seq`.

**Storing a batch.** `papaia-audit` handles the lines of a request in
ascending `source_seq` and stores a line only when its `source_seq` is the
next one for the source (the highest stored plus 1, or 1 for a new source). A
line with a `source_seq` already stored is a repeat: it is not stored again
and is acknowledged with the `seq` it already has. At the first line it does
not store, for whatever reason (invalid submission, unknown schema version, a
gap in `source_seq`, a storage error), it stops and leaves that line and every
later line unstored. A gap cannot arise from the writer, which deletes only
acknowledged leading rows and whose counter is gapless; it means that rows
were removed from the outbox, and `papaia-audit` never closes it on its own.
`seq` therefore rises with `source_seq`, and the hash chain of a source
follows `source_seq` order.

**Response.** `200` with

```json
{"acknowledged": [{"source_seq": 9021, "seq": 18233}]}
```

listing the leading lines of the request that are stored or were already
stored, in request order, each once, with strictly rising `seq`: a prefix of
the batch, possibly empty. When the first line is not stored, the response is
`422` with an error envelope whose `error_code` names the cause
(`audit.invalid_submission`, `audit.unsupported_format`,
`audit.source_seq_gap`); it carries no event content. Any other status, more
than 256 KiB, an unknown field, a non-integer or non-positive number, an entry
for a row that was not sent, and any list that is not a prefix of the batch in
order with rising `seq` counts as no acknowledgement: the writer deletes
nothing and retries. The rows after an acknowledged prefix stay in the outbox
and are sent again, starting the next batch.

**A row that is never accepted.** Rows stay in the outbox until acknowledged
and are never skipped, so a row `papaia-audit` will not store (for example a
submission of a newer schema than the service knows) holds back every later
row of that source. The writer keeps running and retrying with backoff; the
source keeps working. The stall shows as:

- the warning `audit delivery failed: rejected (<n> rows, kept, status 422)`
  on every attempt when the first row of the batch is refused, or
  `not_acknowledged` when the service answers `200` with an empty list;
- outbox depth (`status().depth`, `papaia_audit_outbox_depth{source}`) that
  only grows, and an oldest `time` (`status().oldest_time`) that no longer
  moves; `doctor audit` reports `warn` from 10 000 rows or an oldest row
  older than 15 minutes and `fail` with mail from 100 000 rows (governance
  GV-01), so a stall reaches the operator even below those depths through
  the age;
- on the `papaia-audit` side, the `error_code` of the refused line in its own
  log.

The operator brings the two sides to the same contract version: update
`papaia-audit` when the source writes a newer schema, or the source when it
writes something the current schema refuses. A row is never deleted from the
outbox by hand to clear a stall; that would create the gap described above.

The writer logs reason codes and row counts only, never an event or a
response.

**Outbox in a file of its own.** A source without a database of its own (an
MCP server whose effect happens in a remote service) uses `FileAuditWriter`:
the same two tables in a SQLite file on a persistent volume, for example
`/var/lib/<source>/audit/outbox.sqlite3`. The effect cannot share a
transaction with the outbox, so `record(event)` writes each row in a
transaction of its own, right after the remote call returns (`allowed` or
`error`) and before the source answers. A crash between the remote call and
`record` loses that one row; this is the accepted residual risk. The file
survives a restart of the source like any other outbox, and delivery,
ordering and acknowledgement are unchanged. The writer creates the directory
with mode 0700 and the file with mode 0600, tightens both if they belong to
the source's user, and refuses a symbolic link, a non-regular file and a
directory or file of another user. The database runs in WAL mode with
`synchronous=FULL`.

## Two forms of one event

| Form | Schema | Carries |
|---|---|---|
| Submission | `audit.v1.schema.json#/$defs/submission` | the body as written by the source |
| Stored | `audit.v1.schema.json` | the body plus `source`, `seq`, `prev_hash`, `hash` |

`source`, `seq`, `prev_hash` and `hash` are assigned by `papaia-audit` only.
A submission that carries any of them is rejected: the source is taken from the
mTLS client certificate, never from the body. The chain per source is
`hash = SHA-256(prev_hash || JCS(body))` with the canonical JSON of RFC 8785;
the first event of a source has `prev_hash` of 32 zero bytes. All four fields
are required in the stored form: `papaia-audit` computes `hash` for every event
it stores, and an export carries it so that a recipient can check the chain for
gaps and changes without access to the store.

## Fields

| Field | Required | Meaning |
|---|---|---|
| `format` | always | `papaia.audit/1` |
| `time` | always | time at the source, UTC with milliseconds (`2026-11-20T09:14:03.120Z`) |
| `source_seq` | always | gapless counter of the writer, from 1; repeated deliveries are dropped by it |
| `correlation_id` | always | see below |
| `writer` | always | `<source>` or `<source>/<component>` |
| `result` | always | `allowed`, `denied` or `error` |
| `event` | always | event type, one of `$defs/event` |
| `role` | operation | `caller` or `server` |
| `sub` | operation | subject of the acting identity |
| `identity_kind` | operation | `person` or `service` |
| `service_account` | with `service` | id of the service account; must be null for a person |
| `azp` | operation | authorized party of the presented token |
| `aud` | no | the single audience of the presented token |
| `origin_azp` | no | origin of a token chain, set by the server from the upstream origins enforced by the identity provider |
| `origin_source` | with `origin_azp` | `policy` (enforced upstream origin) or `azp` (the caller is its own origin) |
| `origin_asserted_by` | no | value of the `X-Papaia-Origin-Azp` header; information only, never used for a decision |
| `context` | no | `app`, `run`, `step`, `analysis`, `delegation` identifiers |
| `catalog_id` | operation | catalog entry, for example `paperless.documents` |
| `operation` | operation | operation name, for example `add_note` |
| `effect` | operation | `read`, `write`, `send`, `delete` or `check` |
| `object_ref` | no | `{type, id}` of the object acted on |
| `data_class` | no | one of the eight data classes |
| `error_code` | no | module error code or error class |
| `client_ip` | no | client address at the edge, for sign-in events |
| `detail` | no | `objects` (database object names), `rows`, `bytes`, `count`, `duration_ms`, `spid`, `statement_hash` |
| `token_iat` | server operation | `iat` of the presented token, seconds since the epoch |
| `token_auth_time` | server operation | `auth_time` of the presented token (time of the sign-in); null when the token has none, for example a service account |
| `token_remaining_s` | server operation | seconds from the check of the token to its `exp`; 0 when the token is past `exp` within the 30 s tolerance |

"operation" means the field is required and not null when `event` is
`operation`. Optional fields may be omitted or null.

**Token times** (since schema 1.1.0). `token_iat`, `token_auth_time` and
`token_remaining_s` are optional integers from 0 to 2^63 - 1, or null. A
non-null value is allowed only in a row with `role: server` and
`event: operation`; any other row with one is rejected. A server fills them
from `Principal.audit_fields()` of the check chain (`contract/authz.md`), so
its row of PLT-11-A2 shows `iat`, `auth_time` and the remaining lifetime of
the token that arrived, never the token. Rows written before 1.1.0 stay
valid; a validator of 1.0.0 rejects a row that carries the new fields, so
`papaia-audit` is updated before or together with its sources.

## Never in an event

Token values, request or response payloads, titles, search texts, form values,
SQL statements or literals, document content and vector values. The schema
enforces this as far as a schema can:

- unknown fields are rejected at every level, so there is no place for
  `token`, `payload`, `title`, `query`, `content` or similar fields;
- every string is an identifier with a fixed character set and length;
- strings shaped like a JSON Web Token, a bearer credential or a PEM block are
  rejected in every identifier field;
- opaque keys with a well-known prefix are rejected in every identifier field:
  `sk-` (LLM gateway and provider keys), `ghp_`, `gho_`, `ghu_`, `ghs_`, `ghr_`,
  `github_pat_`, `glpat-`, `xoxa-`, `xoxb-`, `xoxe-`, `xoxp-`, `xoxr-`, `xoxs-`
  and `AKIA`, each followed by the usual minimum of characters and preceded by
  the start of the value or a character that is not a letter or digit.

"Every identifier field" means every string of the event except `time`,
`client_ip` and the hash fields, whose patterns admit only digits, hex or
address characters. This includes the fields a server or `papaia-audit` sets
(`writer`, `catalog_id`, `operation`, `object_ref.type`, `source`) and
`correlation_id`, the one identifier that arrives unchanged from outside (HTTP
header, MCP `_meta`). A receiver therefore treats a key-shaped correlation id
as invalid and replaces it (see below), so the value never reaches an event.

What the schema cannot catch: an opaque random secret without a known prefix
(for example a client secret or a session id) looks like any other identifier.
Writers must never put such values into an event; the schema only stops the
recognisable shapes. The token search of PLT-19-A4 covers exactly the shapes
above (JSON Web Token, bearer credential, PEM block, prefixed keys); a wider
search such as a full secret scanner may find more and is welcome as an extra.

`validate_event` reports problems as `<json path>: <rule>` and never repeats a
value of the rejected event, because that value may be the token or content the
event was rejected for. An unknown field is named only when its name is a field
of the schema or a common content field name (`payload`, `content`, `token`,
`title`, `query` and similar); any other key may itself be a secret used as a
key and appears as `<redacted>`.

## Correlation id

- Header `X-Papaia-Correlation-Id`: 1 to 64 characters out of `A-Z`, `a-z`,
  `0-9` and `-`, and not shaped like a prefixed key (the token rule above,
  `#/$defs/token_free`). A value such as `AKIA` followed by 16 capitals has only
  allowed characters and is still invalid.
- **Generation:** a receiver with no valid value creates a new UUIDv7
  (RFC 9562) with `new_correlation_id()`.
- **Validation:** a missing, invalid or oversized value, and a header repeated
  with different values, is replaced by a new id. It is never shortened or
  repaired, and the replaced value is not recorded anywhere
  (`accept_correlation_id`, `correlation_id_from_headers`).
- **Propagation:** every follow-up call carries the accepted id: the HTTP header
  (`correlation_headers`), `_meta.correlation_id` in MCP requests (`mcp_meta`,
  `correlation_id_from_mcp_meta`), and the state of a flow run. The helpers
  refuse to propagate a value that did not pass validation. A `_meta` that is
  not a JSON object (a list, a string, a number) counts as missing and gets a
  new id; it never raises.
- `traceparent` (W3C Trace Context) may travel alongside. It never replaces the
  correlation id, which is the value audit events and error envelopes carry.
- **One rule in the kit.** The error envelope uses the same rule:
  `papaia_kit.errors.normalize_correlation_id` is `accept_correlation_id`,
  `parse_envelope` rejects a body whose `correlation_id` fails it, and
  `error.v1.schema.json` carries the same `#/$defs/correlation_id` as
  `audit.v1.schema.json`. An id taken from an error envelope can therefore
  always be written into an audit event.

## Checks beyond the schema

Every implementation that validates `papaia.audit/1` (the kit's
`validate_event`, `papaia-audit` at ingest, validators in other languages)
applies these checks in addition to the schema. Test vectors marked
`"checked_by": "validator"` are valid JSON Schema but break one of them.

1. **Limits before patterns.** Reject, before any schema keyword runs:
   - any string or field name longer than 256 characters (the largest
     `maxLength` in the schema),
   - any event larger than 16 KiB (16384 bytes), measured as the UTF-8 bytes of
     its compact JSON serialisation: no whitespace between tokens (separators
     `,` and `:`), non-ASCII characters written as themselves, not as `\u`
     escapes,
   - objects or arrays nested deeper than 3 levels (event, `detail`,
     `detail.objects`),
   - more than 512 values in one event.

   JSON Schema validators evaluate `pattern` even when `maxLength` in the same
   schema already failed, so without these limits one oversized value costs CPU
   time in every pattern. `validate_event` reports `<path>: too long`,
   `$: event too large` or `<path>: nested too deeply` and stops there.
2. **Plain JSON only.** Every object key at every level is a string; values
   are objects, arrays, strings, integers, `true`, `false` or `null`. Bindings
   whose native maps admit other keys (for example `True` or `7` in Python)
   reject them as `$: not plain JSON` instead of converting them to strings.
3. **Integers are integers.** Counters and amounts (`source_seq`, `seq`,
   `detail.rows`, `bytes`, `count`, `duration_ms`, `spid`) are written as JSON
   integers without fraction or exponent. JSON Schema accepts `3.0` as an
   integer; the hash chain (`JCS(body)`) and the `bigint` columns of
   `papaia-audit` do not treat it as `3`. The schema has no non-integer number,
   so `validate_event` rejects every number that the JSON parser does not
   return as an integer.
4. **Real dates.** `time` must name a date that exists (no 30 February, no
   29 February outside a leap year). The schema carries `format: date-time`;
   validators that do not assert formats check the date themselves.

The token pattern itself uses only bounded quantifiers, so a consumer that
skips the limits still validates in linear time.

## Notes for schema consumers

JSON Schema patterns are ECMA-262 regular expressions. Anchored patterns end in
`$(?!\n)` so that engines whose `$` also matches before a final newline (Python)
reject a trailing newline as ECMA-262 does. `client_ip` uses `format` in
addition to a pattern; validators that assert formats reject more invalid
addresses than the pattern alone.
