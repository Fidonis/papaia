# Naming register

`papaia_kit.names` is the binding register of names in the papaia realm and
stack: audiences, exchange scopes, clients, roles, service accounts, core
services and core networks. Every entry names the repository that owns it.
Realm rendering in the core, the realm conformance check and every module read
names from here instead of spelling them on their own.

## Rules

| Kind | Rule | Examples |
|---|---|---|
| Audience of an MCP server | `mcp-<system>` | `mcp-paperless`, `mcp-wiki`, `mcp-probe-<id>` |
| Audience of a module or core service | `papaia-<module>[-<surface>]` | `papaia-studio`, `papaia-studio-me`, `papaia-prefs`, `papaia-audit` |
| Exchange scope | `aud-<audience>`, built only by `exchange_scope` | `aud-mcp-paperless`, `aud-papaia-data`, `aud-flow` |
| Client | `papaia-<module>[-<surface>]`; resource servers `mcp-<system>` (bearer-only, named like their audience); service account clients `svc-<module>-<purpose>` | `papaia-data-ui`, `papaia-studio-gateway`, `mcp-paperless`, `svc-flow-events` |
| Module role | `<module>-<role>`; `<module>` is one of `studio`, `data`, `flow`, `assist`, `me`, `manager`, `connections`, `prefs` (`ROLE_MODULES`) | `flow-admin`, `data-reviewer`, `prefs-read` |
| Platform role | `papaia-<role>` | `papaia-auditor`, `papaia-confirm` |
| Service account | `svc-<module>-<purpose>` | `svc-flow-events`, `svc-studio-notify` |
| Core service, core network | `papaia-<name>` | `papaia-replay`, `papaia-docker-gate-net` |

Names consist of lower-case ASCII letters and digits in segments joined by
`-`, start with a letter and are at most 64 characters long; an audience at
most 60, so that its exchange scope fits. The OIDC scopes `openid` and
`offline_access` are registered as they are.

Existing names that predate the rules stay valid because they are registered:
the audiences and clients `flow` and `assist-api`, the clients `flow-engine`,
`flow-console`, `flow-cli`, `assist-gate` and `librechat`, the role `user` and
the service accounts `flow-directory` and `flow-control`. A new name that is not
registered must follow the rule of its kind. A role whose prefix is no known
module (`foo-bar`, `wiki-admin`) is rejected; a new module extends
`ROLE_MODULES` in the same change that registers it.

The register also carries the service account `svc-papaia-people` (core person
search and group members, security 1.9) and the client `papaia-kit-testclient`
(owner `papaia-kit`, `test_profile_only = true`). The test client exists only in
the realm of the test profile; the realm sync of the product profile does not
create it, and the realm conformance check of the product profile reports it as
a deviation if it is present (PLT-21-A5).

A client with token exchange is never an audience. The only exception is the
chain holder `papaia-data`. `papaia-data-ui`, `flow-console`, `flow-engine` and
the other exchanging clients are therefore rejected as audiences and as the
audience part of an exchange scope.

## Removed names

| Removed | Use instead |
|---|---|
| `data` | `papaia-data` |
| `aud-data` | `aud-papaia-data` |
| `wiki-mcp` | `mcp-wiki` |
| `aud-wiki-mcp` | `aud-mcp-wiki` |
| `aud-studio` | `aud-papaia-studio` |
| `papaia-flow-console` | `flow-console` |
| `svc-<module>-prefs` | `svc-<module>-notify` |
| scope `flow` | `aud-flow` |

Validation rejects a removed name with an `InvalidName` error whose
`successor` attribute and message name the replacement. The hint always names a
valid name: a scope `aud-<x>` whose audience was replaced by a client that is
never an audience (`aud-papaia-flow-console`) is rejected without a successor.

`wiki-mcp` and `aud-wiki-mcp` have a transition until the end of stage 1
(RE-10, `Removed.until_stage = 1`). `validate` rejects them in every stage, so
no new code uses them. The realm sync and the realm conformance check may keep
the old objects next to `mcp-wiki` while `transitional(name, kind, stage)`
returns the entry, that is in stages 0 and 1; from stage 2 on they are
deviations.

## Keycloak built-in objects

`BUILTIN` lists the objects Keycloak creates in every realm, each with owner
`papaia` and the purpose prefix `built-in, not managed`:

- client scopes `acr`, `address`, `basic`, `email`, `microprofile-jwt`,
  `organization`, `phone`, `profile`, `role_list`, `roles`, `service_account`,
  `web-origins`
- realm roles `offline_access`, `uma_authorization`, `default-roles-papaia`
- clients `account`, `account-console`, `admin-cli`, `broker`,
  `realm-management`, `security-admin-console`

The scope `offline_access` is a built-in scope as well, but it is a registered
scope because the stack grants it on purpose. A realm comparison accepts an
object when `lookup(name, kind)` or `builtin(name, kind)` finds it; built-in
objects are never names to create, and `validate` does not accept them.

## Exchange scope

```python
from papaia_kit.names import exchange_scope

scope = exchange_scope("papaia-studio")  # "aud-papaia-studio"
```

`exchange_scope` takes exactly one audience as a string; a list, set or tuple
is a `TypeError`, so a token request can never ask for two audiences. It is the
only supported way to build `aud-<audience>`; code must not concatenate the
prefix itself. Code that only reads scope names, such as a realm check, tells
an exchange scope by its form with `has_exchange_prefix(name)` instead of
holding the prefix itself.

## Person identifier

The person identifier is `sub`. `person_id` equals `sub` for persons and is
absent for service accounts. `person_id(claims)` applies this rule to verified
token claims: it returns `sub` for a person token and `None` for a service
account token (no session id `sid`, or `azp` is a service account). It rejects a
`person_id` claim that differs from `sub`, a service account token that carries
`person_id` or a session id, a token without `sid` whose `azp` is a registered
client that is not a service account (a person client never issues such a
token; this points to a misconfiguration such as lightweight tokens), and a
missing or malformed `sub`.

## Command line

```sh
uv run --locked papaia-kit names list                      # the register as JSON
uv run --locked papaia-kit names list --kind service-account
uv run --locked papaia-kit names check --kind audience mcp-wiki flow
uv run --locked papaia-kit names scope papaia-studio       # prints aud-papaia-studio
```

`names check` exits with 1 and names the successor of every rejected name.
