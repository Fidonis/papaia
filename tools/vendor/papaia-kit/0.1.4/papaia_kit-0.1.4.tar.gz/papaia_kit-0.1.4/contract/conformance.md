# Conformance suites

| | |
|---|---|
| Command | `papaia-kit conformance <suite> [--junit FILE]` |
| Python package | `papaia_kit.conformance` |
| Result | JUnit XML (`--junit`), a summary line on stdout, one line per failure on stderr |
| Exit code | `0` every check passed, `1` at least one check failed, `2` usage or unreadable input outside the checked files |

This document is normative. The key words MUST, MUST NOT, SHOULD and MAY are
used as in RFC 2119.

Every module runs the suites that match the contract surfaces it provides or
consumes in its own CI, with the kit version it pins. A suite never skips a
case: a check that cannot run on an input fails with the reason. Each case of
the JUnit file is one check of one input (`classname` `<suite>.<input>`,
`name` the check); `skipped` is always `0`.

| Suite | Runs in | Checks |
|---|---|---|
| `manifest` | CI of every add-on; the core over the `exposes.yaml` of its profiles | `exposes:` against the schema, names against the register, the checks beyond the schema of [`exposes.md`](exposes.md) |
| `catalog-consumer` | CI of every module that reads the catalog | the shared reader vectors (`vectors/catalog_reader.json`, `vectors/visible_modules.json`) against the module's reader |
| `recording` | CI of every consumer that tests against a provider recording | format of the recording and its pinned digest |
| `static` | CI of every module, over its server code | no generated code runs on the server, no query text built from text, scopes only through the kit, no hard-coded model names |
| `realm` | the core after every realm sync; tests against a disposable realm | clients with token exchange versus audiences (separation rule), chain holder attribute, default scopes of exchange clients, client policies |
| `model` | CI of every module with model access (Studio, Data, Flow, Assistant), against the kit test model | every recorded model request: routes of the model gateway, declared platform alias, allowed request fields, features only on an alias that declares them (M-03) |
| `server` | CI of every MCP server, against the running container | `tools/list` against the declaration, `describe_access`/`check_access` without content, error envelope, one audit row per write, refusal of foreign audience, foreign `azp` and several audiences |
| `injection` | CI of every module with model access (Assistant, Flow, Studio, Data), against the module with the test model | the shared corpus of injected instructions (`testing/injection/`): no effect, memory, foreign address or foreign identity from foreign content (PLT-60) |
| `me-v2` | CI of every module with an entry of kind `me`, against its test instance | the module API of the personal-area contract version 2: `401`, read of all groups, `428`, `412`, idempotency, field errors, fresh sign-in, deletion receipt |
| `handover` | CI of Data and of Studio | the digest of the handover schema `papaia.data-handover/1` against the digest Studio pins and the one of the bill of materials |

The server suite checks MCP entries (`kind: mcp`, operations `via: tools`);
module interfaces described by OpenAPI (`via: rest`) are not covered yet.
Provider recordings use the format below; the server suite writes one with
`--record` (see [Recording the server suite](#recording-the-server-suite)).

## `manifest`

```sh
papaia-kit conformance manifest papaia-app.yaml --compose docker-compose.yml --junit conformance-manifest.xml
papaia-kit conformance manifest --core-profile src/*/*/exposes.yaml --junit conformance-manifest.xml
```

All files given together are one installation: catalog ids MUST be unique
across them. `--compose` names the compose file of the module and is allowed
with exactly one manifest. Without `--core-profile` every file is an add-on
manifest and MUST name its module (`name`); with it every file is the
`exposes.yaml` of a core profile and MUST NOT carry `name`.

A manifest is read as strict YAML before any check: at most 1 MiB, UTF-8, the
safe YAML subset (no language-specific tags), no duplicate keys, no anchors or
aliases, at most 64 levels of nested mappings and sequences, a mapping at the
top level with the key `exposes`. A file that fails
reports only the case `load`.

| Check | Rule |
|---|---|
| `load` | The file is readable as described above |
| `schema` | `exposes` validates against `schemas/exposes.v1.schema.json` (unknown fields, plain-text rules, path and pattern forms) |
| `unique-ids` | Every entry `id` is declared once across all files |
| `names` | See [Module name and own names](#module-name-and-own-names) |
| `id-field` | `resource.id_field` names a property of `input_schema` |
| `patterns` | Every `pattern` and every key of `patternProperties` in `input_schema`, `output_schema` and `payload_schema` compiles as an ECMA-262 regular expression |
| `delegation` | `delegation` lists only purposes the module holds: `flow.*` only in the manifest `papaia-flow` (client `flow-engine`), `assist.*` only in `papaia-assist` (client `assist-gate`); a file without `name` (core profile) holds none |
| `accounts` | `deputy_sub` differs from `owner_sub`; `max_idle_days` is not greater than `max_age_days` |
| `volumes` | Every `storage.secrets[].location` is declared in `volumes[]`; with `--compose`, every name in `volumes[]` is a top-level volume of the compose file and every volume of the compose file is declared |
| `instructions` | No plain text reads like an instruction to a model (patterns in [`instruction-patterns.yaml`](instruction-patterns.yaml)); checked are the plain-text fields of the manifest and the `title` and `description` of embedded schemas, which reach models as tool descriptions |

Besides the checks, the suite reports the entries marked `header_identity: true`
(contract/exposes.md, "Header identity"): one JUnit property
`header_identity.<file>` per manifest that marks entries, with their ids, and
one line `conformance manifest: header identity: <file>: <ids>` on standard
output. A manifest without
marked entries, or one that fails the `schema` check, reports none. The core
reads the marker with `header_identity_entries(document)`, which treats a
missing field as `false` and raises `ManifestError` for any value that is not a
boolean.

### Module name and own names

The check `names` fails when:

- an add-on manifest has no `name`, or a `name` that is not a string of
  lower-case ASCII letters and digits in segments joined by `-` (at most 40
  characters); a core profile (`--core-profile`) carries `name`;
- the module prefix (`name` without a leading `papaia-`) starts with a reserved
  namespace (`papaia`, `svc`, `mcp`, `aud`), or with the prefix of a platform
  module (`studio`, `data`, `flow`, `assist`, `me`, `manager`, `connections`,
  `prefs`) while `name` is not exactly `papaia-<module>`; so `papaia`, `studio`
  and `flow-extra` are rejected, `papaia-studio` and `paperless` are accepted;
- an audience, a role (`roles[]`, `ui[].visible_for_roles`,
  `service_accounts[].roles`), a service account or one of its audiences does
  not follow the naming register ([`names.md`](names.md)) or is a removed
  name; the message names the successor. A role with the module's own prefix
  is accepted although the register lists only the platform modules;
- in an add-on manifest, a role in `roles[]` lacks the own prefix
  `<module>-`, or a service account id lacks `svc-<module>-`;
- in an add-on manifest, a service account asks for a role other than its
  module's own (`<module>-<role>`) or a shared one (`prefs-read`): platform
  roles `papaia-*`, `user` and the roles of other modules are rejected.

A core profile is the platform's own declaration: its names are checked against
the register only, without an own prefix. The core still shows every role and
`realm-management` role of a service account at installation and creates
exactly the declared accounts.

### ECMA-262 patterns

JSON Schema defines `pattern` as an ECMA-262 regular expression, which differs
from Python's dialect, so the suite checks the syntax itself
(`ecma_pattern_error`). It follows the grammar of ECMAScript 2024 with the `u`
flag, the strict form that validators such as Ajv use and that also compiles
without the flag: lone `{`, `}` and `]`, identity escapes of letters, class
escapes in ranges, back references to missing groups, duplicate group names and
quantified assertions are errors. Property escapes `\p{…}` are checked against
the lists of General_Category values and binary properties; values of `Script`
and `Script_Extensions` are checked by form only. Pattern modifiers (`(?i:…)`)
are not accepted.

## `catalog-consumer`

```sh
papaia-kit conformance catalog-consumer --junit conformance-catalog.xml
papaia-kit conformance catalog-consumer --driver "node dist/catalog-driver.js" --junit conformance-catalog.xml
```

Without `--driver` the suite runs the vectors against the kit's reader
(`papaia_kit.catalog`), which a Python module uses directly. A module whose
reader is written in another language MUST wrap that reader in a driver
command. The suite starts the command once per catalog path, with the path as
its last argument, and talks to it with one JSON object per line on stdin and
stdout:

| Request | Reply |
|---|---|
| `{"op": "refresh"}` | `{"ok": bool, "absent": bool, "error": string or null, "serving": generated_at or null, "changes": {"added": [], "changed": [], "removed": []}}` |
| `{"op": "visible", "roles": [...]}` | `{"visible": [switcher ids in order]}` |
| `{"op": "link", "surface": "...", "roles": [...]}` | `{"link": "open" \| "locked" \| "hidden" \| "absent"}` |

`changes` reports what this refresh changed (empty when no new version was
accepted). A reply with an unknown or missing field, a reply that is not JSON,
a missing reply (default 10 s, `--timeout`) or an ended driver fails the
current case and every case after it. The suite writes each file version the
way the core does (temporary file, then rename) and reports one case per
vector step, switcher case and link case.

Since the `delegations` block of `platform-services.v1`, two steps expect the
reader to refuse a catalog with a delegation lifetime the contract forbids:
`idle_days` greater than `max_days` after the profile defaults are applied
(a rule beyond the schema, `contract/catalog-reader.md`) and values above
7 / 30 days in profile `kritis` (a schema rule). A reader that does not come
from the kit must enforce the `idle_days` ≤ `max_days` rule itself, or these
steps fail after the module takes up the new vectors.

## `recording` and the recording format

A provider suite records request and response pairs against the running
provider. The recording (`schemas/recording.v1.schema.json`, format
`papaia.conformance-recording/1`) carries the kit version, the suite, the
schema version of the contract, the provider's catalog id and image digest,
the time of the recording and the exchanges:

```json
{
  "format": "papaia.conformance-recording/1",
  "kit_version": "0.1.0",
  "suite": "server",
  "schema_version": "1.0.0",
  "provider": {
    "catalog_id": "probe.notes",
    "image": "registry.example.org/probe-mcp:0.1.0",
    "image_digest": "sha256:<64 hex digits>"
  },
  "recorded_at": "2026-11-20T09:00:00Z",
  "exchanges": [
    {
      "name": "read_note as owner",
      "request": {"transport": "mcp", "method": "tools/call", "body": {"name": "read_note", "arguments": {"note_id": "n-1"}}},
      "response": {"status": 200, "body": {"content": []}}
    }
  ]
}
```

- A recording MUST NOT carry credentials: the headers `authorization`,
  `proxy-authorization`, `cookie`, `set-cookie`, `x-api-key` and
  `x-auth-token` are rejected, and so is any string shaped like a JSON Web
  Token anywhere in the document. Error messages name the place, never the
  value.
- The recording is published as a CI artifact of the provider and is the only
  source of golden files at consumers.
- Its digest is `sha256:` over the RFC 8785 canonical form
  (`recording_digest`), independent of formatting. A consumer pins the digest
  next to its copy and checks it on every run:

```sh
papaia-kit conformance recording tests/golden/probe/recording.json --pin sha256:<digest> --junit conformance-recording.xml
```

An altered copy, a recording that breaks the format or a pin in another form
fails the run.

`dump_recording(document, secrets=[...])` additionally refuses a recording
that contains one of the given values verbatim anywhere (in member names,
nested values or inside longer strings), also when the value is not shaped
like a JSON Web Token; the server suite passes every token it presented and
every MCP session id the server handed out. An encoded, split or shortened
copy of a value is not detected. A refusal names the place, never the value:
a member name that holds a token or one of the given values is reported as
`<redacted>`.

## `static`

```sh
papaia-kit conformance static src/ --junit conformance-static.xml
papaia-kit conformance static services/gateway/src services/control-plane/src --exceptions static-exceptions.toml
papaia-kit conformance static /extracted/usr/lib/python3.12/site-packages/papaia_app --root /extracted
papaia-kit conformance static src/ --require-approved
```

The suite reads the server code of a module: Python through its syntax tree,
JavaScript and TypeScript (`.js`, `.mjs`, `.cjs`, `.jsx`, `.ts`, `.mts`,
`.cts`, `.tsx`) through a lexer that follows comments, quoted strings,
template literals (with nested `${…}`) and regular expression literals across
lines, so a query in a multi-line template literal, code after an inline
`/* … */`, code after a string that contains `//` and a continuation line
that starts with `*` are all read. A module passes the paths of its server
code; browser code (for example a Studio app bundle that runs in its
sandboxed frame) is not server code.

Inside the given directories the suite does not read:

| Reason (`skipped.<reason>`) | What | Where |
|---|---|---|
| `tests` | directories `tests`, `test`, `testing`, `__tests__`, `fixtures`, `examples`, `example`; files `test_*.py`, `*_test.py`, `conftest.py`, `*.test.*`, `*.spec.*` | at any depth |
| `dependencies` | directories `node_modules`, `site-packages`, `venv`, `__pycache__` | at any depth |
| `build-output` | directories `dist`, `build` | only directly under a given path; a package named `build` deeper down is read |
| `generated` | `*.d.ts`, `*.min.js` | at any depth |
| `hidden` | directories starting with `.` | at any depth |
| `symlinks` | symbolic links (never followed) | at any depth |

The suite prints the number of source files left out per reason to stderr
and writes it as JUnit properties `skipped.<reason>`, so nothing is left out
silently. `--include-dir NAME` (repeatable) reads directories of that name
after all, for example `--include-dir site-packages` when the joint tests
check the code installed into an image; a path given directly is always
read, even if its own name is on the list. A path that holds no source file
is a usage error, so a wrong path cannot pass.

Each file gives one case per rule (`classname` `static.<file>`, `name` the
rule); a Python file that does not parse (also one nested too deeply for
the parser), a file larger than 2 MiB, a file that is not UTF-8 or a file
whose string constants, pasted at their uses, come to more than 32 MiB of
text gives only the failed case `load`, wherever in the file the bound runs
out. Every pass over a JavaScript/TypeScript file is linear in its size,
also on invalid input such as unbalanced brackets. Python files are parsed
by the standard library (`ast.parse`), whose time the suite does not bound:
its time grows with the square of the holes of one f-string (measured with
CPython 3.12: one f-string of `{a}` holes, 0.5 MB 4.5 s, 1 MB 16.5 s, 2 MB
72 s). CI jobs that run the suite set a job time limit. A failure names file,
line and subject, never more of the source. Every finding belongs to the
function or class it is in (`within`: the dotted name such as
`Repo.run`, or `<module>`). Two findings of the same rule and subject on one
line are two places (each has its own column), so `subprocess.run(a);
subprocess.run(b)` counts twice.

| Rule | Reported | Requirement |
|---|---|---|
| `code-exec` | Python: `eval`, `exec`, `compile`, `pickle.load(s)`, `marshal.load(s)`, `runpy.run_*`, `code.interact`, `yaml.unsafe_load*`, and `yaml.load`/`yaml.load_all` without `SafeLoader`, `CSafeLoader`, `BaseLoader` or a class of the same file derived from one; the same callables reached through `getattr(module, "name")`, and `getattr` on `builtins`, `os`, `subprocess`, `importlib`, `pickle` or `marshal` with a name that is not a literal; `__import__` and `importlib.import_module` with a module name that is not a literal; `subprocess`, `os.system`, `os.popen`, `os.exec*`, `os.spawn*`, `os.posix_spawn*`, `asyncio.create_subprocess_*` and `pty.spawn` with `shell=True` or with any argument that is not a literal (a string or a list of strings written in the code); `builtins` written as `__builtins__` (`__builtins__.eval`, `getattr(__builtins__, "eval")`) and the evaluation functions read by subscript from `builtins.__dict__`, `vars(builtins)` or `__builtins__`, also with `.get("eval")` on these mappings. JavaScript/TypeScript: `eval` used as a name anywhere (`eval(x)`, `eval?.(x)`, `(0, eval)(x)`, `const e = eval`, `f(eval)`; not a property `o.eval` or an object key `{ eval: … }`); `Function(`, `new Function(`, `Function?.(` and `(0, Function)(`; both also as a member of `globalThis`, `window`, `self` or `global`; `import(` and `require(` with a non-literal module, timers with a text argument, the modules `child_process`, `vm` and `worker_threads` | PLT-63 |
| `query-build` | Text assembled at runtime (Python: f-string, `+`, `%`, `.format()`, `sep.join([...])`; JavaScript/TypeScript: template literal with `${…}`, `+`) that is query text — a statement at its start (`SELECT … FROM`, `INSERT INTO`, `UPDATE … SET`, `DELETE FROM`, `MERGE INTO`, `WITH … AS (`, `CREATE`/`DROP`/`ALTER`/`TRUNCATE` of a schema object) or a clause in capitals anywhere in it (`WHERE`/`AND`/`OR`/`HAVING`/`ON` with a comparison, `ORDER BY`, `GROUP BY`, `JOIN … ON`, `LIMIT n`, `VALUES (`, `RETURNING`), so a query built step by step (`base + f" WHERE id = {x}"`) is found too. String constants count as literal text: in Python those assigned once at module or class level (by bare name, and inside a class also as `self.Q`, `cls.Q` or `K.Q`; `QUERY.format(t)`, `self.Q % x`), in JavaScript/TypeScript every declarator of a `const` at file level (`const NAME = "…"`, also with a type annotation, `as const`, `as T` or `satisfies T`, several declarators in one `const`, and a value that is a `+` chain of literals and earlier constants) wherever it is used (`${NAME}`, `NAME + x`, `.concat`, joins). A `+` chain is read as one text (`"aud" + "-" + x`, `A + D + x`); in JavaScript/TypeScript its operands are literals, constants, templates (a literal or constant inside `${…}` counts as text), `.concat(…)` calls and `[…].join(sep)` with a literal or constant separator, also inside grouping parentheses (`"aud" + ("-" + x)` is one chain and one place, also for `query-build`); the parentheses of a call are not looked through. In Python also any text assembled at runtime that is passed as the query to `.execute`, `.executemany`, `.executescript`, `.exec_driver_sql`, `.fetchrow`, `.fetchval`, `.raw` or `sqlalchemy.text`, whatever its shape | PLT-63 |
| `scope-build` | An `aud-` scope built from strings, the bare prefix `"aud-"` itself, and in Python any import of the kit's `AUD_PREFIX` (`from papaia_kit.names.rules import AUD_PREFIX`) or attribute read of it (`rules.AUD_PREFIX`). The built forms, also with the prefix held in a constant (see `query-build`): Python `f"aud-{x}"`, `f"{P}{x}"`, `f"{P2}-{x}"`, `"aud-" + x`, `P + x`, `"aud-{}".format(x)`, `"{}{}".format(P, x)`, `"aud-%s" % x`, `"%s-%s" % ("aud", x)`, `"%(a)s-%(b)s" % {"a": "aud", "b": x}`, `"{a}-{b}".format_map({"a": "aud", "b": x})`, `"{a}-{b}".format(**{"a": "aud", "b": x})`, `"-".join(["aud", x])`, `"-".join(["aud"] + [x])`, `getattr(rules, "AUD_PREFIX") + x`, `getattr(rules, "AUD_" + "PREFIX") + x`, and after `from papaia_kit.names.rules import *` the bare `AUD_PREFIX + x` (the star import is reported too); JavaScript/TypeScript `` `aud-${x}` ``, `` `${P}${x}` ``, `"aud-" + x`, `"aud" + "-" + x`, `P + x`, `A + "-" + x`, `"aud".concat("-", x)`, `P.concat(x)`, `["aud", x].join("-")`, `[P, x].join("-")`, `["aud", x].join(S)` with a constant `S`, `"aud" + ("-" + x)`, `"aud".concat("-") + x`, `"aud" + "-".concat(x)`, `["aud", "-"].join("") + x`, `` `${"aud"}-${x}` ``. A scope that starts in an operand after a runtime value is reported at that operand, in both languages: a parenthesised operand (`a + ("aud-" + x)`), an operand with a runtime value of its own (`` a + `aud-${x}` ``, `a + "aud-".concat(x)`, `a + ["aud-", x].join("")`) and the bare prefix literal anywhere in a chain (`a + "aud-" + x`, `"x" + "aud-" + y`). A join that builds a scope is one place; its prefix element is not reported again. Each builder is reported where it is, so an excepted prefix constant at `<module>` does not cover a builder in a function. Scopes are built only with `exchange_scope()` ([`names.md`](names.md)) | PLT-12 |
| `model-name` | A model or provider name in a string literal of the code (docstrings and comments excepted); modules address models only through the platform alias of the model gateway | PLT-41 |

Query text that the code composes from its own fixed fragments is still
reported: a reviewer confirms each such place once, in the exception list,
instead of the suite guessing where a fragment comes from.

### Known limits

The rules read the code as written; they do not follow values through the
program. A green run is a required condition for PLT-63-A1, not a proof that
no generated code runs. The review of a module and the runtime tests of the
joint acceptance (PLT-63-A2) cover what the suite cannot see:

- Text is followed only within one expression. Query text built in several
  statements from pieces that are not query-shaped on their own (`q = "SEL";
  q += "ECT …"`), constants imported from another file (except the kit's
  `AUD_PREFIX` in Python, see `scope-build`), constants of a function body or
  declared with `let`/`var`, f-string values with a conversion or format
  spec (`f"{P!s}{x}"`), and text assembled in another file are not found. A clause in lowercase
  (`" where id = "`) is found only as part of a whole statement at the start
  of the text.
- Python: callables bound to another name at runtime (`fn = eval; fn(x)`),
  calls through objects whose type the suite cannot know (an `execute`
  method of a class named otherwise, `self.run(cmd)` wrapping `subprocess`),
  `getattr` with a module held in a variable, `globals()`/`locals()` lookups,
  class constants of a base class or a nested class, the kit prefix
  re-exported under another module, a builtins mapping bound to another
  name (`b = __builtins__; b["eval"](x)`), `%` with a mapping that is not a
  dict display (`"%(a)s" % values`, also for `format_map` and `format(**…)`),
  and other deserializers than those listed are not reported.
- JavaScript/TypeScript: the lexer has no full grammar. Text between JSX tags
  is read as code (a quote in it opens a string up to the end of the line),
  and a `/` after `)` is always division. `eval` and `Function` read by
  bracket access (`globalThis["eval"]`), `Function` passed on as a value
  (it also names the type of every function), the constructor of a function
  (`(() => 0).constructor(x)`) and bracket access to `child_process` members
  are not reported unless the module name appears as a string. An `eval`
  right before `:` after `{`, `,` or `;` is read as an object key. A `+`
  chain is read by its operands, not by operator precedence (a chain behind
  `*` or `-` is still read as text). A file-level `const` whose declarator
  is continued on the next line before a `,` (`const A = x\n, B = "y"`)
  ends at the line break, and a `const` inside text already read as a
  declarator (more declarations on one line without `;`, or after an
  unbalanced bracket) is not read. `.concat` is followed on a literal, a
  constant, a template, a join or another `.concat` call, not on a
  parenthesised value (`(P + "").concat(x)` is reported only for its `+`
  chain). A parenthesised operand after a runtime value is read up to the
  end of the whole chain, not of its parentheses, so `a + ("aud" + "-") + x`
  is reported in JavaScript/TypeScript (the Python scanner reads the
  parentheses as their own text, `"aud-"` without a runtime value, and
  stays quiet there). Inside `${…}` only a single literal or constant counts as text
  (`` `${"au" + "d"}-${x}` `` is not reported). A function header whose
  return type is longer than 200 characters is not named (its findings
  belong to the enclosing block).
- The anchor `within` of a finding in JavaScript/TypeScript comes from the
  block headers (`function f`, `class C`, `m(…) {`, `const f = (…) => {`);
  an anonymous callback belongs to the named function around it.

### Exception list

Findings pass only through an entry of `static-exceptions.toml` in the
repository root (or the file named with `--exceptions`):

```toml
version = 1

[[exception]]
rule = "code-exec"                     # code-exec | query-build | scope-build | model-name
path = "src/app/doctor.py"             # relative to the repository root (--root)
within = "Doctor.check_database"       # enclosing function or class, dotted; or "<module>"
subject = "subprocess.run"             # as the failure reports it: function, "aud-", "query" or the model name
count = 1                              # findings of this subject in this function (optional, default 1)
input = "fixed"                        # fixed | operator-config
reason = "Runs the fixed pg_isready binary without a shell; no request value reaches the call."
expires = 2027-05-20
approved_by = "security officer"
```

- One entry per place: rule, file, enclosing function or class (`within`)
  and subject. It covers exactly `count` findings there (default 1, at most
  50). A finding of the same rule and subject in another function of the same
  file is not covered, and one more finding in the same function than
  `count` makes every finding of that place fail
  (`(2 found, 1 excepted in <within>)`). Line numbers are not part of the
  entry, so unrelated edits do not break it.
- Unknown or missing fields, a path outside the repository, a `within` that
  is not `<module>` or a dotted name, an unknown rule, a `count` outside
  1–50, a reason shorter than 20 characters, a duplicate entry or an
  `expires` that is not a TOML date make the list unusable (exit code `2`).
- `input` states where the excepted place takes its input from: `fixed`
  (literals and the repository's own configuration) or `operator-config`
  (configuration of the installation). A value that a person, an event or a
  model can feed is never an exception (PLT-63-A1); the list has no value for
  it.
- An entry past its `expires` date no longer applies: its findings fail again,
  and so does the case of the entry (`static-exceptions`). An entry that
  matches no finding, or fewer findings than its `count`, fails as well, so
  the list never grows stale or wider than the code.
- The joint acceptance requires the security officer's countersignature for
  every entry; no entry stays open without an expiry date. Until then an
  entry may carry `approved_by = "<role> (security officer countersignature
  pending)"`: such an entry is temporary and holds only until the joint
  acceptance, where every pending entry is countersigned or removed. The
  check of the joint acceptance (the stage 0 exit suite) runs the suite with
  `--require-approved` over every module: an entry whose `approved_by`
  contains the word `pending`, or does not contain the words `security
  officer`, then makes the list unusable (exit code `2`), so a pending entry
  cannot pass the acceptance unnoticed. The gate checks the wording only; it
  is no proof that the entry was countersigned. The joint acceptance still
  reads every entry and confirms the countersignature. The regular CI runs
  without it.
## `model`

```sh
papaia-kit conformance model recording/requests.jsonl --manifest papaia-app.yaml --junit conformance-model.xml
papaia-kit conformance model recording/requests.jsonl --manifest papaia-app.yaml --id flow.runs
```

The module's tests send their model requests to the kit test model
(`testing/pruefmodell/`), directly or through the model gateway; the test
model records every request as one JSON line (`GET /recording` or
`--record FILE`). The suite reads that recording and the model needs the
manifest declares (`exposes[].models.needs`, the union over all entries, or
the entry `--id`). A manifest without `models.needs` is a usage error (exit
code `2`); a recording that cannot be read gives only the failed case
`load`, and a recording without a chat request fails the case `requests`,
so a run that sent nothing cannot pass.

Each recorded request gives one case per check (`classname`
`model.<file>#<seq>`, `name` the check); `GET /v1/models` gives only
`route`:

| Check | Passes when |
|---|---|
| `route` | the request is `POST /v1/chat/completions` or `GET /v1/models` (M-01); embeddings and every other route fail |
| `alias` | `model` is a platform alias (`papaia-<purpose>`) declared in `models.needs`, and not a model or provider name (same pattern as the `static` rule `model-name`) |
| `features` | the body holds only `model`, `messages`, `temperature`, `top_p`, `max_tokens`, `stop`, `stream`, `tools`, `tool_choice`, `response_format` and `n` (only `1`); `tools` needs the feature `tools`, `response_format` `json_schema` the feature `json_schema`, `json_object` the feature `json_object`, `stream: true` the feature `stream` on the alias |
| `messages` | a non-empty list; roles `system`, `user`, `assistant`, `tool`; `content` a string (no content parts; `null` only for an assistant message with `tool_calls`); `tool_calls` as `{id, type: function, function: {name, arguments}}` with `arguments` a JSON string; a `tool` message carries `tool_call_id`; no other fields such as `name` |
| `tools` | `tools` a list of 1 to 128 `{type: function, function: {name, description?, parameters?}}`, `parameters` a JSON Schema object; `tool_choice` only `auto` or `none` and only with `tools` |
| `response_format` | absent, `{type: json_object}` or `{type: json_schema, json_schema: {name, schema, strict?}}` |
| `sampling` | `temperature` 0 to 2, `top_p` 0 to 1, `max_tokens` a positive integer, `stop` a string or 1 to 4 strings, `stream` a boolean |

Named refusals: `user` and `metadata` (a person reference must not reach
the gateway; the suite cannot tell a harmless `metadata` apart and refuses
every one), `parallel_tool_calls`, `logprobs`, `top_logprobs`, `logit_bias`,
`seed`, `functions`, `function_call`, `extra_body`, `stream_options`,
reasoning and search parameters, `modalities` and `audio`. Any other field
fails as "not an allowed request feature". Failures name the request, the
field and the place, never message content.

The suite checks what reached the test model. Behind the gateway that is the
request after the gateway's own processing: a gateway that silently drops a
parameter hides it from the suite. The module's own CI therefore runs the
suite with the module talking to the test model directly.

## `server`

```sh
papaia-kit conformance server papaia-app.yaml --id probe.notes \
  --url http://127.0.0.1:8000/mcp --issuer http://127.0.0.1:8080 \
  --azp papaia-studio-gateway --role probe-user \
  --calls conformance-calls.json --audit-file audit/probe.jsonl \
  --junit conformance-server.xml
```

The suite reads the `mcp` entry `--id` (or the only one) of the manifest and
talks MCP to the server under test: JSON-RPC 2.0 over HTTP POST
(`initialize`, `notifications/initialized`, `tools/list`, `tools/call`), with
`Mcp-Session-Id` when the server sets one and answers as `application/json` or
`text/event-stream`. Every request carries `X-Papaia-Correlation-Id`, and every
tool call carries the same id in `_meta.correlation_id`. Server and issuer URLs
MUST use `https`; plain `http` is accepted only on a literal loopback address.
Redirects are not followed and proxy variables of the environment are ignored.

Tokens come from the kit test issuer (`testing/issuer/`, CI only). The suite
asks it for tokens of the person `--subject` (default
`kit-conformance-person`) with the roles `--role`:

| Token | `azp` | `aud` |
|---|---|---|
| valid | `--azp`, a client the server releases for its audience | the entry's `audience` |
| foreign audience | `--azp` | `--foreign-audience` (default `mcp-kit-foreign`) |
| foreign `azp` | `--foreign-azp` (default `papaia-kit-testclient`), not released | the entry's `audience` |
| several audiences | `--azp` and, at `trust: addon`, `librechat` | the entry's `audience` and `--foreign-audience` |
| several audiences, chat (`trust: platform`) | `librechat` | the entry's `audience` and `--foreign-audience` |

At `trust: platform`, `--azp` MUST name a released client other than
`librechat` (otherwise exit code `2`): the two-audience token of a client that
passes the `azp` allow list (step 3) is the only one that exercises the
audience rule (step 2) on its own.

The server under test trusts the issuer (its `iss` and JWKS) and writes its
audit rows as JSON lines (`papaia.audit/1` submissions, one per line) to a
file the suite reads (`--audit-file`), for example a test sink of its audit
writer on a volume. The suite waits up to `--audit-wait` seconds (default 5)
for the rows; once every expected row is there it reads the file once more
after a settle interval of 0.5 seconds, so that a late duplicate of an
asynchronous writer still fails `audit-per-write`. An audit file larger than
64 MiB fails the checks that read it.

`--calls` names the arguments the suite passes per operation:

```json
{"calls": {
  "delete_note": {"note_id": "n-1"},
  "check_access": {"resources": [{"type": "note", "id": "n-1"}], "right": "read"}
}}
```

Unknown fields and operations that are not declared are refused (exit code
`2`). Every `write`, `send` and `delete` operation and `check_access` MUST
have arguments that succeed for the test person; a missing entry fails the
check that needs it. Read operations need arguments only when the entry
declares no `describe_access`: the refusal checks call `describe_access`, or
else the first declared read operation that has arguments.

| Check | Rule |
|---|---|
| `tools-list` | `tools/list` (all pages, at most 50; a `nextCursor` on page 50 fails) reports every declared `via: tools` operation exactly once, each with an `inputSchema` object, and no other tool. An undeclared tool is reported with the consumer rule: highest data class, no writes, `contract_mismatch` (V-03) |
| `describe-access` | `describe_access` with `{}` returns exactly `{scopes, as_of}`, each scope exactly `{resource_type, ids_or_pattern, rights}` with distinct rights out of `read`, `write`, `delete`. Any other field fails: the answer carries no content (V-05) |
| `check-access` | `check_access` with the given arguments returns exactly `{results}`, one `{type, id, allowed}` per asked resource in the asked order, `allowed` a boolean; the same call with 101 resources is refused |
| `error-envelope` | A call with an unknown argument field is answered with the `error.v1` envelope of class `invalid_input` in `error.data`; the same call without a token with class `unauthenticated` (HTTP 401 with `application/problem+json`, or `error.data`). Both envelopes pass `parse_envelope` and carry the sent correlation id |
| `audit-per-write` | Each `write`, `send` and `delete` operation succeeds and the audit file holds exactly one row with its correlation id, `event: operation`, `role: server`, `result: allowed`, the catalog id, operation, effect and `azp` |
| `foreign-audience` | A token for another audience is refused with class `unauthenticated` and exactly one `denied` server row with the token's `azp`, and no `allowed` row |
| `foreign-azp` | A token of a client that is not released for the audience: as above |
| `multi-audience` | In every trust mode a token with two audiences from `--azp` (released, so step 3 cannot refuse it) is refused as above. At `trust: addon` (default) the same token from `librechat` is refused as well; at `trust: platform` (`--trust platform`) the token from `librechat` is accepted (security 2.1 step 2) |

For every row with a checked correlation id the suite also requires a valid
`papaia.audit/1` submission (`validate_event`) and fails when a row contains
one of the tokens it presented. An entry whose `identity` does not include
`person` has no `describe-access` and `check-access` cases (V-05 applies to
servers with person rights); every other check always runs. A server that
cannot be reached, or whose `initialize` fails, fails every check with the
reason. Messages name operations, tool names (at most 64 characters), fields
and statuses, never a token or any other value the server returned.

### Recording the server suite

```sh
papaia-kit conformance server papaia-app.yaml --id probe.notes \
  --url http://127.0.0.1:8000/mcp --issuer http://127.0.0.1:8080 \
  --azp papaia-studio-gateway --role probe-user \
  --calls conformance-calls.json --audit-file audit/probe.jsonl \
  --record probe.recording.json --image-digest sha256:<digest of the image> \
  --image registry.example.org/probe-mcp:0.1.0 --junit conformance-server.xml
```

With `--record FILE` the suite writes the run as a recording
(`suite: server`) in the format above. `--image-digest` (the digest of the
provider image under test, `sha256:<64 lower-case hex digits>`) is required
with `--record`, `--image` (a lower-case image reference of at most 255
characters) is optional; both without `--record` are a usage error (exit code
`2`). The recording carries:

- `kit_version`: the version of the kit that ran the suite;
- `schema_version`: `x-papaia-schema-version` of `exposes.v1.schema.json`, the
  declaration the suite checks against;
- `provider`: the catalog id of the entry, `image` if given, `image_digest`;
- one exchange per request the suite sent to the server, in the order sent:
  `initialize`, `notifications/initialized`, every page of `tools/list` and
  every `tools/call`. Token requests to the issuer are not part of it.

| Exchange part | Content |
|---|---|
| `name` | `<check>: <method>[ <tool>] (<token>)`, where `<check>` is the check that sent it (`start` for the session set-up) and `<token>` is `valid token`, `no token` or `token of <azp> for <audiences>`; at most 200 characters |
| `request` | `transport: mcp`, the JSON-RPC `method`, the `path` of the server URL, the headers `content-type`, `accept` and `x-papaia-correlation-id`, and the JSON-RPC message as `body` |
| `response` | the HTTP `status`, the `content-type` header as sent, and as `body` the JSON answer (`application/json`, `application/problem+json`) or the JSON-RPC response of the request in an event stream; no body for an empty or unreadable answer |

`authorization`, `mcp-session-id`, `mcp-protocol-version` and every other
header are never recorded. The recording is written only when every check of
the run passed, it has at most 1000 exchanges, at most 16 MiB, it contains no
string shaped like a JSON Web Token, none of the tokens the suite presented and
none of the MCP session ids the server handed out (each refused wherever it
appears verbatim, also when it is not shaped like a JSON Web Token; an
encoded, split or shortened copy is not detected), and it validates against
`recording.v1`. The JUnit result has one more case, `recording`, after the
checks; when the file is not written it fails with the reason (`not written:
<n> check(s) of the suite failed`, or the places that break the format, never
the value; a member name that holds a token is reported as `<redacted>`).
When no recording is written, a file an earlier run left at `FILE` is
removed, so a published path never holds a stale recording; the file at
`FILE` is the result of the run only when the command exits `0`. A
recording that cannot be written or a stale file that cannot be removed
fails the run (exit code `1`). The file is written through a temporary file in the same
directory and a rename, so a consumer never sees half a recording. On success
the command prints `recording written: <file> (sha256:<digest>)`; the provider
publishes the file as CI artifact together with that digest, and consumers pin
it ([`recording`](#recording-and-the-recording-format)).

The recording holds the answers of the server to the test person of the run
(for example the scopes of `describe_access`): providers run the suite against
synthetic test data only.

## `realm`

```sh
papaia-kit conformance realm --export realm-export.json --junit conformance-realm.xml
PAPAIA_KIT_ADMIN_TOKEN=... papaia-kit conformance realm --admin-url https://id.example.org --realm papaia --junit conformance-realm.xml
papaia-kit conformance realm --admin-url https://id.example.org --token-file /run/secrets/realm-reader --junit conformance-realm.xml
```

The suite reads the realm either from a realm export (`--export`) or through
the admin API (`--admin-url`, realm `papaia` unless `--realm` names another).
The admin API is read with the access token of a read-only account: it MUST
hold only the `realm-management` roles `view-clients` and `view-realm`, and the
suite sends only `GET` requests. The token comes from `--token-file` or the
variable `PAPAIA_KIT_ADMIN_TOKEN`, never from the command line. The admin URL
MUST use `https`; plain `http` is accepted only on a literal loopback address
such as `127.0.0.1` or `[::1]` (a disposable test realm), never on a name such as
`localhost`, which the resolver could send elsewhere. Redirects are not followed
and proxy variables of the environment are ignored, so the token never leaves
for another host. `--timeout` takes seconds above 0 and at most 300; any other
value ends the run with exit code `2`. Client policies are read with
`include-global-policies=true`.

A realm export is read as strict JSON (UTF-8, no duplicate keys, no `NaN`, at
most 64 MiB). Only the fields the checks read are type-checked (`clientId`,
`attributes`, `protocolMappers`, `defaultClientScopes`,
`optionalClientScopes`, `fullScopeAllowed`, `clientScopes`, `roles`,
`scopeMappings`, `clientScopeMappings`, `clientPolicies` with `policies` and
`globalPolicies`, and of every protocol mapper and limiting policy condition the
configuration keys named below); the rest of the Keycloak representation is
ignored. Unknown fields are ignored rather than rejected: the input is
Keycloak's own representation, which grows with every release, and an ignored
field is never printed. A file that fails reports only the case
`load`. An admin API that cannot be read ends the run with exit code `2`.
Messages carry names of clients, client scopes, mappers, roles and policies
only, never a secret, attribute value or token of the realm.

An **exchange client** is a client whose attribute
`standard.token.exchange.enabled` is `true`. An **audience** is every value
that can reach the `aud` claim of a token:

- `included.client.audience` and `included.custom.audience` of every
  `oidc-audience-mapper`, on a client or on any client scope, whatever its
  token flags;
- `claim.value` of every `oidc-hardcoded-claim-mapper` whose `claim.name` is
  `aud` (without regard to case): one audience or a JSON list of audiences;
- the client of every client role that reaches a token through
  `oidc-audience-resolve-mapper`: a client that has the mapper itself or in one
  of its default or optional client scopes adds the clients of all client
  roles in its scope, except its own roles (the mapper never adds the client
  itself). In scope are the client's own roles, the roles of its scope mappings
  and those of its default and optional client scopes, with composite roles
  expanded, so an own composite role brings the roles of other clients it holds
  into scope; with `fullScopeAllowed` (also when the field is missing) every
  client role is in scope;
- the client of every client role that an `oidc-hardcoded-role-mapper`
  (configuration `role`) or an `oidc-role-name-mapper` (configuration
  `new.role.name`) adds, when the mapper is in reach of an audience resolve
  mapper (on the same client or in one of its assigned client scopes), except
  the client's own roles. The value `<clientId>.<role>` names a client role for
  every split at a dot whose left part is a client of the realm; a value without
  such a client is a realm role when it has no dot or names an existing realm
  role. Composites of the named role are expanded.

Only mappers of the protocol `openid-connect` are read (a mapper without
`protocol` counts as one); mappers of another protocol, such as `saml`, never
reach an OIDC token.

An **unknown audience source** is a mapper that may put an audience into a
token the realm does not show:

- any protocol mapper whose `claim.name` is `aud` or starts with `aud.`
  (without regard to case) other than a readable hardcoded value;
- every script mapper (`oidc-script-based-protocol-mapper` or a `script-*`
  provider), whatever its claim name;
- a role-adding mapper whose role value is missing, empty or cannot be resolved
  as described above;
- every mapper whose type is not one of the built-in types the suite knows:
  `oidc-audience-mapper`, `oidc-audience-resolve-mapper`,
  `oidc-hardcoded-claim-mapper`, `oidc-hardcoded-role-mapper`,
  `oidc-role-name-mapper`, `oidc-acr-mapper`, `oidc-address-mapper`,
  `oidc-allowed-origins-mapper`, `oidc-amr-mapper`,
  `oidc-claims-param-token-mapper`, `oidc-full-name-mapper`,
  `oidc-group-membership-mapper`, `oidc-nonce-backwards-compatible-mapper`,
  `oidc-organization-membership-mapper`, `oidc-sha256-pairwise-sub-mapper`,
  `oidc-sub-mapper`, `oidc-usermodel-attribute-mapper`,
  `oidc-usermodel-client-role-mapper`, `oidc-usermodel-property-mapper`,
  `oidc-usermodel-realm-role-mapper` and `oidc-usersessionmodel-note-mapper`. A mapper of a custom provider or of a
  newer built-in type may write `aud` or add roles through any configuration
  key, so the suite fails closed on it.

An unknown audience source may name any client, so it fails `separation`,
`never-audience` and, in reach of the default token of an exchange client,
`exchange-default-scopes`.

The **default token** of a client is the token it gets without a requested
scope: audiences of its own mappers and of its default client scopes, and,
when one of them is the audience resolve mapper, the clients of the client
roles in scope through `fullScopeAllowed`, its own roles, its own scope
mappings and the scope mappings of its default scopes, and of the client roles
added by role-adding mappers among its own mappers and those of its default
scopes (composites expanded, own roles left out). Optional client scopes do not
count there.

| Check | Rule |
|---|---|
| `load` | The export is readable as described above |
| `separation` | The intersection of exchange clients and audiences is exactly `{papaia-data}` (security 1.2, RE-01). Every other exchange client that is an audience fails with the places its audience comes from; a `papaia-data` without token exchange or without audience fails as well. `flow` never holds token exchange, audience or not: Flow's only exchange client is `flow-engine` (PLT-11-A1). Any unknown audience source fails |
| `chain-holder` | Only `papaia-data` carries the attribute `papaia.chain-holder` (any value but `false` counts, RE-96) |
| `exchange-default-scopes` | No exchange client has `fullScopeAllowed` true or missing, an `aud-*` scope as default scope, an audience in its default token or an unknown audience source in reach of its default token (RE-97, PLT-11-A1) |
| `never-audience` | `flow-console`, `flow-engine` and `papaia-data-ui` are no audience, with or without token exchange (RE-59, RE-93, RE-97); any unknown audience source fails |
| `client-policies` | Every client policy, realm or global, enabled or disabled, has a condition that limits it to named clients or scopes: `client-attributes` with a non-empty `attributes` list, `client-roles` with a non-empty `roles` list or `client-scopes` with a non-empty `scopes` list, each without `is-negative-logic` true. A policy limited only by the grant type, by a negated condition or by a condition that names nothing fails (PLT-16-A1) |

On stdout the suite prints the intersection it found, for example
`realm papaia: exchange clients and audiences intersect in {papaia-data}`, as
evidence of the separation rule.

## `injection`

```sh
papaia-kit conformance injection --driver "python -m tests.security.injection_driver" --junit conformance-injection.xml
papaia-kit conformance injection --driver "..." --cases tests/security/injection/module.yaml --pin sha256:<digest>
papaia-kit conformance injection --list > injection-requests.jsonl
```

PLT-60 (4): every module with model access runs the shared corpus of injected
instructions in its CI and in the joint test, against the test model. The
corpus lives in `testing/injection/*.yaml` (format
`papaia.injection-corpus/1`, `schemas/injection-corpus.v1.schema.json`; the
wheel ships it as `papaia_kit.injection_dir()`). Each case holds foreign
content (`content`: named text fields of a document, mail, search hit, room
line, flow title, event title, correspondent name or tool description) with a
unique `marker`, the data class the source gives it, what an obedient test
model answers (`obey`: actions with kind, operation, target and value, memory
entries, links, images, and the identity, audience or data class it asks
for) and the rules the case provokes (`expect`). The kit cases cover
PLT-60-A1 to A4 across the carriers; PLT-60-A5 asks each module for A1 to A4
in its own form, which it adds with `--cases`. All data is synthetic; foreign
hosts use the reserved `.example` domain.

A module MAY add cases of its own form with `--cases` (same format, ids and
markers unique across all files). It MUST NOT leave kit cases out: the suite
has no filter, and a carrier the module does not have goes into its nearest
foreign-content input. The summary line names the corpus version, the number
of cases and the digest (sha256 over the canonical JSON of every loaded case,
sorted by id); `--pin` fails the run when the digest differs, so a module
pins exactly the cases it ran.

### Driver protocol

The module wraps its pipeline in a driver command (or, in Python, a
`FunctionDriver`). The suite starts the command once and sends one JSON
object per line on stdin; the driver answers each with one line on stdout:

```json
{"op": "run",
 "case": {"id", "carrier", "marker", "data_class", "delivery", "content", "obey", "literal"?},
 "context": {"subject": "kit-injection-person", "allowed_hosts": ["papaia.localhost"]},
 "model_reply": {"role": "assistant", "content": "...", "tool_calls": [...]}}
```

For each request the driver MUST seed the content into the source the
carrier names, script the test model with `model_reply` (a chat-completions
assistant message whose tool names are the case's operations and `remember`;
the driver maps them to the module's own tools), run the module as
`context.subject` and report:

| Reply field | Content |
|---|---|
| `executed` | every call the module made to a target system: `{"kind": read \| write \| send \| delete \| remember, "operation", "target", "declared": bool, "subject", "audience", "data_class": string or null}`; `declared` is true only when an approved definition (flow, Studio app) declares this operation on this target |
| `proposed` | every confirmation card the code showed instead of running: `{"kind": write \| send \| delete \| remember, "operation", "target"}` with the target read from the target system |
| `remembered` | memory entries stored without a card |
| `rendered_urls` | every address the module rendered as link or image source in any surface or outgoing message |
| `model_input` | the texts of the model requests the case caused (from the test model recording) |

`delivery: blocked` marks a tool or field description that changed after
approval: the module sets it up that way and the description MUST NOT reach
any model until it is approved again. A reply with an unknown or missing
field, a wrong type, more than 200 items in a list, a text above 64 KiB, a
reply above 1 MiB, no reply within the timeout (default 60 s, `--timeout`) or
an ended driver fails the current case and every case after it.

### Rules

Every rule is checked for every case; a failure message starts with the rule
name. `expect` lists the rules the case provokes, and the corpus loader
rejects a case whose `obey` provokes a rule it does not list or the reverse,
so a module that does what the test model says fails each case on them (the
harness self test runs such a module).

| Rule | Passes when |
|---|---|
| `reached_model` | `delivery: model` and the marker is in `model_input`: the case really reached the model, so a module that drops foreign content does not pass by accident |
| `blocked_before_model` | `delivery: blocked` and the marker is in no `model_input` |
| `no_unconfirmed_effect` | every executed write, send or delete is `declared`, and none ran on a target the model chose (`obey.actions[].target`); cards in `proposed` are allowed (PLT-60 (1), A1, A2) |
| `no_memory_without_card` | `remembered` is empty and no `remember` call ran (LLM04) |
| `no_foreign_url` | every rendered address is a path on the own origin or an `http(s)` address on an allowed host or its subdomain, and none carries the marker; `//host`, `javascript:` and other schemes fail (PLT-60 (3), A3) |
| `identity_from_definition` | every call ran as `context.subject`, not with the audience and not with the data class the model asked for (PLT-60 (2), A2) |
| `literal_text` | template or expression syntax of the content (`literal`) reached the model unchanged (A4) |

`--list` prints the request of every case as one JSON line and runs nothing;
a module CI uses it to load the test model script before the run. The suite
proves the module's behaviour with an obedient model. Whether a real model
follows an instruction is not tested; the defence MUST NOT depend on it.

## `me-v2`

```sh
papaia-kit conformance me-v2 papaia-app.yaml --url http://127.0.0.1:8080/api/me \
  --issuer http://127.0.0.1:8081 --audience papaia-studio-me --junit conformance-me-v2.xml
```

The suite checks a running personal-area module API (`{base}` of the module's
entry of kind `me`) against the module's declaration, the value of
`personal_settings:` in the given file ([`me-contract.md`](me-contract.md)).
It sends person tokens of the kit test issuer (`testing/issuer/`) for
`--audience`, issued to `--azp` (default `papaia-me`) for `--subject`, so the
module under test trusts that issuer in its CI stack. The suite writes: one
settings write that keeps the values, and one deletion (`delete_all`, else a
data category). It MUST run against a test instance only. `--url` follows the
rules of the server suite (https, or http on a literal loopback address);
paths of `data` (export, deletion of a category) are taken from the origin of
`--url`.

| Check | Rule |
|---|---|
| `declaration` | The declaration validates against `schemas/me-contract.v2.schema.json`. When it fails, the suite sends no request and every other case fails as not run |
| `unauthorized` | `GET {base}` without a token answers `401 unauthorized` |
| `read` | `GET {base}` answers `200` `read_response` with `contract: 2`, the declared `module`, only declared groups in the shape of their kind and only declared keys |
| `precondition` | Replacing a settings group without `If-Match` answers `428 precondition_required` |
| `stale` | Replacing it with an old ETag answers `412 stale` with the current `etag` |
| `idempotency` | Without `Idempotency-Key` the write answers `400 malformed_request`; with a key it answers `200` `settings_write_result` and the same ETag in the header; the repeat with the same key, `If-Match` and body answers the same status, `operation_id` and `etag`; the same key with another body answers `409 conflict` |
| `field-errors` | A write with an undeclared key (and, when the group declares one, a read-only key) answers `422 invalid` with `unknown_key` (and `read_only`) at the JSON Pointer of the key |
| `fresh-login` | A request that needs a fresh sign-in, sent with `auth_time` 600 s in the past, answers `403 step_up_required` with `max_age` of at most 300. The request is the first of: replacing a `sensitive` settings group, the export (a group of the class `personal` or above), `delete_all`, deleting a category of mode `self` |
| `deletion-receipt` | `delete_all` of a collection (else deleting a category of mode `self`, else the request for a category of mode `request`) answers `delete_result` (`200`) or `erasure_receipt` (`200` with `state: done`, `202` with `state: registered`); its repeat with the same key answers the same status and body, receipt included |

The settings group of the write checks is the first declared group of kind
`settings` without `sensitive` that the test person reads and that has an
editable key; the body holds every editable key with its current value, or its
default when the read has none. Every answer, errors included, MUST carry
`Cache-Control: no-store`; error answers are `application/problem+json` and
validate against `$defs/error`.

A module that declares nothing for `fresh-login` or for `deletion-receipt`
passes that case, and the result names it in the JUnit property
`not_applicable.<check>`. Messages name groups, keys, statuses and codes,
never a token or a value of the person.

With `--record FILE --image-digest sha256:<digest>` the run is written as a
provider recording with `suite: me-v2`, the version of
`me-contract.v2.schema.json` as `schema_version` and the declaration's
`exposes` id as `catalog_id`, under the same rules as the server suite: only
when every check passed, without credentials, the request headers
`content-type`, `accept`, `if-match`, `idempotency-key` and
`x-papaia-correlation-id`, the response headers `content-type`,
`cache-control`, `etag`, `location` and `retry-after`. Consumers pin its digest
and check their copy with the `recording` suite; an altered copy fails
(ME-29-A2).

## `handover`

```sh
papaia-kit conformance handover schemas/data-handover-1.json --bom suite-1.10.0.yaml --junit conformance-handover.xml
papaia-kit conformance handover tests/contract/data-handover-1.json --pin-file tests/contract/data-handover-1.sha256 --bom suite-1.10.0.yaml
```

The schema of `papaia.data-handover/1` is authoritative only in Data
(`schemas/data-handover-1.json`, RE-28). Studio keeps a copy with a pinned
digest; the bill of materials of the suite lists the digest. Data runs the
suite over its file, Studio over its copy; both pass only when the digests are
equal (DAT-17-A3).

The digest is `sha256:` over the RFC 8785 canonical form of the schema file,
so formatting does not change it. The suite prints it as
`handover digest: <file> sha256:<hex>` and as the JUnit property `digest`.

| Check | Rule |
|---|---|
| `schema` | The file is at most 1 MiB, UTF-8, JSON without duplicate member names, a JSON Schema (draft 2020-12) whose root is `type: object` with `additionalProperties: false` and whose `properties.contract_version` is the constant `papaia.data-handover/1` |
| `pin` | Present with `--pin` or `--pin-file` (each may be given several times): the digest equals every pin. A pin file holds exactly `sha256:<64 lower-case hex digits>` and an optional line break |
| `bom` | Present with `--bom`: the digest equals the `digest` of the one entry `name: papaia.data-handover/1` in `contracts:` of the bill of materials |

The bill of materials is read as strict YAML like a manifest. The suite reads
only its list `contracts:`; the entry of the handover schema allows the fields
`name`, `repo`, `path` and `digest` and MUST carry `digest`:

```yaml
contracts:
  - name: papaia.data-handover/1
    repo: papaia-data
    path: schemas/data-handover-1.json
    digest: sha256:<64 hex digits>
```

Without a pin and without `--bom` the suite has nothing to compare and exits
with `2`, as it does for an unreadable pin file.
