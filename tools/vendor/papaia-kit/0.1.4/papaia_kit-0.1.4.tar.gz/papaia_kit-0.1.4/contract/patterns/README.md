# Patterns

The nine interaction patterns every module renders the same way. Mandatory are
the element, its role, the ARIA attributes, the `data-pk-*` hooks and the fixed
texts. Recommended are the `pk-*` classes of `dist/css/patterns.css` (layer
`pk.patterns` of `papaia-kit.css`). Own classes and components are allowed when
the computed styles of the specimen page are the same and own values use only
`var(--pk-*)`.

| File | Content |
|---|---|
| `patterns.yaml` | States per pattern, mandatory elements, fixed text keys, timing |
| `examples/<id>.<lang>.html` | Example markup, one `<section data-pk-example="<state>">` per state |
| `../messages/patterns.{de,en}.yaml` | Fixed texts of the patterns |
| `../messages/states.{de,en}.yaml` | Fixed texts of the five states (missing, stopped, no access, not found, session expired) |
| `../messages/codes.{de,en}.yaml`, `../messages/consequences.{de,en}.yaml` | Pattern 8 texts per code and the closed list of consequence sentences |
| `../vectors/formats.json` | Pattern 9 formats, kinds of time value, shared test vectors |

`papaia_kit.ui.patterns.check_example` checks parsed markup against a state of
`patterns.yaml`; `papaia_kit.ui.messages.text` fills a fixed text;
`papaia-kit messages check [--dir DIR]` runs the forbidden patterns
(`../forbidden-patterns.yaml`) over every message file of a directory, with
placeholders filled, and fails when the German and English files differ in
keys or placeholders.

## Timing

One value per entry in all modules (`patterns.yaml`, `timing`):

| Entry | Value |
|---|---|
| Undo offer after a reversible write (patterns 4 and 5) | 15 s, equal to the validity of `undo_token`, and as long as pointer or focus is inside |
| Loading indicator appears after | 0.3 s |
| Second loading stage after | 10 s |
| Loading aborted with a pattern 8 message after | 30 s |
| Success toast stands at least | 6 s; error toasts stay until closed |

## Pattern 1: table

`<table>` with `<th scope="col">`; sorting through a `<button>` in the header
cell and `aria-sort` on the `th`; container `div.pk-table-scroll` with
`tabindex="0"` and a name. From 50 rows on, pages with the range
`table_range` ("1–50 von 120" / "1–50 of 120"). Row action in the last column,
one visible, the rest in a menu ("Weitere Aktionen" / "More actions");
multiple selection only with check boxes. Focus outlines inside scroll
containers are drawn inward (`outline-offset: -2px`). States: `default`, `paged`.

## Pattern 2: form

`<label for>` above the field; mandatory fields carry `required`,
`aria-required="true"` and "(Pflicht)" / "(required)" in the name; field
errors in a `<p id>` referenced by `aria-describedby`; error summary
`<div role="alert" tabindex="-1">` ("Prüfen Sie die markierten Angaben." /
"Check the marked details."), focused after a failed submit. Checks run on
leaving a field and on submit. Primary action bottom left, "Abbrechen" /
"Cancel" next to it. Unsaved changes on leaving: dialog "Änderungen
verwerfen?" / "Discard changes?" with focus on "Weiter bearbeiten" / "Keep
editing". States: `default`, `error`, `discard`.

## Pattern 3: write in the own module

Message in `role="status"`: "Gespeichert." / "Saved.". State: `default`.

## Pattern 4: write into an integration

Before writing, a `<dialog aria-labelledby aria-describedby>` names the three
details `data-pk-confirm="integration|function|object"` ("Anbindung",
"Funktion", "Objekt" / "Integration", "Function", "Object"); without
confirmation nothing is written. Afterwards the receipt "Ausgeführt am <Zeit>.
Kennung: <Korrelationskennung>" / "Carried out on <time>. Reference:
<correlation id>", whose reference is found in the audit. A reversible write
offers "Rückgängig" / "Undo" for the undo window (`data-pk-undo-ms="15000"`).
States: `dialog`, `receipt`, `undo`.

## Pattern 5: destructive action

`pk-btn` with `data-pk-variant="danger"`; `<dialog>` with default focus on
"Abbrechen" / "Cancel" (`autofocus`), so the Enter key deletes nothing. The
dialog names object and consequence: "„<Objekt>“ wird endgültig gelöscht." /
"“<object>” will be deleted permanently.", or "… wird gelöscht und kann
<Frist> wiederhergestellt werden." / "… will be deleted and can be restored
for <period>.". More than one object: the number ("<n> Einträge werden
endgültig gelöscht."), the affected people, groups, workflows or dashboards
("Betroffen: …" / "Affected: …") and typing the name ("Geben Sie zur
Bestätigung „<Name>“ ein.") or a fresh sign-in. After a reversible delete the
same undo offer as in pattern 4. Every write action of a module is classified
in its `ui/write-actions.yaml` as `umkehrbar`, `endgültig` or `wirkt auf
andere`. States: `final`, `restorable`, `many`, `undo`.

## Pattern 6: empty state

`<div class="pk-empty" data-pk-state="empty">` with one sentence saying what
appears here and at most one action. The sentence belongs to the module.
State: `default`.

## Pattern 7: loading

`<div data-pk-state="loading" aria-busy="true">`, shown only after 0.3 s
("Wird geladen …" / "Loading …"). After 10 s "Das dauert länger als üblich." /
"This is taking longer than usual."; after 30 s the load is aborted with a
pattern 8 message, for example "Die Daten konnten nicht geladen werden. Es
wurde nichts geändert." / "The data could not be loaded. Nothing was
changed.", and "Erneut versuchen" / "Try again". States: `loading`, `slow`,
`failed`.

## Pattern 8: error message

`<div class="pk-error" role="alert">` with three children
`data-pk-part="what|todo|id"` in this order: (1) what happened, one sentence,
followed where the person entered or triggered something by the consequence
sentence `<span data-pk-part="consequence">` from the closed list; (2) what to
do, exactly one action; (3) "Kennung: <Korrelationskennung>" / "Reference:
<correlation id>" with a copy button ("Kennung kopieren" / "Copy reference").
Parts 1 and 2 never match a forbidden pattern. The state pages "Kein Zugang" /
"No access" (HTTP 403) and "Nicht gefunden oder nicht erlaubt" / "Not found or
not permitted" (HTTP 404) inside the frame use the texts of
`states.{de,en}.yaml` and the same reference line. States: `default`,
`no_access`, `not_found`.

## Pattern 9: date, time, number

`<time datetime="2026-03-07T14:05:00+01:00">`; German "07.03.2026", "14:05",
"1.234.567,5"; English "7 Mar 2026", "14:05", "1,234,567.5". The date never
contains a weekday. `formats.json` decides per kind of time value whether a
weekday stands as its own element `<span data-pk-weekday>` before the
`<time>`: with weekday for due dates, reminders and the next scheduled run;
never for log entries, versions and the data state. Form: "Sa., 07.03.2026,
14:05" / "Sat 7 Mar 2026, 14:05". The server formats in the time zone of the
person (`time_zone` from `prefs`). Relative times only with the absolute time
as `title` or second line; exports in ISO 8601 with offset. Formats are fixed
patterns with the kit's own month list, not locale data (English "Sep", never
"Sept"); Python (`papaia_kit.ui.formats`) and TypeScript (`@papaia/kit`) run
the same vectors. Numbers use `<data value="1234567.5">`. States:
`with_weekday`, `without_weekday`, `number`.

```python
from papaia_kit.ui.formats import format_moment, format_number, moment_html

moment = format_moment(due_at, kind="due", lang="de", time_zone="Europe/Berlin")
moment.text  # "Sa., 07.03.2026, 14:05"
moment_html(
    moment
)  # '<span data-pk-weekday>Sa.</span>, <time datetime="…">07.03.2026, 14:05</time>'
format_number("1234567.5", "en")  # "1,234,567.5"
```
