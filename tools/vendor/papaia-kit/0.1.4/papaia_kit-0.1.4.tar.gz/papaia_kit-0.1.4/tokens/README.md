# Design tokens

One source for colours, radii, fonts and layout values of every user interface
of the platform. The values are those of the manager themes `fidonis-light`
and `fidonis-dark`; where the kit adds a role (`text-muted`, `nav-active-bg`),
it is listed with its contrast in `contrast-pairs.yaml`.

| File | Content |
|---|---|
| `papaia.tokens.json` | All values, [Design Tokens Format Module 2025.10](https://www.designtokens.org/TR/2025.10/format/), groups `light` and `dark` per theme, other groups shared; SHA-256 of every font file |
| `contrast-pairs.yaml` | Colour pairs that must meet WCAG 2.1 contrast in both themes |
| `media.yaml` | Register of every font and icon file: source, release, license, rights holder, retrieval date, SHA-256 |
| `assets/fonts/`, `assets/icons/` | The registered media files, unchanged from their source |
| `licenses/` | License texts of the media files |

`tools/build.py` generates `dist/` from these files. Generated files are
checked in and never edited by hand:

```sh
make tokens         # write dist/
make check-tokens   # dist/ is current (exit 1 names each differing file) and contrast passes
```

## Names

Each token becomes one CSS custom property `--pk-<path>`: the token path
without the theme group, joined by `-`; the DTCG name `$root` adds nothing.
`light.color.primary` is `--pk-color-primary`, `text.xs.$root` is
`--pk-text-xs`, `text.xs.line-height` is `--pk-text-xs-line-height`. Every
colour role also gets the channel variable `--pk-color-<role>-rgb` (`r g b`),
used only for opacity steps in the Tailwind preset, never for text.

The reader (`papaia_kit.ui.tokens`) refuses unknown `$` fields and groups,
colour spaces other than sRGB, a `hex` that disagrees with `components`,
aliases anywhere except the colour of a border (which may only refer to a
colour of its own theme), and roles defined in one theme only.

## Generated files (`dist/`)

| Path | Content |
|---|---|
| `css/tokens.css` | `@font-face` rules and all `--pk-*` variables; `:root[data-theme="light"]`, `:root[data-theme="dark"]`, and without the attribute the system setting through `prefers-color-scheme` |
| `css/papaia-kit.css` | The stylesheet modules include: layer order `pk.tokens, pk.shell, pk.patterns` and the tokens layer |
| `tailwind/preset.cjs` | Tailwind CSS 3 preset: daisyUI themes `fidonis-light`/`fidonis-dark` with the literal values, colours `pk-<role>` on the channel variables, font families, radii |
| `fonts/*.woff2` | Manrope 500/700/800, IBM Plex Sans 400/500/600, IBM Plex Mono 400, with their license texts |
| `icons/sprite.svg` | Symbols `pk-icon-<name>`: module symbols (`chat`, `studio`, `data`, `flow`, `assistant`, `me`, `manager`) and shell symbols; use `<svg><use href="…/sprite.svg#pk-icon-check"/></svg>` |
| `keycloak/papaia/login/resources/` | `css/tokens.css` and the fonts for the login theme |
| `SHA256SUMS` | SHA-256 of every generated file |

Nothing is loaded from another host: fonts, icons and stylesheets are shipped
with each module.

## Changing a value

A changed value is a minor version and carries the mark `visual` in the
changelog with the old and the new value; a removed or renamed variable is a
major version. Change the token file, run `make tokens`, commit the token file
and `dist/` together.

## Adding a media file

Put the unchanged file under `assets/`, add an entry to `media.yaml` with its
SHA-256 and, for a new license, the license text under `licenses/`. A font file
also needs a face in the token file with the same SHA-256. The build refuses a
file without an entry, an entry without a file and every checksum that does
not match. Icons must be single-colour SVGs on a 24 × 24 grid with drawing
elements only (`path`, `circle`, `rect`, `line`, `polyline`, `polygon`,
`ellipse`); scripts, links, styles and references are refused.
