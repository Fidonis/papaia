"""Registered names of the reference stack, built-in Keycloak objects and removed names.

The exchange scopes ``aud-<audience>`` are not listed here; ``register``
derives one per audience through ``exchange_scope``.
"""

from __future__ import annotations

from papaia_kit.names._model import Entry, Kind, Removed

# Repositories that own a registered name.
OWNERS = frozenset(
    {
        "papaia",
        "papaia-kit",
        "papaia-studio",
        "papaia-data",
        "papaia-flow",
        "papaia-assist",
        "papaia-me",
        "papaia-manager",
        "papaia-connections",
        "papaia-knowledge-map",
        "paperless-mcp-rbac",
        "qdrant-mcp-rbac",
        "mssql-mcp-rbac",
        "mediawiki-mcp-rbac",
    }
)

A, C, S, R = Kind.AUDIENCE, Kind.CLIENT, Kind.SCOPE, Kind.ROLE
SA, SV, NW = Kind.SERVICE_ACCOUNT, Kind.SERVICE, Kind.NETWORK

# Resource servers: each is an audience and a bearer-only client of the same
# name (no flow, no token exchange).
_RESOURCE_SERVERS: tuple[tuple[str, str, str], ...] = (
    ("flow", "papaia-flow", "Flow API (existing name)"),
    ("assist-api", "papaia-assist", "assistant interface and module API (existing name)"),
    ("papaia-connections", "papaia-connections", "connection register"),
    ("papaia-data", "papaia-data", "Data API; chain holder, signs nobody in"),
    ("papaia-studio", "papaia-studio", "Studio gateway: handover and usages"),
    ("papaia-studio-assist", "papaia-studio", "Studio channel for the assistant"),
    ("papaia-studio-me", "papaia-studio", "Studio module API for Me"),
    ("papaia-studio-builder-mcp", "papaia-studio", "Studio builder for the chat"),
    ("papaia-prefs", "papaia-me", "preference store"),
    ("papaia-audit", "papaia", "core audit service, read API"),
    ("mcp-paperless", "paperless-mcp-rbac", "Paperless MCP server"),
    ("mcp-qdrant", "qdrant-mcp-rbac", "Qdrant MCP server"),
    ("mcp-qdrant-ingest", "qdrant-mcp-rbac", "Qdrant MCP server, ingest surface"),
    ("mcp-knowledge-map", "papaia-knowledge-map", "knowledge map MCP server"),
    ("mcp-mssql", "mssql-mcp-rbac", "SQL Server MCP server"),
    ("mcp-wiki", "mediawiki-mcp-rbac", "MediaWiki MCP server"),
)

# Clients that are not resource servers, plus the clients above whose
# settings differ from plain bearer-only. (name, owner, purpose, token exchange)
_CLIENTS: tuple[tuple[str, str, str, bool], ...] = (
    ("papaia-studio-gateway", "papaia-studio", "Studio gateway (BFF); never an audience", True),
    ("papaia-studio-builder-mcp", "papaia-studio", "Studio builder, own sign-in", False),
    ("papaia-data", "papaia-data", "Data API, chain holder; declares downstream", True),
    ("papaia-data-ui", "papaia-data", "Data interface (BFF); own tokens only", True),
    ("papaia-me", "papaia-me", "Me area", True),
    ("flow", "papaia-flow", "Flow API, bearer-only (existing name)", False),
    ("flow-engine", "papaia-flow", "Flow engine and worker; offline access (existing)", True),
    ("flow-console", "papaia-flow", "Flow console (BFF); own tokens only (existing)", True),
    ("flow-cli", "papaia-flow", "Flow command line, public client (existing name)", False),
    ("papaia-flow-mcp-chat", "papaia-flow", "Flow MCP surface in the chat", False),
    ("assist-api", "papaia-assist", "assistant interface and module API (existing)", False),
    ("assist-gate", "papaia-assist", "assistant gate, only token holder (existing)", True),
    ("papaia-manager", "papaia-manager", "Manager", True),
    ("librechat", "papaia", "chat (existing name)", False),
)

# Clients that exist only in the realm of the test profile (security 1.2).
# (name, owner, purpose, token exchange)
_TEST_CLIENTS: tuple[tuple[str, str, str, bool], ...] = (
    ("papaia-kit-testclient", "papaia-kit", "conformance tests; test profile only", True),
)

_SCOPES: tuple[tuple[str, str, str], ...] = (
    ("openid", "papaia", "OpenID Connect sign-in"),
    ("offline_access", "papaia", "refresh token for long-running work (flow-engine, assist-gate)"),
    ("papaia-person", "papaia", "shared claims sub, person_id, roles, groups, email"),
)

_ROLES: tuple[tuple[str, str, str], ...] = (
    *(
        (f"{module}-{level}", owner, f"{module} {level}")
        for module, owner, levels in (
            ("studio", "papaia-studio", ("member", "author", "reviewer", "admin")),
            ("data", "papaia-data", ("member", "author", "reviewer", "admin")),
            ("flow", "papaia-flow", ("member", "author", "reviewer", "admin")),
            ("assist", "papaia-assist", ("member", "admin")),
        )
        for level in levels
    ),
    ("prefs-read", "papaia-me", "read notification preferences of others (service accounts)"),
    ("user", "papaia", "sign-in (existing name)"),
    ("papaia-admin", "papaia", "platform administration, composite of the module admins"),
    ("papaia-auditor", "papaia", "read the audit log; not part of papaia-admin"),
    ("papaia-operator", "papaia", "start, stop, backup, upgrade, emergency stop"),
    ("papaia-confirm", "papaia", "second person for approvals"),
    ("papaia-legal-hold", "papaia", "legal hold, two persons"),
)

_SERVICE_ACCOUNTS: tuple[tuple[str, str, str], ...] = (
    ("svc-flow-events", "papaia-flow", "event runs, purpose invoice intake"),
    ("svc-flow-d1", "papaia-flow", "second purpose of the test inventory"),
    ("svc-assist-notify", "papaia-assist", "read notification preferences"),
    ("svc-flow-notify", "papaia-flow", "read notification preferences"),
    ("svc-studio-notify", "papaia-studio", "read notification preferences"),
    ("svc-papaia-lifecycle", "papaia", "account lifecycle and revocation"),
    ("svc-papaia-people", "papaia", "core person search and group members"),
    ("flow-directory", "papaia-flow", "groups for approvals (existing name)"),
    ("flow-control", "papaia-flow", "connection register calls (existing name)"),
)

_SERVICES: tuple[tuple[str, str, str], ...] = (
    ("papaia-replay", "papaia", "core start gate adapters for chat and model gateway"),
    ("papaia-docker-gate", "papaia", "Docker socket mediator of the Manager"),
)

_NETWORKS: tuple[tuple[str, str, str], ...] = (
    ("papaia-sql-uplink", "papaia", "only direct path of mcp-mssql to the production system"),
    ("papaia-replay-net", "papaia", "papaia-lifecycle to papaia-replay, internal"),
    ("papaia-replay-chat-net", "papaia", "papaia-replay to the chat database, internal"),
    ("papaia-replay-gw-net", "papaia", "papaia-replay to the model gateway, internal"),
    ("papaia-docker-gate-net", "papaia", "Manager to papaia-docker-gate, internal"),
)


def _base() -> tuple[Entry, ...]:
    entries: list[Entry] = [Entry(n, A, o, p) for n, o, p in _RESOURCE_SERVERS]
    special = {name for name, *_ in _CLIENTS}
    entries += [
        Entry(n, C, o, f"{p}; bearer-only") for n, o, p in _RESOURCE_SERVERS if n not in special
    ]
    entries += [Entry(n, C, o, p, token_exchange=te) for n, o, p, te in _CLIENTS]
    entries += [
        Entry(n, C, o, p, token_exchange=te, test_profile_only=True)
        for n, o, p, te in _TEST_CLIENTS
    ]
    entries += [Entry(n, S, o, p) for n, o, p in _SCOPES]
    entries += [Entry(n, R, o, p) for n, o, p in _ROLES]
    entries += [Entry(n, SA, o, p) for n, o, p in _SERVICE_ACCOUNTS]
    entries += [Entry(n, SV, o, p) for n, o, p in _SERVICES]
    entries += [Entry(n, NW, o, p) for n, o, p in _NETWORKS]
    return tuple(entries)


BASE: tuple[Entry, ...] = _base()

# Module prefixes of module roles ``<module>-<role>``; platform roles use
# ``papaia-<role>``.
ROLE_MODULES = frozenset(
    {"studio", "data", "flow", "assist", "me", "manager", "connections", "prefs"}
)

# Objects Keycloak creates in every realm. They are listed so that the realm
# conformance check and the realm sync accept them without a list of their
# own; they are not managed by the register and are no names to create. The
# scope offline_access is a built-in scope too, but registered above because
# the stack grants it on purpose.
_BUILTIN_NOTE = "built-in, not managed"
_BUILTIN_SCOPES = (
    "acr",
    "address",
    "basic",
    "email",
    "microprofile-jwt",
    "organization",
    "phone",
    "profile",
    "role_list",
    "roles",
    "service_account",
    "web-origins",
)
_BUILTIN_ROLES = ("offline_access", "uma_authorization", "default-roles-papaia")
_BUILTIN_CLIENTS = (
    "account",
    "account-console",
    "admin-cli",
    "broker",
    "realm-management",
    "security-admin-console",
)

BUILTIN: tuple[Entry, ...] = (
    *(Entry(n, S, "papaia", f"{_BUILTIN_NOTE}: Keycloak client scope") for n in _BUILTIN_SCOPES),
    *(Entry(n, R, "papaia", f"{_BUILTIN_NOTE}: Keycloak realm role") for n in _BUILTIN_ROLES),
    *(Entry(n, C, "papaia", f"{_BUILTIN_NOTE}: Keycloak client") for n in _BUILTIN_CLIENTS),
)

REMOVED: tuple[Removed, ...] = (
    Removed("data", "papaia-data", "Data client and audience renamed"),
    Removed("aud-data", "aud-papaia-data", "Data exchange scope renamed"),
    Removed(
        "wiki-mcp",
        "mcp-wiki",
        "MCP servers are named mcp-<system>; transition until the end of stage 1",
        until_stage=1,
    ),
    Removed(
        "aud-wiki-mcp",
        "aud-mcp-wiki",
        "MCP servers are named mcp-<system>; transition until the end of stage 1",
        until_stage=1,
    ),
    Removed("aud-studio", "aud-papaia-studio", "Studio handover audience renamed"),
    Removed("papaia-flow-console", "flow-console", "the Flow console keeps its existing name"),
    Removed("svc-assist-prefs", "svc-assist-notify", "service accounts read notifications"),
    Removed("svc-flow-prefs", "svc-flow-notify", "service accounts read notifications"),
    Removed("flow", "aud-flow", "scopes carry the aud- prefix", frozenset({Kind.SCOPE})),
)
