"""User interface contract: design tokens, shell markup and the specimen page."""

from papaia_kit.ui.shell import (
    ShellInput,
    ShellInputError,
    kit_loader,
    parse_shell_input,
    render_shell,
    shell_context,
    shell_environment,
)
from papaia_kit.ui.shell_normalize import normalize_shell

__all__ = [
    "ShellInput",
    "ShellInputError",
    "kit_loader",
    "normalize_shell",
    "parse_shell_input",
    "render_shell",
    "shell_context",
    "shell_environment",
]
