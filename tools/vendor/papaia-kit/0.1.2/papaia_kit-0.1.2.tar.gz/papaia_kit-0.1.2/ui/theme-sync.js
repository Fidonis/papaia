/*
 * Appearance switching without reload, for React consoles (oberflaeche 3.1, 3.3).
 * No dependencies, no inline script, no stored state: the source of the
 * appearance stays the core service prefs, written by the module's server.
 *
 * 1. The footer form POST /_kit/appearance (contract/shell/shell.md section 7)
 *    switches data-theme and the button at once and sends the same form with
 *    fetch. If the server does not accept it, the old state comes back and the
 *    form is posted the plain way, so the server's answer (error page, sign-in)
 *    is what the person sees.
 * 2. When the tab shows again, the session cookie pk_ui
 *    (<appearance>.<locale>.<etag>) tells whether another module changed the
 *    settings; a new etag applies the appearance and fires the window event
 *    "pk:preferences" with {appearance, locale}, so the console can reload its
 *    texts when the language changed. A cookie the script cannot read changes
 *    nothing.
 * 3. window.pkTheme.apply(appearance) switches the view after the console
 *    itself changed the setting through its server; current() reads it.
 */
(function () {
  "use strict";

  var ACTION = "/_kit/appearance";
  var FORM = 'form[action="' + ACTION + '"]';
  var BUTTON = 'button[name="appearance"]';
  var NATIVE = "data-pk-native";
  var COOKIE = "pk_ui";
  var PK_UI = /^(light|dark|system)\.(de|en|browser)\.([A-Za-z0-9._~+\/=-]{1,128})$/;
  /* Equal to appearance_dark and appearance_light in contract/messages/shell.{de,en}.yaml. */
  var LABELS = {
    de: { dark: "Dunkler Modus", light: "Heller Modus" },
    en: { dark: "Dark mode", light: "Light mode" }
  };

  var doc = window.document;
  var root = doc.documentElement;
  var seen = null;

  function language() {
    var lang = (root.getAttribute("lang") || "").toLowerCase();
    return lang === "en" || lang.indexOf("en-") === 0 ? "en" : "de";
  }

  function current() {
    var theme = root.getAttribute("data-theme");
    return theme === "light" || theme === "dark" ? theme : "system";
  }

  /* The button offers the other appearance; for system it offers dark, as the server renders it. */
  function setButton(button, appearance) {
    var offer = appearance === "dark" ? "light" : "dark";
    button.setAttribute("value", offer);
    var label = button.querySelector(".pk-label");
    if (label) {
      label.textContent = LABELS[language()][offer];
    }
    var use = button.querySelector("use");
    var href = use && use.getAttribute("href");
    if (href && href.indexOf("#") >= 0) {
      use.setAttribute("href", href.slice(0, href.indexOf("#") + 1) + "pk-icon-" + (offer === "light" ? "sun" : "moon"));
    }
  }

  function apply(appearance) {
    if (appearance === "system") {
      root.removeAttribute("data-theme");
    } else {
      root.setAttribute("data-theme", appearance);
    }
    Array.prototype.forEach.call(doc.querySelectorAll(FORM), function (form) {
      var button = form.querySelector(BUTTON);
      if (button) {
        setButton(button, appearance);
      }
    });
  }

  function readCookie() {
    var cookie;
    try {
      cookie = doc.cookie || "";
    } catch (ignored) {
      return null;
    }
    var parts = cookie.split(";");
    for (var i = 0; i < parts.length; i += 1) {
      var part = parts[i].replace(/^\s+|\s+$/g, "");
      if (part.indexOf(COOKIE + "=") === 0) {
        var match = PK_UI.exec(part.slice(COOKIE.length + 1));
        return match ? { appearance: match[1], locale: match[2], etag: match[3] } : null;
      }
    }
    return null;
  }

  function sync() {
    var ui = readCookie();
    if (!ui || ui.etag === seen) {
      return;
    }
    seen = ui.etag;
    if (ui.appearance !== current()) {
      apply(ui.appearance);
    }
    window.dispatchEvent(
      new window.CustomEvent("pk:preferences", {
        detail: { appearance: ui.appearance, locale: ui.locale }
      })
    );
  }

  function body(form, value) {
    var params = new window.URLSearchParams();
    Array.prototype.forEach.call(form.querySelectorAll('input[type="hidden"]'), function (input) {
      if (input.name && input.name !== "appearance") {
        params.append(input.name, input.value);
      }
    });
    params.append("appearance", value);
    return params;
  }

  function fallback(form, button, before) {
    apply(before);
    form.setAttribute(NATIVE, "1");
    if (typeof form.requestSubmit === "function") {
      form.requestSubmit(button);
    } else {
      form.submit();
    }
  }

  doc.addEventListener("submit", function (event) {
    var form = event.target;
    if (!form || typeof form.matches !== "function" || !form.matches(FORM)) {
      return;
    }
    if (form.getAttribute(NATIVE) === "1") {
      form.removeAttribute(NATIVE);
      return;
    }
    var button = event.submitter && event.submitter.name === "appearance" ? event.submitter : form.querySelector(BUTTON);
    var value = button ? button.value : "";
    if (value !== "light" && value !== "dark") {
      return;
    }
    event.preventDefault();
    var before = current();
    apply(value);
    window
      .fetch(ACTION, {
        method: "POST",
        body: body(form, value),
        credentials: "same-origin",
        redirect: "manual"
      })
      .then(function (response) {
        /* The server answers 303; with redirect "manual" that is an opaque redirect. */
        if (response.type !== "opaqueredirect" && !response.ok) {
          throw new Error("not accepted");
        }
        var ui = readCookie();
        if (ui) {
          seen = ui.etag;
        }
      })
      .catch(function () {
        fallback(form, button, before);
      });
  });

  doc.addEventListener("visibilitychange", function () {
    if (doc.visibilityState === "visible") {
      sync();
    }
  });
  window.addEventListener("pageshow", sync);
  window.addEventListener("focus", sync);

  var start = readCookie();
  seen = start ? start.etag : null;

  window.pkTheme = {
    apply: function (appearance) {
      if (appearance !== "light" && appearance !== "dark" && appearance !== "system") {
        throw new TypeError("appearance must be light, dark or system");
      }
      apply(appearance);
    },
    current: current
  };
})();
