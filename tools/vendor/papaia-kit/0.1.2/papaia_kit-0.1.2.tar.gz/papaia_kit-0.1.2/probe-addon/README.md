# Probe add-on

A minimal add-on with a small MCP server. It proves that a new connection
appears in every module from its catalog entry alone (PLT-49) and serves as
the reference for add-on authors. It holds synthetic test data only.

| File | Content |
|---|---|
| `papaia-app.yaml` | Manifest: `exposes:` with the tool server `probe.notes` and the personal-area entry `probe.me`, and the declaration of the personal setting (`personal_settings:`, contract version 1) |
| `docker-compose.yml` | One service `probe-mcp`, one volume `probe-data`, one network; nothing published on the host |
| `Dockerfile` | Image of the server; build context is the repository root, dependencies pinned with hashes (`requirements.txt`) |
| `probe_mcp/` | The server (Python, standard library HTTP server plus the kit) |
| `schemas/probe-export-1.json` | Schema of the exit export `papaia.probe-export/1` |
| `testing/live_check.py` | Install in Docker, server suite, uninstall, residue check (`make probe-live`) |

## What it offers

| Catalog id | Kind | Content |
|---|---|---|
| `probe.notes` | `mcp` | `read_note` (read), `write_note` (write), `delete_note` (delete), `describe_access`, `check_access`; event `probe.note.deleted` |
| `probe.me` | `me` | personal setting "Report deletions" (`announce_deletions`, boolean), summary, export and erasure of the person's data |

Data classes: every operation and the event carry at most `internal`; the
setting is `personal`. Both categories are declared under `storage`.

The server reads its manifest at start and serves exactly what it declares:
`tools/list`, the input schemas, the effects and the event come from the file.
A changed declaration (for example an operation changed from `read` to `write`
and `addon upgrade`) changes the server without a code change.

## Rules the server keeps

- Every request except `GET /healthz` runs the kit check chain
  (`papaia_kit.authz`): signature and issuer, exactly the own audience, `azp`
  in the allow list (`/run/papaia/security/azp-allowlist.json`), the role
  `probe-user` and the effect released for the client. The person is taken
  from the token only.
- Notes are kept per person: a person reaches only the notes filed under the
  `sub` of the verified token. Another person's note and a missing note give
  the same answer (`forbidden_or_not_found`).
- Inputs are checked against the declared schemas; unknown fields, ids outside
  `^[a-z0-9-]{1,64}$`, texts longer than 2000 characters and bodies over
  64 KiB are refused with the `error.v1` envelope.
- Every write and delete (`write_note`, `delete_note`, saving the setting,
  erasing the person's data) writes one `papaia.audit/1` row with the
  correlation id through the kit audit writer, in the same SQLite transaction
  as the effect. A refused write writes one `denied` row. Rows carry no note
  text, no setting value and no token.
- The event `probe.note.deleted` carries the note id only. It is queued in the
  same transaction as the deletion and sent to `PROBE_EVENT_URL`, signed after
  Standard Webhooks (https://www.standardwebhooks.com/) with the secret in
  `PROBE_EVENT_SECRET_FILE` (`whsec_<base64>`, a file not readable by others).
  A person who turned "Report deletions" off sends no event. Without an event
  URL no event is queued.

## Settings

| Variable | Meaning |
|---|---|
| `PROBE_ISSUER` | `iss` of the platform realm (https), required |
| `PROBE_JWKS_URL` | JWKS of the realm (http on the internal network or https), required |
| `PROBE_TRUST` | `addon` (default) or `platform`, as the catalog sets it |
| `PROBE_AUDIT_SINK` | `ingest` (default: mutual TLS to `papaia-audit` with the client certificate in `/run/papaia/security/audit/`) or `file:<absolute path>` (JSON lines, test stacks only) |
| `PROBE_EVENT_URL`, `PROBE_EVENT_SECRET_FILE` | event input and its secret; both or neither |
| `PROBE_SECURITY_DIR` | host directory mounted read-only at `/run/papaia/security` (compose only) |

## Checks

```sh
uv run --locked papaia-kit conformance manifest probe-addon/papaia-app.yaml \
  --compose probe-addon/docker-compose.yml
uv run --locked python -m pytest tests/test_probe_addon.py
make probe-live PROJECT=probe-live PORT=18000      # needs Docker
```

`tests/test_probe_addon.py` runs the kit server suite against the server
in-process, with the kit test issuer. `make probe-live` builds the image and the
kit test issuer, starts both with `docker compose` (ports on 127.0.0.1 only;
`SUBNET=<cidr>` pins the network), runs the server suite against the
container, removes everything with `docker compose down -v --rmi all` and
fails when a container, volume, network or image of the project is left.

## A fresh id

PLT-49-A1 needs a connection no module knows. This writes the manifest under
a fresh id; module name, catalog ids, audience, role and event name change
together:

```sh
PYTHONPATH=probe-addon uv run --locked python -m probe_mcp manifest --id t3x9 \
  --output /path/to/addon/papaia-app.yaml
```

With `--id t3x9` the add-on is `probe-t3x9`, its entries are `probe-t3x9.notes`
and `probe-t3x9.me`, the audience is `mcp-probe-t3x9`, the role
`probe-t3x9-user` and the event `probe_t3x9.note.deleted`.

## Known limits

- The revocation list (step 5 of the check chain) is off until the core mounts
  it; the chain reports the step as disabled.
- A rejection before the identity is known (no token, forged token) has null
  identity fields, which `papaia.audit/1` does not admit yet; the server logs
  such a rejection with its error code and does not store it.
- Erasure through the erasure journal of the platform is not wired; a person
  erases their data through the personal area (`DELETE /api/me/data`).
