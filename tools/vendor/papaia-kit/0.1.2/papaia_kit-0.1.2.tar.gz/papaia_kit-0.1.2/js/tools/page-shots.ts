// Whole-page images of the specimen and the composed reference pages: German, 1440 x 900 and
// 390 x 844, light and dark, with the test branding (contract/specimen.md, Ä-33). Used by
// `make shots` (local review, shots/) and by the kit release (refimg/, tools/refimg.ts).
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";

import type { Browser } from "playwright-core";

import { capturePage, openPage } from "../src/conform/run.ts";
import { PAGE_SHOT_VIEWPORTS, PAGE_SHOTS, type PageShotViewport } from "../src/conform/refimg.ts";
import { renderComposed, renderSpecimen, startReferenceSite } from "./reference-site.ts";

/** Module whose shell frames the whole-page images (the composed pages belong to Mein Bereich). */
export const PAGE_SHOT_MODULE = "me";
const PATH = "/_kit/page";

export type PageShotTarget = (page: string, viewport: PageShotViewport, theme: "light" | "dark") => string;

/** Render every page shot and write it to the path `target` names; returns the paths written. */
export async function writePageShots(browser: Browser, kitDir: string, kitVersion: string, target: PageShotTarget): Promise<string[]> {
  const written: string[] = [];
  for (const name of PAGE_SHOTS) {
    const html = name === "specimen" ? renderSpecimen(kitDir, PAGE_SHOT_MODULE, "de") : renderComposed(kitDir, name, "de");
    const site = await startReferenceSite(kitDir, html, kitVersion, undefined, PATH);
    try {
      for (const [viewport, size] of Object.entries(PAGE_SHOT_VIEWPORTS) as [PageShotViewport, { width: number; height: number }][]) {
        for (const theme of ["light", "dark"] as const) {
          const context = await browser.newContext({ viewport: size, colorScheme: theme, locale: "de", reducedMotion: "reduce" });
          try {
            const page = await openPage(context, `${site.url}${PATH}`, theme);
            const path = target(name, viewport, theme);
            mkdirSync(dirname(path), { recursive: true });
            writeFileSync(path, await capturePage(page));
            written.push(path);
          } finally {
            await context.close();
          }
        }
      }
    } finally {
      await site.close();
    }
  }
  return written;
}
