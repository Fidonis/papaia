// Local site with the kit's reference specimen page (papaia-kit specimen page) and the files of
// dist/, on 127.0.0.1 only. Used to make the reference images in a kit release and by the
// browser self test; never part of a module.
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { createServer, type Server } from "node:http";
import { extname, join, normalize, sep } from "node:path";

const TYPES: Record<string, string> = {
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".woff2": "font/woff2",
};

export interface ReferenceSite {
  url: string;
  close: () => Promise<void>;
}

export function renderSpecimen(kitDir: string, module: string, lang: "de" | "en"): string {
  const run = spawnSync(
    "uv",
    ["run", "--locked", "papaia-kit", "specimen", "page", "--module", module, "--lang", lang, "--theme", "light"],
    { cwd: kitDir, encoding: "utf-8", maxBuffer: 8 * 1024 * 1024 },
  );
  if (run.status !== 0) throw new Error(`papaia-kit specimen page failed: ${run.stderr}`);
  return run.stdout;
}

/** The base layer fixture document (papaia-kit base page). */
export function renderBase(kitDir: string, lang: "de" | "en"): string {
  const run = spawnSync("uv", ["run", "--locked", "papaia-kit", "base", "page", "--lang", lang, "--theme", "light"], {
    cwd: kitDir,
    encoding: "utf-8",
    maxBuffer: 8 * 1024 * 1024,
  });
  if (run.status !== 0) throw new Error(`papaia-kit base page failed: ${run.stderr}`);
  return run.stdout;
}

/** The fixture document of the layout primitives, section head, card and tile (papaia-kit components page). */
export function renderComponents(kitDir: string, lang: "de" | "en"): string {
  const run = spawnSync(
    "uv",
    ["run", "--locked", "papaia-kit", "components", "page", "--lang", lang, "--theme", "light"],
    { cwd: kitDir, encoding: "utf-8", maxBuffer: 8 * 1024 * 1024 },
  );
  if (run.status !== 0) throw new Error(`papaia-kit components page failed: ${run.stderr}`);
  return run.stdout;
}

/** A composed reference page (papaia-kit specimen page --page). */
export function renderComposed(kitDir: string, page: string, lang: "de" | "en"): string {
  const run = spawnSync("uv", ["run", "--locked", "papaia-kit", "specimen", "page", "--page", page, "--lang", lang, "--theme", "light"], {
    cwd: kitDir,
    encoding: "utf-8",
    maxBuffer: 8 * 1024 * 1024,
  });
  if (run.status !== 0) throw new Error(`papaia-kit specimen page --page ${page} failed: ${run.stderr}`);
  return run.stdout;
}

/** Serve one specimen document (optionally changed by `transform`) and dist/ of the kit. */
export async function startReferenceSite(
  kitDir: string,
  html: string,
  kitVersion: string,
  transform: (html: string) => string = (h) => h,
  pagePath = "/_kit/specimen",
): Promise<ReferenceSite> {
  const dist = join(kitDir, "dist");
  const prefix = `/_kit/${kitVersion}/`;
  const page = transform(html);
  const server: Server = createServer((req, res) => {
    const path = new URL(req.url ?? "/", "http://127.0.0.1").pathname;
    if (req.method !== "GET") {
      res.writeHead(405).end();
      return;
    }
    if (path === pagePath) {
      res.writeHead(200, { "content-type": "text/html; charset=utf-8" }).end(page);
      return;
    }
    if (path === "/_kit/brand/logo") {
      const logo = readFileSync(join(kitDir, "contract", "shell", "inputs", "branding", "logo.svg"));
      res.writeHead(200, { "content-type": TYPES[".svg"]! }).end(logo);
      return;
    }
    const file = path.startsWith(prefix) ? normalize(join(dist, path.slice(prefix.length))) : "";
    const type = TYPES[extname(file)];
    if (!file.startsWith(dist + sep) || !type) {
      res.writeHead(404).end();
      return;
    }
    try {
      res.writeHead(200, { "content-type": type }).end(readFileSync(file));
    } catch {
      res.writeHead(404).end();
    }
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  if (address === null || typeof address === "string") throw new Error("no port");
  return {
    url: `http://127.0.0.1:${address.port}`,
    close: () => new Promise<void>((resolve) => server.close(() => resolve())),
  };
}
