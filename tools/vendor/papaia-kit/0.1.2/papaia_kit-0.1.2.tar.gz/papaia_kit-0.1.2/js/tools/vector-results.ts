// Prints what the TypeScript binding computes for every shared vector, as JSON on
// standard output. tests/test_ts_parity.py compares it with the Python binding.
import { readFileSync } from "node:fs";

import {
  formatMoment,
  formatNumber,
  linkState,
  momentHtml,
  readCatalog,
  resolveFrom,
  visibleModules,
  type Language,
  type MomentKind,
} from "../src/index.ts";

function vectors(name: string): Record<string, unknown> {
  const url = new URL(`../../contract/vectors/${name}`, import.meta.url);
  return JSON.parse(readFileSync(url, "utf-8")) as Record<string, unknown>;
}

const visible = vectors("visible_modules.json") as {
  catalog: unknown;
  visible: { name: string; roles: string[] }[];
  links: { name: string; surface: string; roles: string[] }[];
};
const visibleCatalog = readCatalog(visible.catalog);

const from = vectors("from.json") as { catalog: unknown; cases: { name: string; from: string }[] };
const fromCatalog = readCatalog(from.catalog);

const formats = vectors("formats.json") as {
  vectors: {
    moments: { name: string; value: string; time_zone: string; lang: Language; kind: MomentKind }[];
    numbers: { name: string; value: string; lang: Language; decimals: number | null }[];
  };
};

const result = {
  visible: Object.fromEntries(
    visible.visible.map((c) => [c.name, visibleModules(visibleCatalog, c.roles).map((s) => s.id)]),
  ),
  links: Object.fromEntries(
    visible.links.map((c) => [c.name, linkState(visibleCatalog, c.surface, c.roles)]),
  ),
  from: Object.fromEntries(
    from.cases.map((c) => {
      const target = resolveFrom(fromCatalog, c.from);
      return [
        c.name,
        target === null
          ? null
          : {
              module: target.module,
              target: target.target,
              title: target.title,
              url: target.url,
              after_done: target.afterDone,
              running: target.running,
            },
      ];
    }),
  ),
  moments: Object.fromEntries(
    formats.vectors.moments.map((v) => {
      const m = formatMoment(new Date(v.value), v.kind, v.lang, v.time_zone);
      return [
        v.name,
        { weekday: m.weekday, date: m.date, time: m.time, iso: m.iso, text: m.text, html: momentHtml(m) },
      ];
    }),
  ),
  numbers: Object.fromEntries(
    formats.vectors.numbers.map((v) => [v.name, formatNumber(v.value, v.lang, v.decimals)]),
  ),
};

process.stdout.write(JSON.stringify(result) + "\n");
