// Make the reference images of one kit release (contract/specimen.md, Ä-33): every module, both
// themes, from the reference specimen page with the test branding, plus the whole specimen and
// composed pages at both widths, in the pinned Playwright container of the platform. Refuses unless the requested release equals the package version.
//
//   node js/tools/refimg.ts --release vX.Y.Z
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";

import { chromium } from "playwright-core";

import { KIT_VERSION } from "../src/index.ts";
import { captureShot, loadExpected, openPage } from "../src/conform/run.ts";
import { pageShotPath, platformDir, REFIMG_MODULES, REFIMG_SHOTS, refimgPath } from "../src/conform/refimg.ts";
import { writePageShots } from "./page-shots.ts";
import { renderSpecimen, startReferenceSite } from "./reference-site.ts";

const KIT_DIR = fileURLToPath(new URL("../..", import.meta.url));

async function main(): Promise<number> {
  const { values } = parseArgs({ args: process.argv.slice(2), strict: true, options: { release: { type: "string" } } });
  const pkg = JSON.parse(readFileSync(join(KIT_DIR, "js", "package.json"), "utf-8")) as { version: string };
  if (values.release !== `v${pkg.version}`) {
    console.error(`refimg: --release must be v${pkg.version} (reference images are made only for a kit release)`);
    return 2;
  }
  const require = createRequire(import.meta.url);
  const playwright = (JSON.parse(readFileSync(require.resolve("playwright-core/package.json"), "utf-8")) as { version: string }).version;
  const expected = loadExpected(KIT_DIR, "light");
  if (playwright !== expected.tools.playwright) {
    console.error(`refimg: playwright-core ${playwright}, the kit pins ${expected.tools.playwright}`);
    return 2;
  }
  const platform = platformDir(process.platform, process.arch);
  const browser = await chromium.launch();
  try {
    for (const module of REFIMG_MODULES) {
      const site = await startReferenceSite(KIT_DIR, renderSpecimen(KIT_DIR, module, "de"), KIT_VERSION);
      try {
        for (const theme of ["light", "dark"] as const) {
          const context = await browser.newContext({ viewport: expected.viewports.desktop, colorScheme: theme, reducedMotion: "reduce" });
          const page = await openPage(context, `${site.url}/_kit/specimen`, theme);
          for (const shot of REFIMG_SHOTS) {
            const target = join(KIT_DIR, refimgPath({ playwright, platform, module, shot: shot.name, theme }));
            mkdirSync(dirname(target), { recursive: true });
            writeFileSync(target, await captureShot(page, shot));
          }
          await context.close();
        }
      } finally {
        await site.close();
      }
    }
    await writePageShots(browser, KIT_DIR, KIT_VERSION, (page, viewport, theme) =>
      join(KIT_DIR, pageShotPath({ playwright, platform, page, viewport, theme })),
    );
  } finally {
    await browser.close();
  }
  console.log(`refimg: wrote refimg/${playwright}/${platform}/ for ${values.release}`);
  return 0;
}

process.exitCode = await main();
