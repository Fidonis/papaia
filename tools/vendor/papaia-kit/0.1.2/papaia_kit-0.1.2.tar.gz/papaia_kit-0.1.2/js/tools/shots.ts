// Local review images (make shots): the specimen and the composed reference pages at 1440 x 900
// and 390 x 844, light and dark, German, as PNG files in --out. Never reference images: those
// are made only in a kit release (tools/refimg.ts).
//
//   node js/tools/shots.ts --out shots
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";

import { chromium } from "playwright-core";

import { KIT_VERSION } from "../src/index.ts";
import { writePageShots } from "./page-shots.ts";

const KIT_DIR = fileURLToPath(new URL("../..", import.meta.url));

async function main(): Promise<number> {
  const { values } = parseArgs({ args: process.argv.slice(2), strict: true, options: { out: { type: "string" } } });
  if (!values.out) {
    console.error("usage: node js/tools/shots.ts --out DIR");
    return 2;
  }
  const out = resolve(values.out);
  const browser = await chromium.launch();
  try {
    const written = await writePageShots(browser, KIT_DIR, KIT_VERSION, (page, viewport, theme) =>
      resolve(out, `${page}-${viewport}-${theme}.png`),
    );
    console.log(`shots: wrote ${written.length} image(s) to ${out}`);
  } finally {
    await browser.close();
  }
  return 0;
}

process.exitCode = await main();
