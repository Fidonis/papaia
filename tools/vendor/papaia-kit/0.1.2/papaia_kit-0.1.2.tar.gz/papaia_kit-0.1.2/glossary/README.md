# Glossary

The German and English glossary binding for all user-facing texts of the
platform, with the replacement lists used by the wording check.

- `glossary.yaml`: the entries and the fixed part (form of address, module
  names, role display, mandatory places).
- `glossary.schema.json`: JSON Schema 2020-12 of the file.

Rules for the patterns and the stages of the check are described in the
section "Glossary and word check" of the repository README. Entries and
patterns change only with a kit minor version; a change that makes a term of
the glossary match one of its own patterns is rejected when the file is loaded.
