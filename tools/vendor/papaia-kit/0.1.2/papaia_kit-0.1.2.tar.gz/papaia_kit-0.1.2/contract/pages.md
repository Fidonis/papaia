# Addresses, page list and administration places

Interface spec 2.4, 2.5, 3.9 and 7. Every module uses these files and the
functions named here; none keeps its own copy.

## 1. Named targets and the return parameter `from`

A module publishes its named targets in the catalog (`ui[].targets`, each with
a `pattern`) and its administration overview as `ui[].admin_url`. Addresses
carry only identifiers and versions, never titles, names, mail addresses or
tokens. A renamed pattern keeps a permanent redirect (`308`) across upgrades.

A link into another module carries `?from=<module>:<target>:<key>`:

| Pattern of the target | `<key>` | Example |
|---|---|---|
| no placeholder (a list) | `-` | `studio:tasks:-` |
| one placeholder | `[A-Za-z0-9-]{1,64}` | `flow:task:01JCZ8V4N5Q2W3E4R5T6Y7U8I9` |
| two placeholders | `<identifier>~<version>`, version a positive integer | `data:analysis:01JCZ8V4N5Q2W3E4R5T6Y7U8I9~3` |

The target `admin` resolves to `admin_url`. The receiving module calls
`papaia_kit.catalog.resolve_from(catalog, from)` (TypeScript: `resolveFrom`,
rules in `catalog-reader.md` section 6); the result carries the address (built
from `public_url` and `pattern` only), the `after_done` address, the module
title for the breadcrumb "Zurück zu <module>" and whether the module runs (a
stopped module gets the locked link of interface spec 2.4). Everything else (unknown module
or target, other characters, `/`, a third `:`, `//`, a scheme, a line break)
yields `None`: no breadcrumb, no link, no redirect, no message. An address
passed as a parameter is never evaluated.
`papaia_kit.ui.address.target_url(catalog, module, target, key,
from_value=...)` builds a link with `from` on the same rules.

Shared vectors: `vectors/from.json` (every implementation runs them unchanged).

## 2. Delegation targets

A delegation is granted only at its holder: `flow:delegation` (holder
`flow-engine`) and `assistant:delegation` (holder `assist-gate`).
`delegation_url(catalog, holder, return_to)` returns
`{public_url}/delegation?return_to=<from value>`; `return_to` follows the
grammar of `from` and is resolved the same way, so after the grant or the
cancellation the holder answers `303` only to an own path of a platform host
from the catalog. A `return_to` that does not resolve yields no link.

## 3. Page list

Each module keeps its part `ui/pages.yaml` (`papaia.pages-part/1`, schema
`pages.schema.json`); the page list `contract/pages.yaml` of a run
(`papaia.pages/1`) is the union of the parts of the bill of materials:

```sh
papaia-kit pages union studio/ui/pages.yaml me/ui/pages.yaml --out contract/pages.yaml
papaia-kit pages check contract/pages.yaml
```

A row is `{module, path | state, target?, title_key, nav_group?,
primary_action_key?, kinds[], needs_neighbours, person}` with `kinds` from
`tabelle`, `liste`, `formular`, `zerstörend`, `bau-editor`, `zustand`. A part
is rejected when it lacks `signed_off_by` (name and date of the module's
product owner), breaks the schema, lists a path twice, names another module in
a row, or misses `/help`, `/_kit/specimen` or the state page "Kein Zugang"
(`state: no_access`, kind `zustand`). Guided paths (`leitweg`) are numbered
step lists `{step, action, path}` under a unique `name`; steps count 1, 2,
3, ... and every path is a page of the part. The union lists each module once,
ordered by module and path; nothing is written when one part is rejected.
`pages check` applies the same rules to every module of the page list and
also rejects a module listed twice under `modules` and a row whose module has
no entry under `modules` (such a row would have no sign-off).

## 4. Administration map

`admin-map.yaml` (`papaia.admin-map/1`, schema `admin-map.schema.json`) is
identical for all modules:

| Entry | Place |
|---|---|
| Not-Aus | `/admin/emergency-stop`, first entry, only Studio, Flow, Assistant |
| Anbindungen freischalten | `/admin/integrations` |
| Einstellungen | `/admin/settings` |
| Audit-Log (in Manager) | no module route; manager target `audit`, filtered on the module |
| Rollen vergeben (in Manager) | optional row; manager target `users` |
| group Prüfen | `/reviews` |

My area and the manager have no group "Verwaltung". Old paths answer `308`:
`/admin/halt` and `/admin/stop` to the emergency stop, `/admin/connections`
to `/admin/integrations`, `/admin/audit` to the audit log in the manager,
`/review` to `/reviews` (`AdminMap.redirect()`). The list `tasks` names
task, place and role; every task has exactly one place. The path
`admin_url` stands for the module's `ui[].admin_url` in the catalog; a task
with `module` (only for place `module`) is a domain administration page of
that module alone. `unmapped_admin_pages(admin, pages, catalog)` reports
every page of group `nav.admin` in a page list without a row in the map for
its module.

## 5. Places that depend on another module

`depends-on.yaml` (`papaia.depends-on/1`) lists per module the places whose
function needs another module. When that module has no `ui[]` entry,
`DependsOn.missing(catalog, module)` returns the place: it shows no link and
the sentence "<module> ist in dieser Installation nicht eingerichtet." /
"<module> is not set up in this installation." (`DependsOn.sentence()`).
