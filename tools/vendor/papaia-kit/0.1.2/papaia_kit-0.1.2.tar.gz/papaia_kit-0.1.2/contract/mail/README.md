# Notification mail: reference cases

Golden cases of `papaia_kit.ui.mail.render_notification` with the templates
`dist/mail/notification.{html,txt}.j2` (interface spec 3.5 and 7; PLT-78 with
the changed wording Ä-32 and RE-48).

| Folder | Content |
|---|---|
| `inputs/<case>.json` | One notification: `lang`, `kind` (`reminder` or `task`), `title`, `module`, `installation`, `object_url`, `notifications_url`; optional `body` (at most three sentences from the module's own fixed texts) and `logo_src` (`cid:<id>` or an https address) |
| `expected/<case>.json` | Sender name and subject |
| `expected/<case>.txt`, `expected/<case>.html` | The two parts |

Rules the cases pin down:

- Sender name is `<installation>` for every module, never `<installation> – <module>`.
- Subject is `<kind>: <title>`, kind `Erinnerung`/`Reminder` or `Aufgabe`/`Task`.
- First line `Aus <module>` / `From <module>`; the module is named again in the footer.
- Exactly one link to the object and one to the notifications in My area.
- No content from integrations: the input has no field for it, unknown fields are refused.

Unknown fields, line breaks or hidden characters in a single-line field
(header injection), addresses other than https, and credentials in an address
are refused with `MailInputError`. The kit renders; sending is the core's mail
outbound.
