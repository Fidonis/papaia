# Token exchange

`papaia_kit.exchange` is the only place that builds token exchange requests.
Modules do not post to the token endpoint themselves.

## One pattern: one audience per token

Every exchange is RFC 8693 in the core realm with

```text
grant_type           = urn:ietf:params:oauth:grant-type:token-exchange
subject_token_type   = urn:ietf:params:oauth:token-type:access_token
requested_token_type = urn:ietf:params:oauth:token-type:access_token
audience             = <a>
scope                = aud-<a>
```

`scope` is built by `papaia_kit.names.exchange_scope`, so the audience must be a
valid, registered or rule-conforming audience name. `exchange()` takes exactly
one audience as a string; a list, tuple or set, a string with several names, a
removed name or a client that is never an audience is refused locally
(`invalid_input`) and no request is sent. The realm rejects a request with two
`aud-*` scopes as well (pair policies); the server checks `aud` again on every
request (`papaia_kit.authz`).

The issued token is checked before it is handed out: `aud` is exactly the
requested audience (a string or a one-element list), `azp` is the client,
`sub`, `sid` and `auth_time` equal those of the subject token, the response
carries no refresh token and no unknown member. A deviation is
`contract_mismatch`. The client does not verify signatures; the resource server
does.

`exchange()` reads the claims of the subject token without checking its
signature. Pass only a token the module has verified with `papaia_kit.authz`
(a received token) or obtained from its own sign-in (a session token); never
caller-supplied text that has not passed that check.

```python
from papaia_kit.exchange import ExchangeClient, PrivateKeyJwt

client = ExchangeClient(
    token_endpoint="http://keycloak:8080/realms/papaia/protocol/openid-connect/token",
    client_id="papaia-studio-gateway",
    auth=PrivateKeyJwt(signer),  # signer: alg, kid, sign(bytes) -> bytes
)
token = client.exchange(session_token, "mcp-paperless", correlation_id=cid)
response = http.post(url, headers=token.headers(), ...)
```

## Chain exchange only as declared

A subject token whose `azp` is the client itself is the client's own token and
may be exchanged for any audience the client is paired with; the realm decides.
The chain holder is the exception: it never exchanges a token of its own, so a
token it already exchanged (`azp` = chain holder, `aud` = a downstream audience)
cannot be exchanged a third time (security 1.5 no. 2/3). Such a token is refused
locally with `chain_holder_own_token` and no request is sent; the realm refuses
it as well (policy `data-chain` applies to every exchange of the chain holder).

A token whose `azp` is another client is a received token. It is exchanged only
when

1. the client declares the target audience in `downstream` (from its catalog
   entry); otherwise `chain_not_declared` and no request is sent;
2. the received token's `aud` is exactly the client's own audience;
3. it is a person token (`person_id` from `papaia_kit.names`).

Only a client that is itself an audience can declare `downstream`; in the
reference stack that is the chain holder `papaia-data`. The construction of any
other client with `downstream` fails. Which origins may start a chain is
enforced by the realm (policy `data-chain`), not by the kit.

The result of a chain exchange carries `origin_azp`, the `azp` of the received
token, and `headers()` adds `X-Papaia-Origin-Azp`. The header is information
only: the server logs it and never decides on it.

## Cache

Exchanged tokens are cached per person (`sub`) and audience. An entry is bound
to the subject token (sha256 of it), so a different token that names the same
`sub` never reads another entry. An entry is handed out only while more than
`CACHE_MARGIN` (10 s) of the token's lifetime is left; the lifetime is the
earlier of the token's `exp` and `expires_in` of the response. Entries are never
shared across persons.

`forget(sub)` drops every entry of a person. Modules must call it on the
lifecycle or revocation signal of a person: until the issuer refuses a token or
`forget(sub)` runs, a cached token of a revoked person stays usable until its
lifetime ends minus `CACHE_MARGIN` (at most 300 s token lifetime).

## Refusals

`ExchangeError` carries `error_class` (`papaia_kit.errors.ErrorClass`), `status`
and `retryable` (the default of the class), `reason`, `audience` and
`correlation_id`:

| Situation | `error_class` | `reason` |
|---|---|---|
| list or set of audiences | `invalid_input` | `one_audience_per_token` |
| invalid or removed audience name | `invalid_input` | `invalid_audience` |
| malformed subject token | `invalid_input` | `malformed_subject_token` |
| expired subject token | `unauthenticated` | `subject_token_expired` |
| received token, audience not declared | `forbidden_or_not_found` | `chain_not_declared` |
| received token not addressed to the client | `forbidden_or_not_found` | `subject_audience_mismatch` |
| received token is no person token | `forbidden_or_not_found` | `not_a_person_token` |
| chain holder passes a token of its own | `forbidden_or_not_found` | `chain_holder_own_token` |
| realm refuses (pairing, second audience, origin) | `forbidden_or_not_found` | `exchange_refused` |
| realm rejects the client authentication | `forbidden_or_not_found` | `client_authentication_failed` |
| realm answers `invalid_token` or `invalid_grant` | `identity_revoked` | `subject_token_not_active` |
| realm unreachable or 5xx | `upstream_unavailable` (retryable) | `issuer_unreachable`, `issuer_error` |
| issued access token is not a compact JWS | `contract_mismatch` | `malformed_access_token` |
| response breaks the contract | `contract_mismatch` | defect, e.g. `audience_not_single` |

`reason` is always one of the fixed words above; no text of the issuer is
passed on.

`identity_revoked` drops the cached tokens bound to the refused subject token
(same sha256), not every token of the person named in it: the claims are not
verified, and a forged token that names someone else's `sub` must not clear
that person's cache. The person-wide purge is `forget(sub)` on the lifecycle
signal (see Cache). Which error codes the realm returns for an inactive or
revoked subject token, as opposed to a policy refusal, is confirmed against the
kit test issuer.

## Client authentication

`PrivateKeyJwt(signer)` (RFC 7523) is the method for every confidential client
with token exchange. The kit builds the assertion (`iss` = `sub` = client,
`aud` = token endpoint, fresh `jti`, lifetime 60 s) and passes the signing input
to the module's signer; algorithms RS256 and ES256 only. The private key never
enters the kit.

`ClientSecret(secret)` (HTTP Basic) is a fallback only while the
`private_key_jwt` proof is open; the client logs a warning when a client is
created with it.

## Correlation and logging

`correlation_id` is sent as `X-Papaia-Correlation-Id` when it satisfies the
correlation id rule of [`audit.md`](audit.md) (at most 64 characters from
`[A-Za-z0-9-]`, not shaped like a token or prefixed key); otherwise a new UUIDv7
replaces it (`papaia_kit.errors.normalize_correlation_id`). The logger
`papaia_kit.exchange` records client, audience, outcome and correlation id. It
never records a token value, a client assertion, a secret or `sub`.

## Transport

`UrllibTransport` (standard library) posts the form, follows no redirect,
ignores proxy variables and reads at most 64 KiB. A malformed status or header
line and a truncated body raise `OSError` like a failed connection, so the
client reports `upstream_unavailable`. A module may pass its own
transport with the same `post_form` method.
