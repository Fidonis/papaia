# Task items and the tasks collector

Schema: `schemas/task-item.v1.schema.json` (`papaia.task-item/1`).
Python: `papaia_kit.tasks`.

The list "Meine Aufgaben" is one list with one count everywhere: the overview
of Mein Bereich, Studio and Flow show the same items and the same number.
Flow (through its module relay), Data and Studio are the task sources; each
keeps its own tasks and serves them in one format. The list is merged in
exactly one place, `papaia_kit.tasks.collect()`.

## Routes of a task source

| Route | Body |
|---|---|
| `GET /api/v1/me/tasks` | `{"format": "papaia.task-item/1", "tasks": [<item>, ...]}` (`#/$defs/list`), at most 2000 items |
| `GET /api/v1/me/tasks/summary` | `{"open": <n>, "overdue": <n>, "revision": "<id>"}` (`#/$defs/summary`) |

- Both routes answer only the calling person's own open tasks, decided by the
  source on the server from the verified token (`sub`, groups, rights). The
  list a client shows is never the control.
- A caller that may read these routes may read no other route of the source's
  audience with that pairing (security 1.4, "Aufgabenquellen"); the source
  answers any other route of such a caller with 403.
- `revision` changes whenever the person's list in this source changes; a
  counter can poll `summary` and fetch the list only when it changed.
- `overdue` is never larger than `open`. Counts are JSON integers.

## Item

| Field | Required | Content |
|---|---|---|
| `format` | yes | `papaia.task-item/1` |
| `id` | yes | Stable within the source, for example `flow:run:42:run_approval` |
| `source` | yes | Module that owns the task and answered for it: `flow`, `data`, `studio` |
| `kind` | yes | Kind of task within the source (`run_approval`, `kpi_review`, ...) |
| `title` | yes | `{"de", "en"}`, one line each, at most 200 characters |
| `href` | yes | Target address: path in the source's user interface, relative to its public address; never a URL |
| `due_at` | yes | RFC 3339 with offset, or `null` |
| `created_at` | no | RFC 3339 with offset, or `null` |
| `subject`, `folder` | no | Name of the object (workflow, app, key figure) and its folder; names, never content |
| `open_in` | no | `{module, target, id}`: a target of another module that opens the task (oberflaeche 2.5), for example a Studio app |
| `app_ref` | no | Studio app that serves as form or approval step |
| `risk_level` | no | `G`, `T`, `H`, `K` for release slots, else `null` |
| `ref` | no | Up to eight ids the source needs (`run_id`, `release_id`, ...): strings of `A-Z a-z 0-9 . _ : -` or non-negative integers |
| `decide` | no | `{where, max_age_s, one_click: false}`: where the task is decided and how fresh the sign-in must be |

Timestamps must name a real instant: the day must exist in its month, hour
00-23, minute and second 00-59 (no leap second), offset hours 00-23 and
minutes 00-59, and the instant must lie within the years 0001-9999 in UTC. The
schema pattern checks only the shape; the kit readers (`parse_task_list`,
`check_task_list`, `validate_task_item`) check the rest, and a list with such a
timestamp makes its source unavailable like any other non-conforming body.

An item carries nothing beyond the title: no run input, no form content, no
step output, no approve link and no token. Unknown fields are rejected at every
level. A task is never decided from the list; the person opens it in the
source.

## Collector

```python
from papaia_kit import tasks as pk_tasks

result = pk_tasks.collect(
    person_token,  # verified with papaia_kit.authz or from the module's own sign-in
    catalog=catalog,  # papaia_kit.catalog reader
    exchange=exchange_client,  # papaia_kit.exchange.ExchangeClient of the calling module
    local=pk_tasks.LocalSource("studio", tasks=own_tasks, summary=own_summary),  # optional
    correlation_id=correlation_id,
)
result.tasks  # read-only items, sorted
result.count  # the number in the counter
result.hints()  # hint lines, German; hints("en") in English
```

1. **Sources.** `SOURCES` names Flow (`flow`, audience `flow`), Data (`data`,
   audience `papaia-data`) and Studio (`studio`, audience `papaia-studio`).
   For each, the collector takes the catalog entry with that `audience` and an
   `address`. A source without such an entry is not installed: it is skipped
   without a hint and without an error. An entry with `state: stopped` is not
   called and counts as unavailable.
2. **Own module.** The calling module passes its own tasks as `LocalSource`
   (decoded bodies of its own routes for the person it has checked). They are
   checked like a remote answer and not fetched over HTTP.
3. **Calls.** Per source, one token exchange for exactly the source's audience
   with the person's token (`papaia_kit.exchange`), then
   `GET <address>/api/v1/me/tasks` and `GET <address>/api/v1/me/tasks/summary`
   with that token and the correlation id. No other route is called. Sources
   are read in parallel; each call has a time limit (`timeout`, default 5 s,
   at most 60 s). The default transport follows no redirect, ignores proxy
   variables and reads at most 2 MiB.
4. **Checks.** Each body is checked against the schema (strict JSON, no
   duplicate member names, unknown fields rejected). Every item's `source`
   must be the source that answered, and ids are unique per source: a source
   cannot place items in another module's name.
5. **Merge.** Items are sorted by `due_at` ascending (instants compared in
   UTC), items without a due date last; then newest `created_at` first; then
   source order and id. `count` and `overdue` are the sums of the summaries of
   the sources that answered.
6. **Outage.** A source that is stopped, cannot be reached, answers with a
   status other than 200 (redirects included), answers outside the contract,
   or for which the exchange fails at the issuer, counts as unavailable. Its
   items and counts are left out, nothing older is shown in their place, and
   `hints()` carries for it:
   - de: "<Modul> ist gerade nicht erreichbar. Aufgaben aus <Modul> sind gerade nicht abrufbar."
   - en: "<Module> is not reachable right now. Tasks from <Module> cannot be retrieved right now."

   Show each line with the role `status`. A refusal that concerns the person
   (session ended, token expired or malformed) is raised as `ExchangeError`
   instead: the person has to sign in again.
7. **No cache.** The collector keeps nothing between calls. The exchange client
   caches tokens per person and audience, bound to the person's token, so a
   token or an answer of one person never reaches a call for another.
8. **Logs.** One line per unavailable source with source name, reason and
   correlation id. Token values, titles and bodies are never logged.

The collector only reads; it writes no audit row. Each source writes its own
audit rows for the decisions made there.
