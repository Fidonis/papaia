# Shell markup contract

Every module delivers its HTML documents from its own server with the same
frame: brand, module switcher, navigation, footer with account menu, page
header. This file is the normative text; `expected/` holds the reference
outputs, `inputs/` the reference inputs, `normalize.md` the comparison rules.

Python modules render the frame with `papaia_kit.ui.render_shell()` or with the
Jinja2 macro `shell` from `pk/shell.html` (`papaia_kit.ui.shell.kit_loader()`).
A module that renders it itself (the manager) must produce the same normalised
output for every reference input.

## 1 Input

`input.schema.json` (`papaia.shell-input/1`) defines the input. Unknown fields
are rejected, every text has a length limit, every link is an own path (never
`//…`, never a backslash) or an `https://` address. The embedded catalog is
checked by the catalog reader (schema and content hashes) before anything is
rendered. Further checks:

- `page.back.module` names a module of the catalog, and `page.back.href` lies
  below that module's `public_url` (no redirect to another host).
- `nav.groups[].items[].module` names a module of the catalog.
- Without a catalog, or with a catalog without `branding`, the input carries
  `branding` itself.

The shell is display only. Whether a module is listed grants or withholds
nothing; every module checks rights server-side on every request.

## 2 Document

```html
<!doctype html>
<html lang="{locale}" data-theme="{light|dark}">          <!-- no data-theme for system -->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="papaia-kit" content="{kit version}">
  <title>{page} – {module} – {installation}</title>
  <link rel="stylesheet" href="/_kit/{kit version}/css/papaia-kit.css">
  <script src="/_kit/{kit version}/js/shell.js" defer></script>
</head>
<body class="pk-body">
  <a class="pk-skip" href="#pk-main">…</a>
  <div class="pk-shell" data-pk-sidebar="{pinned|collapsed}">
    <aside id="pk-sidebar" class="pk-sidebar">
      brand · switcher · nav · footer · <a class="pk-drawer-close" href="#pk-main">
    </aside>
    <div class="pk-content">
      page-header · notice (optional) · <main id="pk-main" tabindex="-1"> · <div id="pk-toasts">
    </div>
  </div>
</body>
</html>
```

- No inline script and no inline style (CSP `script-src` without
  `unsafe-inline`). Symbols come from `/_kit/{kit version}/icons/sprite.svg`.
- The zones `brand`, `switcher`, `nav`, `footer`, `page-header` occur exactly
  once and in this order (`data-pk-zone`); `notice` follows `page-header` only
  when the catalog has `platform_notices`. There is exactly one `main` and one
  `h1`. The skip link is the first focusable element.
- `<title>` is `<page> – <module> – <installation>` with an en dash and
  spaces.

## 3 Zones and measures

Measures are those of the manager (interface spec 2.1); all values come from
`tokens.css`. Breakpoint 1024 px.

| Zone | Markup | Measures |
|---|---|---|
| `brand` | `div.pk-brand` › `a[href][aria-label="<installation> <suffix>, Übersicht"]` › `img.pk-brand-logo[src="/_kit/brand/logo?v=<sha256>"][alt=""]` (only with `logo_sha256`), `span.pk-brand-name`, `span.pk-brand-suffix` | padding 1.25 rem; border bottom 1 px `border`; logo height 2 rem; name Manrope 800 1 rem; suffix 0.75 rem `text-muted`, no opacity on text |
| `switcher` | with catalog: `details.pk-switcher` › `summary[aria-label="Modul wechseln, aktuell: <module>"]` (symbol, name, chevron) and `ul` › `li` › `a`; without catalog: `div.pk-switcher` with symbol and name only | container padding 0.5 rem × 0.75 rem, border bottom 1 px; button width 14.5 rem (232 px), min height 2.5 rem, padding 0.625 rem × 0.75 rem, radius `--pk-radius-btn`; the list opens in the flow below the button and pushes `nav` down, in the 64 px rail as an overlay to its right |
| `nav` | `nav.pk-nav[aria-label="<module>"]` › `ul` with the fixed first row „Übersicht“ (`/`), then per group `h2#pk-nav-g<n>.pk-nav-group` and `ul[aria-labelledby="pk-nav-g<n>"]` | padding 1 rem × 0.75 rem, row gap 0.125 rem; row padding 0.625 rem × 0.75 rem, radius 0.5 rem, 0.875 rem / 1.25 rem, 500; current row `aria-current="page"`, `nav-active-bg`, `secondary`, 600; group heading 0.75 rem, uppercase, `text-muted` |
| `footer` | `div.pk-footer` › `form[action=/_kit/sidebar]`, `form[action=/_kit/appearance]`, `details.pk-account` | border top 1 px, padding 0.75 rem; rows as `nav` |
| `page-header` | `header.pk-page-header` › `div.pk-page-header-inner` › `a.pk-menu-button[href="#pk-sidebar"][aria-controls=pk-sidebar]`, `div.pk-page-heading` (`nav.pk-breadcrumb[aria-label=Brotkrume]` › `ol`, `h1`), `div.pk-actions` | padding 1.25 rem × 2 rem (below 1024 px: 1 rem); border bottom 1 px; `surface-raised`; inner row at most 1680 px; sticky only from 1024 px width and 600 px height; `h1` Manrope 700 1.5 rem / 2 rem; at most one `a.pk-btn[data-pk-variant=primary]` (`page.primary_action`); every further action in the menu `details.pk-menu` „Weitere Aktionen“ / “More actions” (`page.more_actions`, at most 8: links, or with `post` buttons in forms with `pk_csrf`; `destructive` in the error colour; component `menu` of `contract/patterns/`) |
| `notice` | `div.pk-notice[role=status]` › `p[data-pk-level=info|warning]` (symbol, text from `platform_notices[].text`) | padding as `main`; look of the inline alert `.pk-alert`: `--pk-color-<level>-subtle`, accent bar and symbol in the level colour |
| content | `main#pk-main[tabindex=-1]` | padding 1.5 rem × 2 rem (below 1024 px: 1 rem); at most 1680 px; page ground `surface-page` |
| toasts | `div#pk-toasts` › `div[role=status]`, `div[role=alert]` | fixed, right 1 rem, top below the page header + 1 rem, 28 rem wide; below 1024 px at the bottom, full width minus 2 rem; 0.5 rem between toasts (`contract/patterns/README.md`, symbols and surfaces); `shell.js` removes a toast or alert whose `[data-pk-dismiss]` button is pressed |

Long texts break (`overflow-wrap: anywhere`); nothing is cut off with an
ellipsis.

## 4 Brand (Ä-30)

The brand links to the entry page, the overview of Mein Bereich (`public_url`
of `me` from the catalog), with the accessible name
`<installation> <suffix>, Übersicht` (English: `<installation> <suffix>,
overview`; without a suffix `<installation>, Übersicht`). The accessible name
starts with the visible text of the link, name and suffix (WCAG 2.5.3, label in
name). Without `me` in the catalog, and without a catalog (Flow standalone), it
links to `/` of the own module. The first `nav` row of every module is
„Übersicht“ (overview of the module).

## 5 Switcher (PLT-25-A1…A3, Ä-51)

- The entries are exactly `visible_modules(catalog, roles)` in that order
  (shared vectors `contract/vectors/visible_modules.json`): running modules
  whose `visible_for_roles` is empty or shares a role with the person, sorted
  by `order`, then `id`. Display names come only from `ui[].title` of the
  catalog; the shell has no module name of its own.
- The current module carries `aria-current="page"`, `nav-active-bg` **and**
  the check symbol (`svg[data-pk-current-mark]`), never colour alone.
- An entry with `opens_in: new_tab` carries `target="_blank" rel="noopener"`
  and the visible addition „(öffnet in neuem Tab)“ / „(opens in new tab)“,
  which is part of its accessible name.

## 6 Navigation rows into another module

A row with `module` links into that module (address resolved by the caller from
the catalog targets). It shows that module's symbol on the right and the
addition „(in <module>)“, which is part of its accessible name.

## 7 Footer and account menu (PLT-25-A4, Ä-36)

From top to bottom:

1. Sidebar: `button[name=sidebar]` with value `collapsed` („Seitenleiste
   einklappen“) or `pinned` („Seitenleiste ausklappen“); the server sets the
   `pk_sidebar` cookie.
2. Appearance: `button[name=appearance]` with value `dark` („Dunkler Modus“,
   for light and system) or `light` („Heller Modus“, for dark). The server
   writes `prefs` with the person's token and answers `303`
   (`papaia_kit.ui.prefs.write_preferences`, `return_target`).
3. Account menu `details.pk-account`, `summary[aria-label="Kontomenü für
   <name>"]`, opening upwards. Its top-level `ul` has exactly four `li`, in this
   order, and no others:
   1. „Sprache“ / „Language“: nested `details.pk-language` with three forms
      `POST /_kit/language`, values `browser` („Automatisch (<language>)“),
      `de` („Deutsch“), `en` („English“); the stored setting carries
      `aria-current="true"`. The submenu is part of this entry (Ä-36).
   2. „Mein Bereich“ / „My area“: `public_url` of `me`; without a catalog
      `/me` of the own module; with a catalog without `me` the entry is left
      out (the menu then has three entries).
   3. „Hilfe“ / „Help“: `/help` of the own module.
   4. „Abmelden“ / „Sign out“: `form[method=post][action=/auth/logout]`.

Every form is `method="post"` and carries `input[type=hidden][name=pk_csrf]`.

Below 1024 px the sidebar is hidden. The menu button is a link to
`#pk-sidebar`; `#pk-sidebar:target` shows the sidebar as a 256 px drawer and
`a.pk-drawer-close[href="#pk-main"]` closes it. With `shell.js` the link
becomes a button without history entry, the drawer is modal (focus kept, rest
`inert`, Escape closes and returns focus to the menu button).

## 8 Fixed texts

`contract/messages/shell.{de,en}.yaml`, identical keys in both languages.
Modules never keep their own copy.

## 9 Script `shell.js`

Optional enhancement, no dependencies, no stored state:

- switcher and account menu: Escape closes and returns focus to the summary,
  arrow keys, Home and End move between entries, a click outside closes;
- drawer as described in 7;
- `--pk-page-header-height` for scroll padding and the toast position;
- `window.pkShell.update({title, navCurrent, focus})` for route changes in a
  React console: `h1`, `<title>`, current `nav` row, focus on `h1`, announcement
  in the status region.

## 10 Reference inputs

`inputs/*.json`, one expected output per input in `expected/`:

| Input | Case |
|---|---|
| `rs-anna-de-light` | catalog of the reference system, Anna, German, light, back link and primary action |
| `rs-anna-en-dark` | the same in English, dark, stored language `en` |
| `rs-anna-de-system-collapsed` | appearance follows the system, collapsed sidebar |
| `rs-carla-de-light` | Carla, user role only: Chat and Mein Bereich |
| `rs-dora-en-light` | Dora, platform administrator: Chat, Mein Bereich, Manager; stored language `de` |
| `no-data-anna-de-light` | catalog without `data` |
| `notice-anna-de-dark` | catalog with `platform_notices` (zone `notice`) |
| `no-me-anna-de-light` | catalog without `me`: brand → `/`, three menu entries |
| `standalone-flow-de-light` | no catalog (Flow standalone): name only, Mein Bereich → `/me` |

The test branding of all inputs is `inputs/branding/` (name, suffix, contact,
logo; Ä-33). The catalogs' `branding.logo_sha256` is the SHA-256 of
`inputs/branding/logo.svg`; the reference system uses the same branding.

The test roles are those of the vectors: Anna holds a member role of every
module plus `papaia-auditor`, Carla only `user`, Dora `papaia-admin`.

The module of an input is always the checking one: a module renders every
input with its own `module` (the catalog title and symbol win), and the
normalised result must equal `expected/<input>.html`. The kit tests this for
every module of every reference catalog.

`papaia-kit shell render --input <file>` prints the document for one input
(the reference for each module's `render-shell --input`), `papaia-kit shell
normalize <file>` the normalised form, `papaia-kit shell expected [--check]`
writes or checks `expected/`.

## 11 Versioning

A change to this contract, to `input.schema.json`, to `normalize.md` or to
`expected/` is a change of the markup contract and needs a new major version
of the kit (interface spec 3.6), except for corrections of generated files
without a change of the markup.
