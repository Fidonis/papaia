# Normalisation of shell HTML

Rules applied to a rendered document before the character comparison with
`expected/<input>.html` (K3 and K3-RS, interface spec 3.4 and 3.8). The
reference implementation is `papaia_kit.ui.shell_normalize.normalize_shell()`
(`papaia-kit shell normalize <file>`). After normalisation the outputs must be
equal character by character.

1. **Parsing.** HTML is parsed as in the HTML standard's tokenizer, character
   references are decoded. Comments are dropped. A doctype is written as
   `<!doctype html>`.
2. **One node per line.** Each start tag, end tag and text node is one line.
   Text whitespace is collapsed to single spaces and trimmed; whitespace-only
   text is dropped. Void elements (`meta`, `link`, `img`, `input`, …) have no
   end tag; every other element, `svg` and `use` included, has one.
3. **Attributes** are sorted by name. Values are written in double quotes with
   `&`, `<`, `>` and `"` escaped; text escapes `&`, `<`, `>`. An attribute
   without value (`defer`) is written as its bare name.
4. **Per-request values** become placeholders:
   - the value of every `nonce` attribute → `{nonce}`;
   - the `value` of `input[name=pk_csrf]` → `{csrf}`;
   - the `content` of `meta[name=papaia-kit]` → `{kit}`;
   - in `href`, `src` and `action`: `/_kit/<version>/` → `/_kit/{kit}/` and a
     checksum `?v=<hex>` → `?v={hash}`.
5. **Module content** is removed: all children of `nav[data-pk-zone=nav]` and
   of `main#pk-main`. The elements themselves and their attributes stay.
6. **The current module** becomes `{module}`. Its display name is the
   `aria-label` of `nav[data-pk-zone=nav]`. It is replaced
   - in the middle part of `<title>` (`<page> – {module} – <installation>`);
   - in that `aria-label` itself;
   - in the switcher's `summary` (or, without catalog, the switcher `div`): at
     the end of `aria-label`, in a text node equal to the name, and in the
     first symbol reference (`#pk-icon-<id>` → `#pk-icon-{module}`).
   Inside the switcher zone every `aria-current` attribute and every element
   with `data-pk-current-mark` are removed.

The rules are idempotent: a normalised document normalises to itself.
