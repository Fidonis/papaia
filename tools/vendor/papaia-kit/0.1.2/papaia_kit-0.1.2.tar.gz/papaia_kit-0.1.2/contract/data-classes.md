# Data classes

The platform has one scale of data classes. It lives in
[`schemas/data-classes.json`](../schemas/data-classes.json) (format
`papaia.data-classes/1`); no module, add-on or server keeps its own list.

## Order

The position in `classes` is the order, least sensitive first:

| Rank | Id | Title (de) | Title (en) |
|---|---|---|---|
| 0 | `public` | Öffentlich | Public |
| 1 | `internal` | Intern | Internal |
| 2 | `partner_contact` | Kontaktdaten von Geschäftspartnern | Business partner contact data |
| 3 | `personal` | Personenbezogene Daten | Personal data |
| 4 | `employee` | Beschäftigtendaten | Employee data |
| 5 | `confidential` | Vertraulich | Confidential |
| 6 | `special` | Besondere Kategorien (Art. 9 DSGVO) | Special categories (GDPR Art. 9) |
| 7 | `professional_secret` | Berufsgeheimnis (§ 203 StGB) | Professional secrecy (§ 203 StGB) |

The definition of each class is in the file. Compare classes by rank, never by
name: alphabetically `employee` sorts before `internal`.

## Rules

1. Ids are exact. A different spelling (`Public`, ` public`), an unknown name or
   a non-string is rejected; nothing is normalised.
2. A value above a limit (an operation's `data_class_max`, a role's
   `papaia.max_data_class`, a model alias) is refused with the error class
   `class_exceeded`, before the target is called.
3. Where a class is not declared at all (an operation the server reports but the
   catalog does not list), the caller uses the highest class.

## Older scales

`mappings` translates levels of older scales to the platform scale. Each table
covers every level of its source scale exactly once.

| Source | Levels | Mapping |
|---|---|---|
| `me-contract-v1` | `public`, `internal`, `confidential`, `personal`, `special` | same name; v2 of the Me contract uses the platform scale only |
| `studio` | the eight platform ids | same name |

A level outside the source scale (for example `partner_contact` read as a Me
contract v1 value) is rejected, not guessed.

## Python

```python
from papaia_kit import data_classes

data_classes.exceeds("special", "personal")  # True -> class_exceeded
data_classes.at_most("internal", "confidential")  # True
data_classes.highest_of(["internal", "employee"]).id  # "employee"
data_classes.from_scale("me-contract-v1", "confidential").id  # "confidential"
data_classes.parse("secret")  # raises UnknownDataClassError
```

`compare(a, b)` returns -1, 0 or 1. Parsed entries (`DataClass`) order by rank
among themselves; ordering them against a string raises `TypeError`.
