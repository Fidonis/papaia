# Catalog reader

Every module reads `platform/services.json` and `platform/groups.json` with the
kit's reader (`papaia_kit.catalog`, later also the TypeScript package) and with
nothing else, so that an invalid, new, changed or vanished file behaves the same
in every module. The file format is described in `platform-services.md`; this
document describes what a consumer does with it.

## 1. Checks before use

A file is accepted only when all of these hold. Otherwise it is **invalid**.

| Check | Rule |
|---|---|
| Size | At most 1 MiB (1 048 576 bytes) |
| Encoding | Strict UTF-8 |
| JSON | Strict: no duplicate member names, no `NaN` or `Infinity`, no number outside the finite range of a double (`1e400`), at most 64 levels of nested objects and arrays |
| Schema | `platform-services.v1` or `platform-groups.v1`; unknown fields are rejected at every level |
| Unique ids | Entry `id`, switcher `ui[].id` across the whole catalog, group `id` |
| Entry hash | Each entry has an RFC 8785 canonical form, and its `content_hash` equals `sha256:` + SHA-256 of the canonical form of the entry without `content_hash` |
| Delegation lifetime | `delegations.idle_days` is not greater than `delegations.max_days`, after missing values take the defaults of the security profile (90 / 180, `kritis` 7 / 30) |

Error messages name the place and the rule (`services/3/content_hash: does not
match the entry`, `services/3/content_hash: entry has no canonical form`,
`delegations/idle_days: greater than max_days`,
`file: duplicate member name`, `file: nesting too deep`), never the offending
value or member name, and are bounded to 20 per file, so they can be logged and
shown by `doctor` as they are. Any other failure of the check itself counts as
an invalid file with the fixed message `file: rejected (internal check error)`;
the last valid state stays in use.

## 2. Hashes

- `content_hash` identifies one entry. Approvals in modules bind to it.
- The **file digest** (`Catalog.digest`, `sha256:` over the file bytes)
  identifies one rendered version as a whole; the reader uses it to tell a new
  version from a re-written identical one.

The canonical form follows RFC 8785 (https://www.rfc-editor.org/rfc/rfc8785):
members sorted by UTF-16 code units, no whitespace, numbers as ECMAScript writes
a double (`1e+21`, `0.000001`, `1e-7`). Values outside I-JSON (NaN, infinities,
integers beyond 2^53 that a double cannot hold, lone surrogates) have no
canonical form: NaN and infinities make the file invalid while it is read, the
others make the entry and with it the file invalid.

## 3. Reading

| Situation | Behaviour |
|---|---|
| File missing before the first valid read | No catalog; the module works as without a catalog (Flow stand-alone). Not a failure: logged once at INFO, `ReaderStatus.ok` true, `absent` true, no `error`; `doctor` shows "not present (stand-alone)" |
| File invalid, unreadable or missing after a valid read | The last valid state stays in use; the error is logged once per distinct failure and reported by `doctor` (`ReaderStatus`) |
| File valid and different | Replaces the state in use; the reader reports the changes (section 4) |
| File unchanged (size, modification time, inode) | Not read again |

A module asks the reader on every use (`get()`); the reader looks at the file at
most every 30 s, so a change is visible within 60 s of the end of a
`papaia-ctl` command (PLT-25-A3, PLT-49-A1). A file watch may call `refresh()`
earlier. The reader never writes the files; they are mounted read-only.

## 4. Changes and approvals

Between two accepted versions the reader reports entry ids that were

- **added**: the entry is *offered*, never active by itself;
- **changed** (`content_hash` differs): approvals bound to the old hash
  *rest* until someone approves the new hash (PLT-49-A4);
- **removed**: callers answer with error class `upstream_unavailable` and the
  cause "Anbindung entfernt" / "connection removed" (PLT-73).

`approval_state(catalog, entry_id, approved_hash)` returns `offered`, `active`,
`suspended` or `removed` accordingly; `require_entry` raises
`EntryRemovedError` (class `upstream_unavailable`, kit code `PK-UPSTREAM-001`)
for a vanished entry.

## 5. Visible modules and links

```
visible_modules(catalog, roles) =
  sort_by(order, then id) [ e in catalog.ui
      | e.state == "running"
      and (e.visible_for_roles == [] or roles ∩ e.visible_for_roles ≠ ∅) ]
```

`roles` is the `roles` claim of the ID token of the module's own client. `state`
is the state of the entry that carries the surface; a surface whose entry has no
`state` is not running.

`link_state(catalog, id, roles)` says how another module shows a link to the
module with switcher id `id`:

| State | Condition | Shown as |
|---|---|---|
| `absent` | No surface with this id (not installed) | No link; places that depend on the module show "<module> is not set up in this installation." |
| `hidden` | Installed, but no shared role and the role list is not empty | No link |
| `locked` | Visible for the roles, but the entry is `stopped` | Disabled link with "<module> is not reachable right now." |
| `open` | Visible for the roles and `running` | Link |

Visibility is display only. Every target checks rights server-side on every
request; the switcher is never the control.

## 6. Return path

The calling module appends `?from=<module>:<target>:<key>` to an address in
another module. The called module resolves it with
`resolve_from(catalog, from)` (TypeScript: `resolveFrom`) and shows the
breadcrumb "Zurück zu <title>" only for a result. A stopped module still
resolves, with `running` false; the shell then shows the locked link of
interface spec 2.4 ("<module> ist gerade nicht erreichbar.") instead of a link:

```
key = "-"               the target pattern has no placeholder (list targets)
    | <id>              one placeholder; id = [A-Za-z0-9-]{1,64}, not "-"
    | <id>~<version>    two placeholders; version = [1-9][0-9]{0,8}
```

- `module` is a switcher id of a surface in the catalog; `target` is a name in its
  `targets`, or `admin` for its `admin_url`.
- The address is `public_url` without trailing `/` joined with the pattern,
  the placeholders filled in order; `after_done`, when the target names one,
  is joined the same way.
- Everything else is discarded, without breadcrumb, redirect or message: an
  unknown module, an unknown target, a key that does not fit the
  number of placeholders, any other character (`/`, `.`, `%`, white space,
  a line break, non-ASCII), a third `:`, a scheme, `//`, and any value longer
  than 256 characters.
- An address passed as a parameter is never evaluated, so the result can only
  lead to a host the catalog names.

## 7. Shared vectors

| File | Content |
|---|---|
| `vectors/visible_modules.json` | One catalog, role sets with the expected switcher order, link cases (`open`, `locked`, `hidden`, `absent`) |
| `vectors/from.json` | One catalog with targets, `from` values (`cases`) with the expected return address (`module`, `target`, `url`, `after_done`, `running`) or `null` for a discarded value; delegation cases (`delegation`) for `papaia_kit.ui.address.delegation_url` |
| `vectors/catalog_reader.json` | Ordered file versions against one path (absent before the first read, valid, not JSON, unknown field, hash mismatch, duplicate id, delegation `idle_days` greater than `max_days`, delegation lifetime above 7 / 30 days in `kritis`, duplicate member name, lone surrogate, number out of range, integer above 2^53, nesting too deep, new, changed, stopped, removed entry, file removed) with the expected state in use, absent flag and changes |

Every implementation of the reader runs these files unchanged; the Python and
the TypeScript package both do, and `tests/test_ts_parity.py` compares their
outputs. The Python
package finds them under `papaia_kit.contract_dir() / "vectors"`.
