# Manifest section `exposes:` (version 1)

| | |
|---|---|
| Schema | [`schemas/exposes.v1.schema.json`](../schemas/exposes.v1.schema.json), JSON Schema 2020-12 |
| Schema version | `x-papaia-schema-version` in the schema file; history in [`schemas/CHANGELOG.md`](../schemas/CHANGELOG.md) |
| Contract generation | 7 (`ADDON_API`) |
| Example manifests | [`examples/`](examples/) (Paperless, Flow, Studio, probe) |

This document is normative. The key words MUST, MUST NOT, SHOULD and MAY are
used as in RFC 2119. Where this text and the schema disagree, the schema wins
and this text is corrected.

## Purpose

Every module of the platform describes each surface it offers (a tool server,
a REST interface, a user interface, its personal-area interface) exactly once,
in the section `exposes:`. The core renders the platform catalog from these
sections; every consumer (Studio, Data, Flow, Assistant, Me, Manager, knowledge
map) reads the catalog instead of keeping its own description of the same
server. Earlier side files (hand-written connector lists, static tool server
files, a Flow-specific `flow:` section, entries of kind `flow_provider`) are
replaced by this section.

**The catalog is an offer, not a permission.** An entry grants no right, lowers
no data class and activates nothing by itself.

## Where the section lives

- An add-on declares the section under the key `exposes:` of its manifest
  `papaia-app.yaml`.
- A core profile has no add-on manifest; it declares the same list in
  `src/<area>/<profile>/exposes.yaml` of the core repository under the same key.
- The value is a list with at least one entry. Each `id` MUST be unique within
  the whole installation; it stays stable across versions and equals the
  knowledge source id of the surface where one exists.

## The contract

### Discovery

The core validates every section against the schema when an add-on is checked,
installed, started or stopped and at `setup` and `start`. A section that does
not validate is rejected with the field and the reason; the catalog stays
unchanged. Valid entries are rendered into `platform/services.json` (format
`papaia.platform-services/1`) and mounted read-only into every module that
consumes the catalog. A consumer resolves addresses, audiences and operations
only from the catalog, never from fixed addresses.

### Capability description

Each entry carries `id`, `kind`, `title`, optional `description`, the internal
`address`, the `audience` at the target, the accepted kinds of identity
(`identity`), `operations[]`, `events[]` and `ui[]`. Each operation carries one
effect, a retry class, an input and an output schema, the highest data class
it returns or accepts, and an optional display-only role hint. The vocabulary
follows the earlier Flow link contract, extended by the effects `delete` and
`check`.

### Read and write

Every operation has exactly one `effect`:

| Effect | Meaning |
|---|---|
| `read` | returns data, changes nothing |
| `write` | creates or changes data at the target |
| `send` | hands something to a person or system outside the target (message, signal) |
| `delete` | removes data at the target |
| `check` | answers whether a right exists, returns no content |

A tool or route that a server reports at run time (`tools/list`, interface
description) but that its entry does not declare is treated by every module as
the highest data class and as not writable; a call to it ends with
`contract_mismatch` and never reaches the server.

### Identity propagation

A call carries the token of the acting person for exactly the audience of the
entry, obtained by token exchange (`audience=<a>`, `scope=aud-<a>`). A service
identity is used only where `identity` lists `service` and the call has no
person (event-started or scheduled runs), and only through a declared service
account. A module never passes a token on to a third service; a chained
exchange is allowed only for targets named in `downstream`.

Entries of kind `me` accept only `person`: their `identity` is exactly
`[person]`. The realm synchronisation binds the audience of every entry whose
`identity` is `[person]` to persons, so a service token never reaches a
personal-area interface.

### Rights check

The target checks rights on every call with the rights of the identity in the
token (`rights_check: server`). Operations marked `server_and_check_access`
are additionally confirmed by the caller with `check_access` before the call.
A module MAY narrow what it offers (app rights, data class), never widen it.
Entries of kind `mcp` that accept persons MUST offer the standard operations
`describe_access` (effect `read`: which resources and rights the person in the
token has) and `check_access` (effect `check`: up to 100 resources, allowed or
not, no content and no titles), and MUST declare both in `operations[]` as
well.

### Data classes

One scale of eight classes, lowest first: `public`, `internal`,
`partner_contact`, `personal`, `employee`, `confidential`, `special`,
`professional_secret`. `data_class_max` of an operation or event is the
highest class it can carry. A consumer never lowers a declared class.

### Audit

Every operation with effect `write`, `send` or `delete`, every rejection and
every call under a service account produces one event in the format
`papaia.audit/1` at the caller and at the server, with the correlation id of
the request (`X-Papaia-Correlation-Id`, MCP `_meta.correlation_id`). The event
names the catalog `id`, the operation `name` and its `effect`. Tokens, payloads,
titles and search texts are never written to the audit.

### Error model

Errors use the shared envelope `{code, class, message, hint, correlation_id,
retryable}` with the fixed set of classes (`unauthenticated`,
`forbidden_or_not_found`, `invalid_input`, `conflict`, `rate_limited`,
`upstream_unavailable`, `identity_revoked`, `class_exceeded`,
`contract_mismatch`, `budget_exceeded`). "Not found" and "not allowed" are
indistinguishable for objects.

### Versioning

The section is versioned by its schema file: `exposes.v1` accepts additive
changes only (new optional fields, minor version); an incompatible change
creates `exposes.v2` next to it. Each operation and event carries its own
integer `version`, raised on every incompatible change of its schemas. The core
signals its ability to process the section by contract generation 7; a module
declares the generations it needs in `requires.addon_api`. The catalog adds a
`content_hash` per entry; approvals in modules bind to that hash.

## Entry fields

| Field | Required | Meaning |
|---|---|---|
| `id` | yes | `^[a-z0-9][a-z0-9._-]{0,127}$`, unique, stable |
| `kind` | yes | `mcp` (tool server), `rest` (REST interface), `ui` (user interface), `me` (personal-area interface of the module) |
| `title` | yes | plain text `{de, en}`, at most 80 characters per language |
| `description` | no | plain text `{de, en}`, at most 300 characters per language |
| `address` | `mcp`, `rest`, `me`; not allowed for `ui` | internal address `{service, port, scheme, path}`; `service` is the compose service, which the core resolves to the container name; `scheme` defaults to `http`, `path` to `/` |
| `audience` | `mcp`, `rest`, `me` | audience at the target: `mcp-<system>`, `papaia-<module>[-<surface>]`, or the kept names `flow` and `assist-api` |
| `identity` | yes | non-empty list of `person`, `service`; exactly `[person]` for `me` |
| `operations` | `mcp`, `rest`; not allowed for `ui` | capability description, see [Operations](#operations) |
| `events` | no | events the entry emits, see [Events](#events) |
| `ui` | `ui` only | navigation surfaces, see [User interface](#user-interface) |
| `downstream` | no | catalog ids, or `{kind: catalog_sources}`, the entry may reach by chained exchange |
| `standard_operations` | `mcp` with `person` | subset of `describe_access`, `check_access` |
| `roles` | no | realm roles `{name, title, description}` the core creates; `name` is `<module>-<role>` |
| `service_accounts` | no | see [Service accounts](#service-accounts) |
| `delegation` | no | the module may hold delegations, see [Delegation](#delegation) |
| `header_identity` | no (default `false`) | the service accepts a person's identity from a request header, see [Header identity](#header-identity) |
| `models` | no | model needs, see [Models](#models) |
| `requires` | no | `{addon_api: [n], addons: [{id, optional}]}` |
| `volumes` | for own volumes | see [Volumes and backup](#volumes-and-backup) |
| `export` | with personal data | see [Exit export](#exit-export) |
| `storage` | with personal data | see [Storage declaration](#storage-declaration) |

Unknown fields are rejected at every level. In particular `trust`, `branding`,
`state`, `public_url`, `content_hash`, `ca` and `azp` are not manifest fields:
the core sets them in the rendered catalog (`trust: platform` only for entries
of the suite's bill of materials; the brand has exactly one source, the
catalog's top-level `branding`).

## Operations

| Field | Required | Values |
|---|---|---|
| `name` | yes | tool name or `operationId`, `^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$` |
| `version` | yes | integer ≥ 1 |
| `title` | yes | plain text `{de, en}` |
| `description` | no | plain text `{de, en}` |
| `via` | yes | `tools` (MCP) or `rest` |
| `method`, `path` | with `via: rest` only | HTTP method; path on the entry's address, `{name}` segments are placeholders |
| `effect` | yes | `read`, `write`, `send`, `delete`, `check` |
| `retry` | yes | `safe` (repeat freely), `idempotent` (repeat with the same input has the same result), `at_most_once` (never repeated automatically) |
| `input_schema` | yes | JSON Schema 2020-12 with `type: object`, see [Embedded schemas](#embedded-schemas) |
| `output_schema` | yes | JSON Schema 2020-12, see [Embedded schemas](#embedded-schemas) |
| `data_class_max` | yes | data class |
| `resource` | with `write`, `delete`, `check` | `{type, id_field}`: kind of resource and the input field holding its id; only a create (`effect: write` with `retry: at_most_once`) may leave out `id_field`, because it names no existing object yet |
| `rights_check` | yes | `server` or `server_and_check_access` |
| `role_hint` | no | display only, at most 80 characters, never used for a decision |
| `timeout` | no | `^[0-9]{1,6}(ms\|s\|m)$` |

The kit's server suite compares `operations[]` with the tools a server reports
at run time: every reported tool is declared and every declared operation is
reported.

### Embedded schemas

`input_schema`, `output_schema` and `payload_schema` are complete JSON Schema
2020-12 documents. They are self-contained: every `$ref` and `$dynamicRef`
starts with `#` and points into the same document, and `$schema`, when present,
is the 2020-12 meta-schema. An embedded schema MUST NOT contain `$id` at any
depth, so it never moves its base URI and never claims an identifier such as the
meta-schema's or another module's; it is known only by its place in the
manifest. `$anchor` and `$dynamicAnchor` are allowed, since they name a place
inside the document. The 2019-09 keywords `$recursiveRef` and `$recursiveAnchor`
are rejected. A consumer MUST NOT resolve remote references when it loads or
compiles an embedded schema, and compiles each embedded schema on its own,
without adding it to a registry shared with other schemas. The check walks
every object of the embedded schema, so a property or a `const` value named
`$id` is rejected as well. Each `pattern` is an ECMA-262 regular
expression; the schema cannot check that it compiles, so the manifest
conformance check does (see [Checks beyond the schema](#checks-beyond-the-schema)).

## User interface

Entries of kind `ui` list their surfaces in `ui[]`:
`{id, title, summary, example, icon, order, host_key, path, visible_for_roles,
targets, admin_url, opens_in}`. `summary` has at most 15 words per language
and is shown in the module switcher and on the start page; `example` is the
example sentence of the entry page. `targets` maps a target name to
`{pattern, after_done}`: a path with placeholders and, optionally, the path to
go to once the task is done. `host_key` selects the public host the core
assigns; `path`, `pattern`, `after_done` and `admin_url` are paths on that host,
never absolute URLs. The core adds `public_url` and the state
(`running`/`stopped`) in the catalog. `visible_for_roles` decides only what the
switcher shows; the module still checks rights on every request.

## Events

`events[]` lists `{name, version, title, payload_schema, data_class_max}`.
`name` is dotted lower case (`flow.run.finished`). A receiver rejects, counts
and logs an event whose payload does not match `payload_schema`.

## Service accounts

A module declares each account it needs in `service_accounts[]`. The core's
realm synchronisation creates exactly the declared accounts with exactly the
declared rights and nothing else.

| Field | Required | Meaning |
|---|---|---|
| `id` | yes | `svc-<module>-<purpose>`; one account per purpose, never shared between purposes; the earlier `svc-<module>-prefs` names are not accepted |
| `purpose` | yes | plain text `{de, en}` shown to the operator |
| `owner_sub` | yes | responsible person (OIDC `sub`) |
| `deputy_sub` | yes | deputy of the responsible person; MUST differ from `owner_sub` |
| `roles` | no (default empty) | realm roles of the account, e.g. `prefs-read` |
| `audiences` | yes | audiences the account may obtain with `client_credentials` and `scope=aud-<a>`; at most 12 |
| `effects` | yes | effects the account uses (`read`, `write`, `send`, `delete`, `check`) |
| `realm_management_roles` | no (default empty) | roles of the identity provider's `realm-management` client; each one is shown at installation and needs explicit confirmation |
| `credential` | yes | `private_key_jwt`; client secrets are not accepted |

A manifest is written before the installation exists, so `owner_sub` and
`deputy_sub` MAY be a placeholder `${NAME}` (upper case). The core resolves it
from the module's install input and refuses to create the account while a
placeholder is unresolved or both resolve to the same person.

Interactive sign-in is technically impossible for service accounts (no
authorization code flow). Service tokens carry no `sid`; audiences that accept
only `person` reject them. Rotation is a command of the core
(`service-account rotate <id>`): a new key pair is registered, the old key is
rejected after at most 60 seconds, and the rotation is an audit event. The
last use of each account is recorded by the audit service. When the
responsible person is locked, the account is flagged as without responsible
person and its runs stop after 30 days.

## Delegation

`delegation: {purposes[], max_idle_days, max_age_days}` declares that the
module may hold delegations of persons (offline sessions). The purposes are
fixed in the kit; a manifest lists ids only, and the personal area shows a
fixed sentence for each one:

| Purpose | Holder | Used for |
|---|---|---|
| `flow.run` | Flow | steps of the person's own runs; schedules under a person's identity are not allowed |
| `assist.event` | assistant | event rules |
| `assist.room-check` | assistant | checks in group rooms, with the person's own consent |
| `assist.tools` | assistant | tools outside a session, such as checking links before delivery |

The ids are sealed with the delegation, so a database writer cannot widen them.

`max_idle_days` and `max_age_days` are each at most 365 days, and `max_idle_days` is not greater than
`max_age_days`. They state the longest lifetime the module is built for; they do not set the lifetime. The
lifetime in effect is one setting per installation, chosen by the administration and published by the core in
the platform catalog (`delegations.idle_days`, default 90, and `delegations.max_days`, default 180; in security
profile `kritis` at most 7 and 30 days, see [`platform-services.md`](platform-services.md#26-delegation-lifetime)).
A holder, and the personal area, never computes an expiry date from these declared values or from a number of
its own: cards, receipts and the delegation list show dates from the published setting.

A delegation is held at exactly one client. `delegation` is allowed only in the manifest of the purpose's holder:
`flow.*` only for Flow (client `flow-engine`), `assist.*` only for the assistant (client `assist-gate`). A
manifest of any other module MUST NOT declare `delegation`, and a manifest MUST NOT list a purpose of another
holder. The manifest conformance check fails otherwise, and the core's realm sync rejects such a manifest and
assigns `offline_access` only to `flow-engine` and `assist-gate`. A module without a valid `delegation` holds no
delegations.

## Header identity

`header_identity: true` declares that the service behind the entry accepts a
person's identity from a request header set by the edge or by a gate in front
of it (Paperless with `X-Papaia-Remote-User`). Such a service believes whoever
can reach it, so it must never be reachable past the edge.
A missing field is `false`; any value other than `true` or `false` is rejected.
A marked entry lists `person` in `identity`.

The core reads the marker from the manifest and never publishes a host port
for the service of a marked entry: `--allow-direct-port-access` and
`no_proxy` do not apply to it, also on `127.0.0.1`, and `setup` and `doctor`
abort when a port would be published. The same rule holds for `me-web` and for
every module that declares `delegation`. Like `delegation`, the marker serves
the core alone and is not rendered into the catalog. The manifest conformance
check reports the marked entries of each manifest (`header_identity.<file>`).

Mark every entry whose service takes the identity from a header, including the
user interface entry of a module whose web interface signs persons in that
way. An entry whose service checks a token itself carries no marker.

## Models

`models: {needs: [{alias, features, min_context, max_class}]}` names the model
aliases (`papaia-<purpose>`) and features (`chat`, `tools`, `json_schema`,
`json_object`, `stream`, `embeddings`) the module needs, the minimum context
and the highest data class it sends. Modules never name a model or provider.

## Dependencies

`requires: {addon_api: [n], addons: [{id, optional}]}`: the contract
generations the module needs (7 or higher) and other modules it depends on.
`optional: true` means the module works without the other one and offers less.

## Volumes and backup

`volumes[]` lists every named volume of the module as one backup item:
`{name, backup, reason}`. `backup: include` puts the volume into every backup;
`backup: exclude` keeps it out and needs a `reason`. Excluded are the keys that
must not return with a restore: delegation keys, revocation list keys,
lifecycle keys and the local copy of the erasure journal. The core's `doctor`
checks the declaration against its list of excluded volumes, and `backup`
checks that no excluded file is in the archive and every included item is.
Databases are backed up logically by the module's backup hook; the volume entry
still declares whether the item is kept.

## Exit export

`export: {exit: {format, schema}}` names the format (`<name>/<major>`) and the
schema of the module's exit export. It is required when `storage.personal_data`
is true.

## Storage declaration

`storage: {personal_data, categories[], retention, secrets[]}` feeds the
personal area ("my data") and the privacy documentation.

- `personal_data` is required. When it is true, `categories` (at least one) and
  `retention` are required, and so is `export`.
- Each category is `{id, title, purpose, legal_basis, retention, data_class,
  erasure, on_request}`.
- `retention` is `{days}` or `{until}` (`account_deleted`,
  `deleted_by_person`, `legal_obligation`), optionally with a `note`.
- `erasure` is the deletion path: `retention` (deleted when the retention ends),
  `me_api` (the person deletes in the personal area), `person_erase` (deleted
  by the erasure of a person through the erasure journal), `on_request` (only
  on request). Every category is also covered by the erasure of a person.
- A category with `erasure: on_request` MUST declare
  `on_request: {action, way, responsible}`; other categories MUST NOT. A
  category on request without an action is reported as `fail` by `doctor`.
- `secrets[]` declares where the module keeps secrets: `{kind, location}` with
  `kind` `file`, `database` or `keyring` and `location` the volume.

## Health

Every module serves `/healthz` (`GET`) without sign-in. The body follows
[`schemas/healthz.v1.schema.json`](../schemas/healthz.v1.schema.json):
`{"status": "ok" | "degraded" | "down"}` and nothing else: no versions, no
service names, no reasons. Reasons are available only to the operations role, through the core's
diagnostics. Every module also reports the gauge `revocations_age_seconds`
(age of the revocation list it last applied) under `/metrics`.

## Plain text

`title`, `description`, `summary`, `example`, `purpose`, `legal_basis`, `way`,
`reason`, `note` and `role_hint` are plain text. At least one of `de` and `en`
is present; a missing language falls back to the other. Titles have at most 80
and descriptions at most 300 characters per language. Control characters,
zero-width and direction-changing characters, markup (`<`, `>`), links
(`scheme://`, `www.`, `javascript:`) and Markdown links are rejected.

Every pattern of the schema ends at the end of the input
(`$(?![\s\S])`), so a value with a trailing line feed is rejected by Python
and ECMA-262 validators alike.

## Checks beyond the schema

The schema cannot compare values. The kit's manifest conformance check
(`papaia-kit conformance manifest`) additionally verifies:

- every `id` is unique across all sections of the installation;
- names (audiences, roles, service accounts) follow the naming register and
  use no removed name; an add-on manifest names its module with a prefix
  outside the reserved namespaces; roles in `roles[]` and service account ids
  carry the module's own prefix, and service accounts ask only for the
  module's own roles or `prefs-read`;
- `resource.id_field` names a property of `input_schema`;
- every `pattern` and every key of `patternProperties` in an embedded schema
  compiles as an ECMA-262 regular expression;
- `delegation` is declared only by the holder of each of its purposes
  (`flow.*` by Flow, `assist.*` by the assistant, see [Delegation](#delegation));
- `deputy_sub` differs from `owner_sub`, `max_idle_days` ≤ `max_age_days`;
- entries with `header_identity: true` are reported per manifest (a report,
  not a failure);
- every name in `volumes[]` and `storage.secrets[].location` is a volume of
  the module;
- plain text contains no text shaped like an instruction to a model.

The checks, the command and the JUnit result are described in
[`conformance.md`](conformance.md).

## Examples

One example per kind. Each block is a complete, valid section.

### Example: tool server (`mcp`)

```yaml
exposes:
  - id: probe.notes
    kind: mcp
    title: {de: "Probe-Notizen", en: "Probe notes"}
    address: {service: probe-mcp, port: 8000, path: /mcp}
    audience: mcp-probe-notes
    identity: [person]
    standard_operations: [describe_access, check_access]
    operations:
      - name: read_note
        version: 1
        title: {de: "Notiz lesen", en: "Read note"}
        via: tools
        effect: read
        retry: safe
        input_schema:
          type: object
          additionalProperties: false
          required: [note_id]
          properties:
            note_id: {type: string, maxLength: 64}
        output_schema: {type: object}
        data_class_max: internal
        rights_check: server
      - name: delete_note
        version: 1
        title: {de: "Notiz löschen", en: "Delete note"}
        via: tools
        effect: delete
        retry: idempotent
        input_schema:
          type: object
          additionalProperties: false
          required: [note_id]
          properties:
            note_id: {type: string, maxLength: 64}
        output_schema: {type: object}
        data_class_max: internal
        resource: {type: note, id_field: note_id}
        rights_check: server
      - name: describe_access
        version: 1
        title: {de: "Eigene Rechte anzeigen", en: "Describe own access"}
        via: tools
        effect: read
        retry: safe
        input_schema: {type: object, additionalProperties: false}
        output_schema: {type: object}
        data_class_max: internal
        rights_check: server
      - name: check_access
        version: 1
        title: {de: "Rechte prüfen", en: "Check access"}
        via: tools
        effect: check
        retry: safe
        input_schema:
          type: object
          additionalProperties: false
          required: [resources, right]
          properties:
            resources: {type: array, maxItems: 100}
            right: {enum: [read, write, delete]}
        output_schema: {type: object}
        data_class_max: internal
        resource: {type: note, id_field: resources}
        rights_check: server
    events:
      - name: probe.note.deleted
        version: 1
        title: {de: "Notiz gelöscht", en: "Note deleted"}
        payload_schema:
          type: object
          additionalProperties: false
          properties:
            note_id: {type: string}
        data_class_max: internal
```

### Example: REST interface (`rest`)

The former Flow entry of kind `flow_provider` becomes:

```yaml
exposes:
  - id: flow.runs
    kind: rest
    title: {de: "Abläufe starten", en: "Start workflows"}
    address: {service: papaia-flow-api, port: 8080}
    audience: flow
    identity: [person]
    operations:
      - name: start_run
        version: 1
        title: {de: "Ablauf starten", en: "Start workflow"}
        via: rest
        method: POST
        path: /api/v1/workflows/{workflow_id}/runs
        effect: write
        retry: at_most_once
        input_schema:
          type: object
          additionalProperties: false
          required: [workflow_id]
          properties:
            workflow_id: {type: string, maxLength: 64}
        output_schema: {type: object}
        data_class_max: confidential
        resource: {type: workflow, id_field: workflow_id}
        rights_check: server
      - name: send_signal
        version: 1
        title: {de: "Signal senden", en: "Send signal"}
        via: rest
        method: POST
        path: /api/v1/runs/{run_id}/signals
        effect: send
        retry: idempotent
        input_schema:
          type: object
          additionalProperties: false
          required: [run_id, signal]
          properties:
            run_id: {type: string, maxLength: 64}
            signal: {type: string, maxLength: 64}
        output_schema: {type: object}
        data_class_max: confidential
        rights_check: server
      - name: list_tasks
        version: 1
        title: {de: "Meine Aufgaben", en: "My tasks"}
        via: rest
        method: GET
        path: /api/v1/me/tasks
        effect: read
        retry: safe
        input_schema: {type: object, additionalProperties: false}
        output_schema: {type: object}
        data_class_max: confidential
        rights_check: server
    service_accounts:
      - id: svc-flow-events
        purpose: {de: "Ereignisläufe Rechnungseingang", en: "Event runs for incoming invoices"}
        owner_sub: ${PAPAIA_FLOW_EVENTS_OWNER_SUB}
        deputy_sub: ${PAPAIA_FLOW_EVENTS_DEPUTY_SUB}
        audiences: [mcp-paperless]
        effects: [read]
        credential: private_key_jwt
    delegation:
      purposes: [flow.run]
      max_idle_days: 90
      max_age_days: 180
    requires:
      addon_api: [12]
    volumes:
      - name: flow-db
        backup: include
      - name: flow-delegation-key
        backup: exclude
        reason: {de: "Vollmachtsschlüssel", en: "Delegation key"}
    export:
      exit: {format: papaia.flow-export/1, schema: schemas/flow-export-1.json}
    storage:
      personal_data: true
      retention: {days: 1095}
      categories:
        - id: runs
          title: {de: "Läufe", en: "Runs"}
          purpose: {de: "Nachweis der Läufe", en: "Record of runs"}
          legal_basis: {de: "Art. 6 Abs. 1 lit. f DSGVO", en: "Art. 6(1)(f) GDPR"}
          retention: {days: 1095}
          data_class: personal
          erasure: retention
      secrets:
        - {kind: file, location: flow-delegation-key}
```

### Example: user interface (`ui`)

```yaml
exposes:
  - id: flow.console
    kind: ui
    title: {de: "Flow", en: "Flow"}
    identity: [person]
    ui:
      - id: flow
        title: {de: "Flow", en: "Flow"}
        summary: {de: "Abläufe bauen, freigeben und Läufe verfolgen", en: "Build, approve and track flows"}
        example: {de: "Rechnungseingang prüfen und an die Buchhaltung geben", en: "Check incoming invoices and route them"}
        icon: flow
        order: 30
        host_key: flow
        path: /
        visible_for_roles: [flow-member, flow-admin]
        targets:
          run: {pattern: "/runs/{run_id}", after_done: /runs}
        opens_in: same_tab
    roles:
      - name: flow-member
        title: {de: "Abläufe nutzen", en: "Use workflows"}
      - name: flow-admin
        title: {de: "Flow verwalten", en: "Manage Flow"}
```

### Example: personal-area interface (`me`)

The address and audience of the module's interface for the personal area; the
interface itself follows the personal-area contract.

```yaml
exposes:
  - id: studio.me
    kind: me
    title: {de: "Studio in Mein Bereich", en: "Studio in my area"}
    address: {service: studio-gateway, port: 8080, path: /api/me}
    audience: papaia-studio-me
    identity: [person]
```
