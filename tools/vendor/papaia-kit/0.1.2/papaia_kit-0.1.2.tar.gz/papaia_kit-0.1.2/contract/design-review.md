# Design checks and review list for module pull requests

A page that passes every functional test can still look unfinished: browser
default fonts, buttons that touch, gaps off the spacing scale, lines that run
across the whole screen. This file names the automatic design checks that
catch these defects and the review list that covers what a check cannot see.
The visual target is the set of composed reference pages in
`examples/pages/` (`specimen.md`, section "Composed reference pages") and the
specimen page `/_kit/specimen`. This file is normative.

## Automatic design checks: `pk-conform --design`

```sh
pk-conform --design --base-url URL --page PATH [--page PATH ...] [--known a11y-known.yaml]
           [--lang de|en] [--themes light,dark] [--storage-state FILE] [--report FILE]
```

Every page given with `--page` (the pages of the module's page list) is
opened in both themes. At 1440 × 900 and at 390 × 844 the following rules
hold; a page passes when none is broken:

| Check | Rule |
|---|---|
| `font` | No text is drawn in a font outside the kit's: the first family of every element with text of its own is one of `--pk-font-body`, `--pk-font-brand`, `--pk-font-mono`. A browser default (`serif`, `Times New Roman`, `monospace`, …) fails. |
| `spacing-scale` | Inside `#pk-main`, the vertical gap between two block siblings stacked on top of each other (block flow or a column flex box) is a multiple of 0.25rem (4 px, ± 0.5 px). Grids and rows of flex items are aligned, not spaced, and are not measured. |
| `target-gap` | Inside `#pk-main`, no two interactive elements (links styled as buttons, buttons, form controls, `summary`, elements with `tabindex ≥ 0`) are closer than 8 px. A checkbox or radio counts with its label; links inside running text are exempt (WCAG 2.5.8, inline targets); an element is not measured against the interactive element that contains it; the items of one open menu panel form one control. |
| `primary-action` | At most one primary button in `page-header`. |
| `measure` | The widest line of a paragraph in `#pk-main` holds at most 80 characters (the width of "0" in the paragraph's font, the `ch` unit). |
| `narrow-text` | Inside `#pk-main`, no box of text of its own (other than an inline element, a table cell or a text hidden for screen readers) is narrower than 120 px while its text wraps, if its parent is wider than 400 px or the text runs over three lines or more. Text on one line (a count, a badge) is never narrow. It catches a column squeezed to a sliver by its neighbour, such as the value of a description list next to a fixed term column. |
| `outline` | No element without focus draws an outline. An outline is the keyboard focus ring; a block that stays framed (a focus ring left standing, a highlighted section) fails. |
| `reflow` | At 320 × 640 the page does not scroll horizontally (`scrollWidth ≤ innerWidth`; tables scroll in their own container). |
| accessibility | The axe run of `pk-audit` (WCAG 2.1 A/AA, at rest, menus open, first dialog open): no `critical` or `serious` violation, every other one listed in `a11y-known.yaml`. |

The report (`papaia.pk-design/1`) lists the findings per page, theme and
width with the place and the measured value. Exit codes: 0 passed, 1 a
finding, 2 usage (checked before a browser starts). The check is a command
the module's CI calls next to `pk-conform` and `pk-audit`; it reads pages only
and grants nothing.

## Review list

A reviewer of a module pull request that adds or changes a page opens the page
next to the composed reference page of the same kind (overview, settings,
list, state) and checks:

1. **Hierarchy.** One `h1` in the page header, sections with `h2`, cards and
   tiles with `h3`; the most important information first; at most one primary
   button per view, further actions in the menu "Weitere Aktionen".
2. **Spacing.** Gaps only from the spacing scale (the design check measures
   them); related things close together, sections clearly apart; no element
   glued to the edge of its card or table.
3. **Density.** Lists and tables show what a person needs to decide, not every
   field; long texts stop at the measure; numbers in the column class `pk-num`, dates
   in the form of pattern 9 with the weekday where the kind of date asks for it.
4. **States.** Empty, loading, error, no access, disabled with a reason and
   invalid with an error summary are designed, not left to chance; the page
   reads the same in every state (`/_kit/specimen` shows each one).
5. **Both themes.** Light and dark checked by eye; no colour outside the
   tokens, no text on a surface without the contrast of the token pairs.
6. **390 px.** The page works at 390 × 844: no horizontal scroll, buttons
   reachable, tables scroll in their container, nothing overlaps.

`make shots` in the kit renders the composed pages and the specimen in both
themes at 1440 × 900 and 390 × 844 for this comparison.
