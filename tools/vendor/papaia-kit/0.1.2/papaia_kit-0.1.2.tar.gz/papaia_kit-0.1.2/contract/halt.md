# Platform halt guard

| | |
|---|---|
| Python | `papaia_kit.halt.HaltGuard` |
| State file | `$PAPAIA_CONFIG_DIR/state/halt.json`, written only by the core |
| Mount in a module | the folder `state/`, read-only, path in `PAPAIA_HALT_DIR` |
| Refusal | error code `PK-HALT-001` (class `upstream_unavailable`, HTTP 503) |
| Vectors | `vectors/halt.json` (`papaia.vectors.halt/1`) |
| Conformance | `papaia-kit conformance halt` ([`conformance.md`](conformance.md#halt)) |

This document is normative. The key words MUST, MUST NOT, SHOULD and MAY are
used as in RFC 2119.

One host command of the core stops every write, send and delete of the whole
installation, every model call, flow step and delivery (security 4.11, PLT-61,
OPS-20). It writes the state file by renaming a complete file into place. The
kit guard is the one reader every module uses, so that all modules check the
same things at the same moments and fail the same way.

## State file

```json
{"active": true, "by": "host:ops", "reason": "incident 42", "since": 1790000000}
```

| Field | Rule |
|---|---|
| `active` | boolean |
| `since` | integer, seconds since the epoch, 0 to 2^63 - 1 |
| `reason` | string of at most 500 characters |
| `by` | string of 1 to 255 characters |

The file has exactly these four fields, each once, and is at most 4096 bytes
of UTF-8 JSON. The guard never logs, shows or audits `reason` and `by`.

## Mount

A module MUST mount the folder `state/`, never the file: the core replaces the
file by a rename, and a container that mounted the file keeps the old one. The
mount MUST be read-only. The module passes the mount point in
`PAPAIA_HALT_DIR` (an absolute path); `HaltGuard.from_env()` reads it. Without
the variable the guard is off (stand-alone operation); with `PAPAIA_MODE=suite`
a missing variable is a start error.

## When the guard reads

| Moment | Call |
|---|---|
| Before each write, send or delete | `guard.require(Action.WRITE \| SEND \| DELETE, correlation_id=..., principal=..., request=...)` |
| Before each model call | `guard.require(Action.MODEL, correlation_id=...)` |
| Before each flow step | `guard.require(Action.STEP, correlation_id=...)` |
| Before each delivery (mail, notice, reminder) | `guard.require(Action.DELIVERY, correlation_id=...)` |
| Every 5 s, also without an action | `guard.start_polling()` (the notice in every interface, a waiting run) |

Each check costs one `stat` call and no network. The file is parsed again when
its `stat` changed (device, inode, type, size, modification and change time)
and at least every 5 s. A halt therefore holds for the next action after the
command returned, well within the 10 s for writes, sends and deletes
(OPS-20-A3, wording of Ä-39) and the 60 s for everything else (PLT-61-A1).
Reading one's own data is never guarded.

## Fail closed

| State | Result |
|---|---|
| no file in an existing folder, never seen one | no halt |
| valid file, `active: false` | no halt |
| valid file, `active: true` | halt |
| not UTF-8, not JSON, a duplicate, missing or unknown field, a wrong type or length, larger than 4096 bytes | halt |
| a symbolic link, a folder or a named pipe in place of the file, a file that cannot be opened or read | halt |
| the file is gone after the guard saw one (the core never removes it) | halt |
| the folder is missing (not mounted) | halt |

The guard only reads. It MUST NOT create or change the folder or the file. A
named pipe is opened without blocking.

## Refusal and audit row

`require` raises `PlatformHalted` with an error envelope for `PK-HALT-001`
(HTTP 503, `retryable`), the state and the action. For a write, send or delete
it first hands one `papaia.audit/1` row to the guard's audit writer:

| Field | Value |
|---|---|
| `result` | `denied` |
| `event` | `operation` |
| identity and token times | `principal.audit_fields()` (with `correlation_id`) |
| `catalog_id`, `operation`, `effect` | from the request; `effect` equals the action |
| `error_code` | `PK-HALT-001` |
| `writer` | the guard's `writer` |

The audit writer adds `source_seq`. An exception of the audit writer
propagates; the action is refused either way. A refused model call, step or
delivery writes no row of its own. A write, send or delete without principal,
request and a configured audit writer is a usage error (`ValueError`), also
while no halt is active.

```python
from papaia_kit.halt import Action, HaltGuard, PlatformHalted

guard = HaltGuard.from_env(audit=writer.record, writer="mcp-paperless")
poller = guard.start_polling()  # stop with poller.stop() on shutdown

try:
    guard.require(Action.WRITE, correlation_id=cid, principal=principal, request=request)
except PlatformHalted as halted:
    return error_response(halted.status, halted.envelope)
```

Interfaces show the fixed notice while `guard.check().active` is true; the
error text of `PK-HALT-001` is the same sentence ("Die Plattform ist durch einen
Not-Halt angehalten.").

## Module copies

A module that keeps its own reader (another language, or an existing copy)
MUST pass the `halt` conformance suite with a driver around that reader. The
module's own kill switch stays and is checked in addition.
