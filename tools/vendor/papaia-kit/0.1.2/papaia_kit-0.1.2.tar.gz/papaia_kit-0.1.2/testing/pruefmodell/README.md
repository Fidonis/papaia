# Kit test model (`pruefmodell`)

A scripted stand-in for a language model behind the model gateway, for module
tests and test stacks. It speaks the chat completions interface of the gateway
(`POST /v1/chat/completions`, `GET /v1/models`), answers from a script instead
of a model and records every request, so tests can check what a module sent
and the model suite (`papaia-kit conformance model`) can check that the module
uses only the allowed request features. **Test stacks only.** No product image
contains it; it holds synthetic data only.

In a test stack it runs as container `pruefmodell` and the gateway alias points
at it in the overlay of the gateway configuration. Name the backend model like
the alias, so the recording shows the alias the module asked for:

```yaml
model_list:
  - model_name: papaia-chat
    litellm_params:
      model: <prefix>/papaia-chat        # the gateway's prefix for a backend with this interface, then the alias
      api_base: http://pruefmodell:8080/v1
      api_key: os.environ/PRUEFMODELL_KEY  # any placeholder value; the test model accepts every key
```

A module test can also talk to the test model directly with the alias, as the
module's own CI does.

## Ports

| Port | Interface | Reachable from |
|---|---|---|
| 8080 | `GET /v1/models`, `POST /v1/chat/completions` | the gateway, or the module under test |
| 8081 | control interface | the test suite only |

Anyone who reaches the control port can change every answer: keep both ports on
the internal test network (or on `127.0.0.1`).

## Script

A script is YAML or JSON (at most 256 KiB, unknown fields refused):

```yaml
version: 1
rules:
  - match: {last_user: "(?i)remind me"}           # regex on the last user message
    reply:
      tool_calls: [{name: create_reminder, arguments: {at: "16:00"}}]
  - match: {tool_result: "(?i)created"}           # regex on a tool result as last message
    reply: {text: "The reminder is set."}
  - match: {last_user: "(?i)invoice"}
    reply: {json: {number: "2026-17"}}            # answered as JSON text
  - match: {last_user: "(?i)overloaded"}
    reply: {error: {status: 500, type: server_error}}
default: {text: "Test model answer."}             # optional
```

The first matching rule answers. Each rule has one `match` (`last_user` or
`tool_result`, at most 256 characters) and one reply: `text`, `tool_calls` (1
to 4 calls), `json` or `error` (status 400 to 599, optional `type`, `code`,
`message`). Without a match the `default` answers; without a `default` the
answer is `Test model answer.`, or, when the request asks for JSON, a small
value that satisfies the requested schema (`json_schema`) or `{}`
(`json_object`). `scripts/sample.yaml` is the script the image starts with.

## Modes

| Mode | Answer |
|---|---|
| `normal` | as scripted |
| `no_tools` | text instead of tool calls |
| `no_json_schema` | plain text instead of the requested JSON |
| `invalid_json` | broken JSON where JSON is requested |
| `slow` | as scripted, after the delay (default 35 s, over the 30 s limit of the modules) |
| `status_429` | 429, `error.type` `rate_limit_error` |
| `budget` | 429, `error.type` `budget_exceeded` |
| `status_503` | 503, `error.type` `service_unavailable` |
| `injection` | text (or every string of the JSON) that reads like an instruction to the module |

## Variants

Two answer forms, both permitted by the contract; a test marked `skript` must
pass with both (`--variant a|b`):

| | Variant `a` | Variant `b` |
|---|---|---|
| response `model` | `pruefmodell-a` | `pruefmodell-b` |
| content with tool calls | `null` | `""` |
| `finish_reason` with tool calls | `tool_calls` | `stop` |
| field order | usual | reversed |

`"stream": true` is answered as server-sent events: a chunk with the message,
a chunk with the finish reason and usage, then `data: [DONE]`.

## Control interface

| Request | Effect |
|---|---|
| `PUT /script` (JSON script) | replaces the rules |
| `PUT /mode` `{"mode": "slow", "delay_seconds": 2}` | sets the mode (`delay_seconds` 0 to 120, optional) |
| `GET /recording` | the recording, one JSON line per request (`application/x-ndjson`) |
| `DELETE /recording` | clears the recording |
| `POST /reset` | start script and mode, empty recording |
| `GET /state` | mode, delay, variant, models, number of rules and requests |

Control requests take `application/json` of at most 256 KiB; a broken script
or mode is refused with 400 and the place in `error`.

## Recording

Every request to port 8080 is one JSON line (also appended to `--record FILE`):

```json
{"seq": 1, "at": "2026-11-21T09:00:00.000Z", "method": "POST", "path": "/v1/chat/completions",
 "key_id": "sha256:0123456789abcdef", "headers": {"content-type": "application/json"},
 "body": {"model": "papaia-chat", "messages": [{"role": "user", "content": "..."}]},
 "mode": "normal", "status": 200}
```

- `key_id` is the first 16 hex digits of the sha256 of the presented key
  (`Authorization: Bearer`, `x-api-key` or `api-key`); the key itself is never
  recorded.
- `headers` leaves out every header whose name contains `auth`, `key`,
  `token`, `secret`, `cookie`, `session` or `password`; values are cut at 256
  characters.
- `body` is the request as sent (any field, so the model suite can name the
  forbidden ones); other routes are recorded with `body: null` and answered
  with 404. A chat request that is not an object with `model` and `messages`
  is answered with 400.
- At most 10 000 requests; then every request is answered with 503 until the
  recording is cleared.

## Container

```sh
docker build -t papaia-kit-test-model:0.1.2 testing/pruefmodell
docker run --rm -p 127.0.0.1:8080:8080 -p 127.0.0.1:8081:8081 papaia-kit-test-model:0.1.2
docker run --rm -v "$PWD/scripts:/scripts:ro" papaia-kit-test-model:0.1.2 \
  --script /scripts/case.yaml --variant b --models papaia-chat,papaia-structured
```

The image pins its base image by digest and installs `pyyaml` from
`requirements.txt` with hashes (the version of the kit's `uv.lock`). It runs as
an unprivileged user and listens on `0.0.0.0:8080` and `0.0.0.0:8081` inside
the container. Arguments after the image name replace the default
`--script /app/scripts/sample.yaml`. `--record` needs a writable mount.

Without a container: `python testing/pruefmodell/pruefmodell.py --script
testing/pruefmodell/scripts/sample.yaml` (binds `127.0.0.1:8080` and `:8081`).
