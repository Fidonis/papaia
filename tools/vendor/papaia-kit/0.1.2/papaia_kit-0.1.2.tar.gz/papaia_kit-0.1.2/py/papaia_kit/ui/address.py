"""Links to named targets and to the delegation targets (interface spec 2.5).

The return parameter ``from`` (``<module>:<target>:<key>``) is resolved by
:func:`papaia_kit.catalog.resolve_from` and by nothing else; this module builds
the links that carry it. Every address is built from the catalog's
``public_url`` and the target's ``pattern``; an address passed as a parameter
is never used. A value that does not resolve yields no link. Shared vectors:
``contract/vectors/from.json`` (sections ``cases`` and ``delegation``).

Links are display and navigation only: the target checks rights server-side on
every request.
"""

from __future__ import annotations

from urllib.parse import quote

from papaia_kit.catalog.document import Catalog
from papaia_kit.catalog.return_path import resolve_from

__all__ = [
    "DELEGATION_TARGET",
    "LIST_KEY",
    "delegation_url",
    "target_url",
]

LIST_KEY = "-"
"""Key of a target without placeholder (a list such as ``studio:tasks``)."""
DELEGATION_TARGET = "delegation"
"""Grant page at the holder of a delegation (``flow:delegation``, ``assistant:delegation``)."""

# Characters of the from grammar that stay unescaped in a query value.
_SAFE = ":~-"


def target_url(
    catalog: Catalog,
    module: str,
    target: str,
    key: str = LIST_KEY,
    *,
    from_value: str | None = None,
) -> str | None:
    """Address of ``module:target`` for ``key``, with ``?from=`` when given.

    ``None`` when the module, the target or the key does not resolve, or when
    ``from_value`` would itself be discarded by the target module. A stopped
    module still yields its address; whether the link is shown locked is the
    caller's decision (``ReturnTarget.running``, interface spec 2.4).
    """
    resolved = _resolve(catalog, f"{module}:{target}:{key}")
    if resolved is None:
        return None
    if from_value is None:
        return resolved
    if _resolve(catalog, from_value) is None:
        return None
    return f"{resolved}?from={quote(from_value, safe=_SAFE)}"


def delegation_url(catalog: Catalog, holder: str, return_to: object) -> str | None:
    """Grant page of ``holder`` with ``return_to``; ``None`` when either does not resolve.

    The holder answers ``303`` to the address that ``return_to`` resolves to
    after the grant or the cancellation; ``return_to`` is a ``from`` value, so
    only own paths of the platform hosts in the catalog are reachable.
    """
    if _resolve(catalog, return_to) is None:
        return None
    url = target_url(catalog, holder, DELEGATION_TARGET)
    if url is None:
        return None
    return f"{url}?return_to={quote(str(return_to), safe=_SAFE)}"


def _resolve(catalog: Catalog, value: object) -> str | None:
    # Values from a request are untrusted: anything but text is discarded here,
    # resolve_from itself rejects non-text as a programming error.
    if not isinstance(value, str):
        return None
    resolved = resolve_from(catalog, value)
    return resolved.url if resolved is not None else None
