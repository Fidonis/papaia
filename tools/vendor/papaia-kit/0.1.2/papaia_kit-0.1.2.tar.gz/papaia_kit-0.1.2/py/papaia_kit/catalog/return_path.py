"""Return path: resolve a ``from`` parameter to an address of a catalog target.

The calling module appends ``?from=<module>:<target>:<key>`` (oberflaeche 2.5).
The called module turns it into the breadcrumb "Zurück zu <module>" with this
function and nothing else; the TypeScript package implements the same rule,
both are tested against ``contract/vectors/from.json``::

    key = "-"                          target pattern without placeholder
        | <id>                         one placeholder, id = [A-Za-z0-9-]{1,64}
        | <id>~<version>               two placeholders, version = [1-9][0-9]{0,8}

The target ``admin`` stands for the module's ``admin_url`` when the module names
no target of that name. The module must be in the catalog. A stopped module
still resolves, with ``running`` false: the shell shows the locked link of
interface spec 2.4 ("<module> ist gerade nicht erreichbar.") instead of a link.

Anything else is discarded: an unknown module or target, any
character outside the classes above (``/``, ``.``, ``%``, a scheme, white space,
non-ASCII), a key that does not fit the number of placeholders, or a value
longer than :data:`MAX_FROM_LENGTH`. Discarding means ``None``: no breadcrumb,
no redirect, no message. An address passed as a parameter is never evaluated;
the result is always ``public_url`` of the catalog joined with the pattern of
the catalog, so it cannot leave the hosts the catalog names.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from papaia_kit.catalog.document import Catalog

__all__ = ["ADMIN_TARGET", "MAX_FROM_LENGTH", "ReturnTarget", "resolve_from"]

MAX_FROM_LENGTH = 256
"""Longest ``from`` value that is parsed at all."""

ADMIN_TARGET = "admin"
"""Target name that stands for ``admin_url``."""

# Explicit ASCII classes; fullmatch, so no trailing line break slips through.
_FROM = re.compile(
    r"(?P<module>[a-z0-9][a-z0-9._-]{0,127})"
    r":(?P<target>[a-z][a-z0-9_]{0,39})"
    r":(?P<key>[A-Za-z0-9~-]{1,74})"
)
_ID = re.compile(r"[A-Za-z0-9-]{1,64}")
_VERSION = re.compile(r"[1-9][0-9]{0,8}")
_PLACEHOLDER = re.compile(r"\{[a-z][a-z0-9_]{0,39}\}")
_LIST_KEY = "-"
# Number of placeholders that takes <id>~<version>.
_ID_AND_VERSION = 2


@dataclass(frozen=True)
class ReturnTarget:
    """Where the breadcrumb "Zurück zu <title>" leads."""

    module: str
    """Switcher id of the calling module."""
    target: str
    """Target name in that module."""
    title: Mapping[str, str]
    """Module title ``{de, en}`` from the catalog."""
    url: str
    """Absolute address of the object in the calling module."""
    after_done: str | None
    """Absolute address of the target's ``after_done`` path, if the target names one."""
    running: bool
    """False for a stopped module: the shell shows a locked link (interface spec 2.4)."""

    def label(self, lang: str) -> str:
        """Display name of the module in ``lang``, German when that language is missing."""
        return self.title.get(lang) or self.title["de"]


def resolve_from(catalog: Catalog, value: str | None) -> ReturnTarget | None:
    """Return address for ``value`` of the ``from`` parameter, or ``None`` to discard it."""
    match = _parse(value)
    if match is None:
        return None
    surface = catalog.surface(match["module"])
    if surface is None:
        return None
    target = _target(surface.data, match["target"])
    if target is None:
        return None
    pattern, after_done = target
    values = _key_values(match["key"], len(_PLACEHOLDER.findall(pattern)))
    if values is None:
        return None
    filled = iter(values)
    path = _PLACEHOLDER.sub(lambda _: next(filled), pattern)
    base = surface.public_url.rstrip("/")
    return ReturnTarget(
        module=surface.id,
        target=match["target"],
        title=surface.title,
        url=base + path,
        after_done=base + after_done if after_done is not None else None,
        running=surface.running,
    )


def _parse(value: str | None) -> re.Match[str] | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError("from must be a string")
    if len(value) > MAX_FROM_LENGTH:
        return None
    return _FROM.fullmatch(value)


def _target(ui: Mapping[str, Any], name: str) -> tuple[str, str | None] | None:
    targets = ui.get("targets") or {}
    if name in targets:
        target = targets[name]
        return target["pattern"], target.get("after_done")
    if name == ADMIN_TARGET and "admin_url" in ui:
        return ui["admin_url"], None
    return None


def _key_values(key: str, placeholders: int) -> tuple[str, ...] | None:
    if placeholders == 0:
        return () if key == _LIST_KEY else None
    if placeholders == 1:
        return (key,) if key != _LIST_KEY and _ID.fullmatch(key) else None
    if placeholders == _ID_AND_VERSION:
        ident, sep, version = key.partition("~")
        if not sep or ident == _LIST_KEY or not _ID.fullmatch(ident):
            return None
        return (ident, version) if _VERSION.fullmatch(version) else None
    return None
