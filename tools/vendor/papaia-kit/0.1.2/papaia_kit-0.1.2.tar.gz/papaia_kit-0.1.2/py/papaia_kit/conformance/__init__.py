"""Conformance suites for consumers and providers of the contract, with test vectors.

``papaia-kit conformance <suite>`` runs a suite and writes JUnit XML:

- ``manifest``: the section ``exposes:`` against the schema, names against the
  register and the checks beyond the schema (``contract/exposes.md``); it reports
  the entries marked ``header_identity`` per manifest;
- ``catalog-consumer``: the shared catalog reader vectors against the kit reader
  or a module's own reader behind a driver command;
- ``recording``: a provider recording against its format and a pinned digest;
- ``static``: server code against the rules on generated code execution, built
  queries, built scopes and hard-coded model names;
- ``realm``: clients with token exchange versus audiences, read from a realm
  export or read-only from the admin API (separation rule, security 1.2);
- ``model``: the requests a module sent to the kit test model against the
  allowed request features and its declared model needs (M-03);
- ``server``: a running MCP server against its declaration, with tokens of the
  kit test issuer (``tools/list``, standard operations, error envelope, audit
  row per write, refusal of foreign audience, foreign ``azp`` and several
  audiences); with ``--record`` it also writes the provider recording;
- ``injection``: the shared corpus of injected instructions against a module
  behind a driver, with the test model obeying every instruction (PLT-60);
- ``me-v2``: a running personal-area module API against its declaration
  (``412``/``428``, idempotency, field errors, fresh sign-in, deletion
  receipt); with ``--record`` it also writes the provider recording;
- ``handover``: the digest of the Data to Studio handover schema against the
  digest Studio pins and the one of the bill of materials;
- ``halt``: the shared platform halt vectors against the kit guard or a
  module's halt check behind a driver command (PLT-61).

See ``contract/conformance.md``.
"""

from papaia_kit.conformance.catalog_consumer import (
    CommandDriver,
    DriverError,
    DriverFactory,
    KitReaderDriver,
    Observation,
    ReaderDriver,
    run_catalog_consumer,
)
from papaia_kit.conformance.ecma_regex import ecma_pattern_error
from papaia_kit.conformance.halt import (
    HALT_ACTIONS,
    HaltCommandDriver,
    HaltDriver,
    HaltDriverFactory,
    KitHaltDriver,
    run_halt_suite,
)
from papaia_kit.conformance.handover import (
    HANDOVER_CHECKS,
    HANDOVER_CONTRACT,
    HandoverError,
    handover_digest,
    load_pin_file,
    run_handover_suite,
)
from papaia_kit.conformance.injection import (
    CARRIERS,
    RULES,
    Context,
    Corpus,
    CorpusError,
    FunctionDriver,
    InjectionCase,
    InjectionCommandDriver,
    InjectionDriver,
    check_case,
    load_corpus,
    model_reply,
    observation_from_reply,
    run_injection,
)
from papaia_kit.conformance.manifest import (
    DELEGATION_HOLDERS,
    HEADER_IDENTITY_PROPERTY,
    MANIFEST_CHECKS,
    DelegationHolder,
    ManifestError,
    check_manifest_documents,
    check_manifest_files,
    header_identity_entries,
    load_compose_volumes,
    load_manifest,
)
from papaia_kit.conformance.me_v2 import (
    ME_V2_CHECKS,
    MeTarget,
    MeV2SuiteError,
    PersonTokens,
    load_me_declaration,
    record_me_v2_suite,
    run_me_v2_suite,
)
from papaia_kit.conformance.model import (
    MODEL_CHECKS,
    ModelSuiteError,
    check_model_recording_file,
    load_model_needs,
    load_model_recording,
    run_model_suite,
)
from papaia_kit.conformance.realm import (
    CHAIN_HOLDER,
    NEVER_AUDIENCE,
    REALM_CHECKS,
    Fetch,
    Realm,
    RealmError,
    UrllibFetch,
    audiences,
    check_realm,
    check_realm_export_file,
    exchange_clients,
    load_realm_export,
    read_realm_admin,
    realm_from_export,
)
from papaia_kit.conformance.recording import (
    RECORDING_FORMAT,
    RecordingError,
    check_recording_file,
    dump_recording,
    load_recording,
    recording_digest,
    schema_version,
)
from papaia_kit.conformance.result import Case, SuiteResult, junit_xml
from papaia_kit.conformance.server import (
    RECORDING_CHECK,
    SERVER_CHECKS,
    IssuerTokens,
    Provider,
    ServerSuiteError,
    ServerTarget,
    TokenSource,
    load_calls,
    record_server_suite,
    run_server_suite,
    select_entry,
)
from papaia_kit.conformance.static import (
    EXCEPTION_INPUTS,
    SKIP_REASONS,
    SKIPPABLE_DIRS,
    STATIC_RULES,
    Finding,
    Sources,
    StaticException,
    StaticExceptionError,
    collect_sources,
    load_static_exceptions,
    run_static,
    scan_source,
)

__all__ = [
    "CARRIERS",
    "CHAIN_HOLDER",
    "DELEGATION_HOLDERS",
    "HALT_ACTIONS",
    "HANDOVER_CHECKS",
    "HANDOVER_CONTRACT",
    "HEADER_IDENTITY_PROPERTY",
    "MANIFEST_CHECKS",
    "ME_V2_CHECKS",
    "MODEL_CHECKS",
    "NEVER_AUDIENCE",
    "REALM_CHECKS",
    "RULES",
    "RECORDING_CHECK",
    "RECORDING_FORMAT",
    "SERVER_CHECKS",
    "Case",
    "CommandDriver",
    "Context",
    "Corpus",
    "CorpusError",
    "EXCEPTION_INPUTS",
    "SKIPPABLE_DIRS",
    "SKIP_REASONS",
    "STATIC_RULES",
    "DelegationHolder",
    "DriverError",
    "DriverFactory",
    "Finding",
    "Fetch",
    "FunctionDriver",
    "HaltCommandDriver",
    "HaltDriver",
    "HaltDriverFactory",
    "HandoverError",
    "InjectionCase",
    "InjectionCommandDriver",
    "InjectionDriver",
    "IssuerTokens",
    "KitHaltDriver",
    "KitReaderDriver",
    "ManifestError",
    "MeTarget",
    "MeV2SuiteError",
    "ModelSuiteError",
    "Observation",
    "PersonTokens",
    "Provider",
    "ReaderDriver",
    "Realm",
    "RealmError",
    "RecordingError",
    "Sources",
    "StaticException",
    "StaticExceptionError",
    "ServerSuiteError",
    "ServerTarget",
    "SuiteResult",
    "TokenSource",
    "UrllibFetch",
    "audiences",
    "check_case",
    "check_manifest_documents",
    "check_manifest_files",
    "check_model_recording_file",
    "check_realm",
    "check_realm_export_file",
    "check_recording_file",
    "collect_sources",
    "dump_recording",
    "ecma_pattern_error",
    "exchange_clients",
    "handover_digest",
    "header_identity_entries",
    "junit_xml",
    "load_calls",
    "load_compose_volumes",
    "load_corpus",
    "load_manifest",
    "load_me_declaration",
    "load_pin_file",
    "load_model_needs",
    "load_model_recording",
    "load_realm_export",
    "load_recording",
    "load_static_exceptions",
    "model_reply",
    "observation_from_reply",
    "read_realm_admin",
    "record_me_v2_suite",
    "realm_from_export",
    "record_server_suite",
    "recording_digest",
    "run_catalog_consumer",
    "run_halt_suite",
    "run_handover_suite",
    "run_injection",
    "run_me_v2_suite",
    "run_model_suite",
    "run_static",
    "scan_source",
    "run_server_suite",
    "schema_version",
    "select_entry",
]
