"""Error envelope, mapping of module codes to error classes and display texts.

``build_envelope`` turns a module code into the ``error.v1`` envelope
(``schemas/error.v1.schema.json``); ``parse_envelope`` validates a received
one, and ``display_text_for`` rebuilds its texts for a person from code and
class (received texts are never shown). ``display_text`` renders the
three-part message for a person (what happened with its consequence, what to
do, ``Kennung: <correlation id>``) from
``contract/messages/codes.<lang>.yaml``. ``find_forbidden_patterns`` checks
visible text against ``contract/forbidden-patterns.yaml``.
"""

from papaia_kit.errors._catalog import (
    LANGUAGES,
    Catalog,
    CodeText,
    DisplayText,
    check_code_text,
    check_consequence_register,
    check_params,
    class_for_code,
    consequence_text,
    display_text,
    is_known_code,
    load_catalog,
)
from papaia_kit.errors._classes import (
    CLASSES,
    CODE_PATTERN,
    GENERIC_CODE,
    MODULE_PREFIXES,
    ClassSpec,
    ErrorClass,
    is_well_formed_code,
)
from papaia_kit.errors._envelope import (
    CONTENT_TYPE,
    DEFAULT_RETRY_AFTER,
    ErrorEnvelope,
    build_envelope,
    display_text_for,
    normalize_correlation_id,
    parse_envelope,
)
from papaia_kit.errors._patterns import (
    CatalogError,
    ForbiddenPattern,
    PatternHit,
    find_forbidden_patterns,
    has_hidden_characters,
    load_forbidden_patterns,
)

__all__ = [
    "CLASSES",
    "CODE_PATTERN",
    "CONTENT_TYPE",
    "DEFAULT_RETRY_AFTER",
    "GENERIC_CODE",
    "LANGUAGES",
    "MODULE_PREFIXES",
    "Catalog",
    "CatalogError",
    "ClassSpec",
    "CodeText",
    "DisplayText",
    "ErrorClass",
    "ErrorEnvelope",
    "ForbiddenPattern",
    "PatternHit",
    "build_envelope",
    "check_code_text",
    "check_consequence_register",
    "check_params",
    "class_for_code",
    "consequence_text",
    "display_text",
    "display_text_for",
    "find_forbidden_patterns",
    "has_hidden_characters",
    "is_known_code",
    "is_well_formed_code",
    "load_catalog",
    "load_forbidden_patterns",
    "normalize_correlation_id",
    "parse_envelope",
]
