"""Result of a conformance suite and its JUnit XML form."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET  # noqa: S405 - only builds XML, never parses it
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime

# A case reports at most this many messages, so a broken input cannot flood a CI log.
MAX_FAILURES_PER_CASE = 50

# Characters XML 1.0 cannot carry; a message quoting a broken input may contain them.
_NOT_XML = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")


@dataclass(frozen=True, slots=True)
class Case:
    """One check of one input: passed when it has no failures. A suite never skips a case."""

    suite: str
    group: str
    name: str
    failures: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.failures


def case(suite: str, group: str, name: str, failures: Sequence[str]) -> Case:
    """A case with its failures bounded to ``MAX_FAILURES_PER_CASE``."""
    kept = tuple(failures[:MAX_FAILURES_PER_CASE])
    if len(failures) > MAX_FAILURES_PER_CASE:
        kept += (f"... and {len(failures) - MAX_FAILURES_PER_CASE} more",)
    return Case(suite, group, name, kept)


@dataclass(frozen=True, slots=True)
class SuiteResult:
    name: str
    cases: tuple[Case, ...]
    duration: float = 0.0
    # Facts about the run that are not checks, such as files left out (JUnit properties).
    properties: tuple[tuple[str, str], ...] = ()

    @property
    def ok(self) -> bool:
        return all(c.ok for c in self.cases)

    @property
    def failed(self) -> tuple[Case, ...]:
        return tuple(c for c in self.cases if not c.ok)


def junit_xml(results: Sequence[SuiteResult]) -> bytes:
    """JUnit XML (``testsuites`` root) with one ``testsuite`` per suite result."""
    stamp = datetime.now(UTC).replace(microsecond=0).isoformat()
    root = ET.Element("testsuites", name="papaia-kit conformance")
    total = failures = 0
    duration = 0.0
    for result in results:
        suite = ET.SubElement(
            root,
            "testsuite",
            name=result.name,
            tests=str(len(result.cases)),
            failures=str(len(result.failed)),
            errors="0",
            skipped="0",
            time=f"{result.duration:.3f}",
            timestamp=stamp,
        )
        if result.properties:
            listed = ET.SubElement(suite, "properties")
            for name, value in result.properties:
                ET.SubElement(listed, "property", name=name, value=_xml_text(value))
        for item in result.cases:
            element = ET.SubElement(
                suite, "testcase", classname=f"{item.suite}.{item.group}", name=item.name, time="0"
            )
            if item.failures:
                failure = ET.SubElement(
                    element, "failure", message=_xml_text(item.failures[0]), type="conformance"
                )
                failure.text = _xml_text("\n".join(item.failures))
        total += len(result.cases)
        failures += len(result.failed)
        duration += result.duration
    root.set("tests", str(total))
    root.set("failures", str(failures))
    root.set("errors", "0")
    root.set("skipped", "0")
    root.set("time", f"{duration:.3f}")
    return bytes(ET.tostring(root, encoding="utf-8", xml_declaration=True))


def _xml_text(text: str) -> str:
    return _NOT_XML.sub("\ufffd", text)
