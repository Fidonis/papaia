"""State of an approval that binds a catalog entry by its ``content_hash``.

A module approves an entry (a connection, a tool, a source) for use and stores
the entry's ``content_hash`` with the approval. On every use it asks
:func:`approval_state`:

- ``offered``: the entry exists but has no approval. A new entry is only ever
  offered, never active by itself.
- ``active``: approved, and the entry is unchanged.
- ``suspended``: the entry changed since the approval; the approval rests until
  someone approves the new hash (PLT-49-A4).
- ``removed``: the entry vanished; callers answer with error class
  ``upstream_unavailable`` and the cause "connection removed" (PLT-73).
"""

from __future__ import annotations

from collections.abc import Mapping
from enum import StrEnum
from types import MappingProxyType

from papaia_kit.catalog.document import Catalog, Entry
from papaia_kit.errors import ErrorClass

__all__ = [
    "REMOVED_CAUSE",
    "REMOVED_ERROR_CLASS",
    "REMOVED_ERROR_CODE",
    "ApprovalState",
    "EntryRemovedError",
    "approval_state",
    "require_entry",
]

REMOVED_ERROR_CLASS = ErrorClass.UPSTREAM_UNAVAILABLE
REMOVED_ERROR_CODE = "PK-UPSTREAM-001"
REMOVED_CAUSE: Mapping[str, str] = MappingProxyType(
    {"de": "Anbindung entfernt", "en": "connection removed"}
)


class ApprovalState(StrEnum):
    OFFERED = "offered"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    REMOVED = "removed"


class EntryRemovedError(LookupError):
    """The catalog no longer carries the entry; maps to ``upstream_unavailable``."""

    error_class = REMOVED_ERROR_CLASS
    code = REMOVED_ERROR_CODE
    cause = REMOVED_CAUSE

    def __init__(self, entry_id: str) -> None:
        self.entry_id = entry_id
        super().__init__(f"catalog entry {entry_id[:128]!r}: {REMOVED_CAUSE['en']}")


def approval_state(catalog: Catalog, entry_id: str, approved_hash: str | None) -> ApprovalState:
    """State of the approval of ``entry_id`` stored with ``approved_hash`` (``None``: none)."""
    entry = catalog.entry(entry_id)
    if entry is None:
        return ApprovalState.REMOVED
    if approved_hash is None:
        return ApprovalState.OFFERED
    if approved_hash == entry.content_hash:
        return ApprovalState.ACTIVE
    return ApprovalState.SUSPENDED


def require_entry(catalog: Catalog, entry_id: str) -> Entry:
    """The entry, or :class:`EntryRemovedError` if the catalog no longer carries it."""
    entry = catalog.entry(entry_id)
    if entry is None:
        raise EntryRemovedError(entry_id)
    return entry
