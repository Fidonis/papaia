"""Fixed texts of the states and patterns (``contract/messages/``) and their pattern check.

``states.<lang>.yaml`` holds the texts of the five states (interface spec
2.4), ``patterns.<lang>.yaml`` those of the nine patterns (3.5),
``edge.<lang>.yaml`` those of the proxy and signed-out pages (2.3, 2.4) and
``mail.<lang>.yaml`` those of the notification mail (3.5, 7) and
``welcome.<lang>.yaml`` those of the welcome block ``pk-welcome`` (2.6, 3.5). ``text``
fills one text; ``check_message_dir`` runs the forbidden patterns over every
message file of a directory (the kit's own or a module's), with placeholders
filled, and flags languages whose keys or placeholders differ.
"""

from __future__ import annotations

import functools
import re
from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from papaia_kit._resources import contract_dir
from papaia_kit.errors._patterns import find_forbidden_patterns, has_hidden_characters

LANGUAGES = ("de", "en")
TEXT_FILES = ("states", "patterns", "edge", "mail", "welcome")
MAX_VALUE_CHARS = 200
MAX_FILE_BYTES = 1024 * 1024
_PLACEHOLDER = re.compile(r"\{([a-z_]+)\}")
_KEY = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_MESSAGE_FILE = re.compile(r"^([a-z][a-z0-9_-]{0,63})\.(de|en)\.yaml$")
_SAMPLE = {"de": "Beispiel", "en": "Example"}
_TIMING_KEYS = frozenset(
    {
        "undo_window_s",
        "loading_indicator_delay_ms",
        "loading_slow_after_s",
        "loading_abort_after_s",
        "toast_success_min_s",
    }
)


class MessageError(ValueError):
    """A message file is malformed, or a text was asked for with bad input."""


@dataclass(frozen=True)
class MessageFinding:
    location: str  # "<file>:<line>"
    pattern: str  # id of the forbidden pattern, "hidden_character" or "language_mismatch"
    detail: str


def _fail(text: str) -> MessageError:
    return MessageError(f"message: {text}")


def placeholders(text: str) -> set[str]:
    """Names of the ``{placeholder}`` fields in ``text``."""
    return set(_PLACEHOLDER.findall(text))


def _read(path: Path) -> Any:
    if not path.is_file() or path.is_symlink():
        raise _fail(f"{path.name}: not a regular file")
    if path.stat().st_size > MAX_FILE_BYTES:
        raise _fail(f"{path.name}: larger than {MAX_FILE_BYTES} bytes")
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except (yaml.YAMLError, UnicodeDecodeError) as exc:
        raise _fail(f"{path.name}: not valid YAML") from exc


def _flatten(where: str, texts: object) -> dict[str, str]:
    """``texts`` (one level of sections allowed) as ``{"section.key": text}``."""
    if not isinstance(texts, dict) or not texts:
        raise _fail(f"{where}: texts must be a non-empty mapping")
    flat: dict[str, str] = {}
    for key, value in texts.items():
        if not isinstance(key, str) or not _KEY.match(key):
            raise _fail(f"{where}: bad key {key!r}")
        if isinstance(value, dict):
            for sub, text in value.items():
                if not isinstance(sub, str) or not _KEY.match(sub) or not isinstance(text, str):
                    raise _fail(f"{where}: bad entry under {key}")
                flat[f"{key}.{sub}"] = text
        elif isinstance(value, str):
            flat[key] = value
        else:
            raise _fail(f"{where}: {key} must be a text or a section")
    return flat


def parse_texts(where: str, data: object, lang: str) -> dict[str, str]:
    """Texts of one message file with a ``texts`` section, flattened."""
    if not isinstance(data, dict) or data.get("version") != 1 or data.get("lang") != lang:
        raise _fail(f"{where}: expected version 1 and lang {lang}")
    if unknown := set(data) - {"version", "lang", "texts"}:
        raise _fail(f"{where}: unknown {sorted(unknown)}")
    return _flatten(where, data.get("texts"))


def _check_lang(lang: object) -> str:
    if not isinstance(lang, str) or lang not in LANGUAGES:
        raise _fail(f"unknown language, expected one of {list(LANGUAGES)}")
    return lang


@functools.cache
def _load_texts(name: str, lang: str) -> Mapping[str, str]:
    path = contract_dir() / "messages" / f"{name}.{lang}.yaml"
    return parse_texts(path.name, _read(path), lang)


def load_texts(name: str, lang: str) -> Mapping[str, str]:
    """Texts of ``contract/messages/<name>.<lang>.yaml``, ``<name>`` one of ``TEXT_FILES``."""
    if name not in TEXT_FILES:
        raise _fail(f"unknown message file, expected one of {list(TEXT_FILES)}")
    return dict(_load_texts(name, _check_lang(lang)))


def _check_value(name: str, value: object) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= MAX_VALUE_CHARS:
        raise _fail(f"value of {name} must be a text of 1 to {MAX_VALUE_CHARS} characters")
    if "\n" in value or "\r" in value or has_hidden_characters(value):
        raise _fail(f"value of {name} holds a line break or a hidden character")
    return value


def text(name: str, lang: str, key: str, /, **values: str) -> str:
    """One fixed text with its placeholders filled; every placeholder needs a value.

    The first three parameters are positional only, so a placeholder may be called
    ``{name}`` (``type_name``).
    """
    texts = load_texts(name, lang)
    if key not in texts:
        raise _fail(f"unknown key {key!r} in {name}")
    template = texts[key]
    wanted = placeholders(template)
    if missing := wanted - set(values):
        raise _fail(f"{key}: missing value for {sorted(missing)}")
    if unknown := set(values) - wanted:
        raise _fail(f"{key}: unknown placeholder {sorted(unknown)}")
    checked = {k: _check_value(k, v) for k, v in values.items()}
    return _PLACEHOLDER.sub(lambda m: checked[m.group(1)], template)


def no_access_texts(lang: str, *, module: str, contact: str | None) -> tuple[str, str, str]:
    """Title, sentence 1 and sentence 2 of the page "Kein Zugang" (PLT-82)."""
    todo = (
        text("states", lang, "no_access.todo", contact=contact)
        if contact
        else text("states", lang, "no_access.todo_without_contact")
    )
    return (
        text("states", lang, "no_access.title"),
        text("states", lang, "no_access.text", module=module),
        todo,
    )


@functools.cache
def _timing() -> Mapping[str, int]:
    path = contract_dir() / "patterns" / "patterns.yaml"
    data = _read(path)
    raw = data.get("timing") if isinstance(data, dict) else None
    if not isinstance(raw, dict) or set(raw) != _TIMING_KEYS:
        raise _fail(f"patterns.yaml: timing must hold exactly {sorted(_TIMING_KEYS)}")
    if not all(isinstance(v, int) and not isinstance(v, bool) and v > 0 for v in raw.values()):
        raise _fail("patterns.yaml: timing values must be positive integers")
    return dict(raw)


def timing() -> dict[str, int]:
    """Times of the patterns: undo window, loading stages, minimum toast duration."""
    return dict(_timing())


# RE-73: the undo window of every module, equal to the validity of ``undo_token``.
UNDO_WINDOW_S: int = _timing()["undo_window_s"]


# --- pattern check over message files -------------------------------------------------------


def _strings(node: yaml.Node, top: bool = True) -> Iterator[tuple[int, str]]:
    """Every shown string with its line.

    Skipped: the file's ``version`` and ``lang``, and ``consequence``, which
    names an entry of the consequence list instead of holding a text.
    """
    if isinstance(node, yaml.MappingNode):
        for key, value in node.value:
            name = key.value if isinstance(key, yaml.ScalarNode) else None
            if (top and name in {"version", "lang"}) or name == "consequence":
                continue
            yield from _strings(value, False)
    elif isinstance(node, yaml.SequenceNode):
        for item in node.value:
            yield from _strings(item, False)
    elif isinstance(node, yaml.ScalarNode) and node.tag == "tag:yaml.org,2002:str":
        yield node.start_mark.line + 1, str(node.value)


def _file_findings(path: Path, lang: str) -> Iterator[MessageFinding]:
    if path.stat().st_size > MAX_FILE_BYTES:
        raise _fail(f"{path.name}: larger than {MAX_FILE_BYTES} bytes")
    try:
        root = yaml.compose(path.read_text(encoding="utf-8"), Loader=yaml.SafeLoader)
    except (yaml.YAMLError, UnicodeDecodeError) as exc:
        raise _fail(f"{path.name}: not valid YAML") from exc
    if root is None:
        return
    for line, value in _strings(root):
        where = f"{path.name}:{line}"
        if has_hidden_characters(value):
            yield MessageFinding(where, "hidden_character", "control or format character")
        filled = _PLACEHOLDER.sub(_SAMPLE[lang], value)
        for hit in find_forbidden_patterns(filled, "message"):
            yield MessageFinding(where, hit.pattern, hit.match)


def _language_findings(folder: Path, name: str) -> Iterator[MessageFinding]:
    """Keys and placeholders of ``<name>.de.yaml`` and ``<name>.en.yaml`` must agree."""
    files = {lang: folder / f"{name}.{lang}.yaml" for lang in LANGUAGES}
    if not all(path.is_file() for path in files.values()):
        missing = sorted(p.name for p in files.values() if not p.is_file())
        yield MessageFinding(f"{name}.*.yaml", "language_mismatch", f"missing {missing}")
        return
    docs = {lang: _read(path) for lang, path in files.items()}
    if not all(isinstance(doc, dict) and "texts" in doc for doc in docs.values()):
        return  # code and consequence files have their own checks in papaia_kit.errors
    texts = {lang: parse_texts(files[lang].name, docs[lang], lang) for lang in LANGUAGES}
    de, en = texts["de"], texts["en"]
    for key in sorted(set(de) ^ set(en)):
        yield MessageFinding(f"{name}.*.yaml", "language_mismatch", f"key {key} in one language")
    for key in sorted(set(de) & set(en)):
        if placeholders(de[key]) != placeholders(en[key]):
            yield MessageFinding(f"{name}.*.yaml", "language_mismatch", f"placeholders of {key}")


def check_message_dir(folder: Path | None = None) -> list[MessageFinding]:
    """Findings over every ``<name>.<de|en>.yaml`` in ``folder`` (default: the kit's)."""
    folder = folder or contract_dir() / "messages"
    if not folder.is_dir():
        raise _fail(f"{folder}: not a directory")
    findings: list[MessageFinding] = []
    names: set[str] = set()
    for path in sorted(folder.iterdir()):
        match = _MESSAGE_FILE.match(path.name)
        if match is None or path.is_symlink() or not path.is_file():
            continue
        names.add(match.group(1))
        findings.extend(_file_findings(path, match.group(2)))
    for name in sorted(names):
        findings.extend(_language_findings(folder, name))
    return findings
