"""Retention of the erasure journal: which entries a retention run may remove.

The journal is kept as long as a restore point or a copy outside the house can
bring old data back, and not much longer (sicherheit 4.9, betrieb BE-16, RE-86):
an entry goes once it is older than the oldest restore point plus 30 days and
older than the longest offsite retention plus 30 days. Only a prefix by ``seq``
goes, so a retained journal never has a gap a replay would refuse.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from papaia_kit.erasure._entry import JournalEntry, format_at

OFFSITE_RETENTION_DAYS = 90  # default of --offsite-retention (RE-86)
RETENTION_MARGIN_DAYS = 30
MAX_OFFSITE_RETENTION_DAYS = 3650

_AT = re.compile(rb"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z")


@dataclass(frozen=True)
class RetentionResult:
    """Outcome of one retention run.

    ``cutoff`` is the time (UTC, journal format) before which entries were
    eligible; ``through_seq`` the highest ``seq`` removed at the backup target
    (0 when none). ``removed`` counts the removed entries per place,
    ``skipped`` names places that could not be cleaned in this run (an
    unreachable or read-only mirror); their old lines are never delivered again
    and the next run removes them. ``delivered`` and ``renumbered`` count what
    the run delivered to the target first.
    """

    cutoff: str
    through_seq: int
    removed: dict[str, int] = field(default_factory=dict)
    skipped: tuple[str, ...] = ()
    delivered: int = 0
    renumbered: int = 0


def check_offsite_days(days: object) -> int:
    """``--offsite-retention`` in days: an integer from 0 to 3650."""
    if type(days) is not int or not 0 <= days <= MAX_OFFSITE_RETENTION_DAYS:
        raise ValueError(
            f"offsite_retention_days must be an integer from 0 to {MAX_OFFSITE_RETENTION_DAYS}"
        )
    return days


def check_restore_point(point: object) -> datetime:
    """Time of the oldest restore point that exists, timezone-aware."""
    if not isinstance(point, datetime):
        raise TypeError("oldest_restore_point must be a datetime")
    if point.tzinfo is None or point.utcoffset() is None:
        raise ValueError("oldest_restore_point must be timezone-aware")
    return point


def retention_cutoff(now: datetime, oldest_restore_point: datetime, offsite_days: int) -> str:
    """The earlier of both limits; entries before it may go.

    The offsite rule only lengthens the restore point rule, never shortens it.
    """
    if oldest_restore_point > now:
        raise ValueError("oldest_restore_point lies in the future")
    margin = timedelta(days=RETENTION_MARGIN_DAYS)
    by_point = oldest_restore_point - margin
    by_offsite = now - timedelta(days=offsite_days) - margin
    # format_at cuts to milliseconds, which only moves the cutoff earlier
    return format_at(min(by_point, by_offsite))


def removable_through(entries: Iterable[JournalEntry], cutoff: str) -> int:
    """Highest ``seq`` up to which every entry may go (0 for none).

    The run walks the entries by ``seq`` and stops at the first one not older
    than ``cutoff``; the newest entry always stays, so no file is emptied and
    the next provisional ``seq`` still follows it. A renumbered entry
    (``provisional_seq``) makes a replay rewind to ``provisional_seq - 1``, so
    the cut never falls between its two numbers.
    """
    ordered = sorted(entries, key=lambda e: e.seq)
    through = 0
    for entry in ordered[:-1]:
        if entry.at >= cutoff:
            break
        through = entry.seq
    changed = True
    while changed:
        changed = False
        for entry in ordered:
            if entry.provisional_seq is None:
                continue
            low = min(entry.seq, entry.provisional_seq)
            high = max(entry.seq, entry.provisional_seq)
            if low <= through < high:
                through = low - 1
                changed = True
    return through


def parse_floor(text: bytes) -> str | None:
    """Cutoff of an earlier run from its marker, or None for a damaged marker."""
    value = text.strip()
    if not _AT.fullmatch(value):
        return None
    decoded = value.decode("ascii")
    try:
        datetime.strptime(decoded, "%Y-%m-%dT%H:%M:%S.%fZ")
    except ValueError:
        return None
    return decoded
