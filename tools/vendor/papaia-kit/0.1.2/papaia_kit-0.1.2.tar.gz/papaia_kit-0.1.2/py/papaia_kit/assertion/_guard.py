"""Server modes of the module context assertion: ``off``, ``log``, ``enforce``.

The guard runs after the check chain of ``papaia_kit.authz`` accepted the
bearer token. The assertion grants nothing: rights still come from the token
alone. ``log`` verifies and logs the origin of each call, never refuses;
``enforce`` refuses a call without a valid assertion with ``PK-CONTEXT-001``
(HTTP 403) and one ``papaia.audit/1`` row with result ``denied``.
"""

from __future__ import annotations

import logging
import os
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Final

from papaia_kit.assertion._token import (
    Code,
    ContextInvalid,
    ModuleContext,
    ModuleContextVerifier,
    ReplayCache,
)
from papaia_kit.authz import AUDIT_FORMAT, AuditSink, KeyProvider, Principal, Request, ServerConfig
from papaia_kit.errors import ErrorEnvelope, build_envelope

MODE_VARIABLE: Final = "PAPAIA_MODULE_CONTEXT_MODE"
DENIED_CODE: Final = "PK-CONTEXT-001"
DENIED_STATUS: Final = 403

logger = logging.getLogger("papaia_kit.assertion")


class Mode(StrEnum):
    """How a server treats the assertion; ``off`` until the server opts in."""

    OFF = "off"
    LOG = "log"
    ENFORCE = "enforce"

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> Mode:
        """Mode from ``PAPAIA_MODULE_CONTEXT_MODE``; unset means ``off``, anything else fails."""
        raw = (os.environ if environ is None else environ).get(MODE_VARIABLE)
        if raw is None or raw == "":
            return cls.OFF
        try:
            return cls(raw)
        except ValueError:
            raise ValueError(f"{MODE_VARIABLE} must be off, log or enforce") from None


@dataclass(frozen=True, slots=True)
class ContextOutcome:
    """Result of the guard: the verified context, or the refusal code in ``log`` mode."""

    mode: Mode
    context: ModuleContext | None
    code: Code | None


class ContextDenied(Exception):  # noqa: N818 - reads as "raise ContextDenied"
    """``enforce`` refused the call; answer with ``envelope`` and ``status``."""

    def __init__(self, code: Code, envelope: ErrorEnvelope, audit_row: dict[str, Any]) -> None:
        super().__init__(f"module context denied: {code.value}")
        self.code = code
        self.envelope = envelope
        self.status = envelope.status
        self.audit_row = audit_row


def _timestamp(now: float) -> str:
    moment = datetime.fromtimestamp(now, UTC)
    return moment.strftime("%Y-%m-%dT%H:%M:%S.") + f"{moment.microsecond // 1000:03d}Z"


class ContextGuard:
    """Applies the server's mode to the ``X-Papaia-Module-Context`` header of one call.

    ``modules`` maps each trusted module client to its JWKS key provider (see
    ``ModuleContextVerifier``). ``audit`` is the server's audit writer; an
    exception there propagates, so a refusal is never silently unrecorded.
    """

    def __init__(
        self,
        config: ServerConfig,
        modules: Mapping[str, KeyProvider],
        *,
        mode: Mode,
        audit: AuditSink,
        replay: ReplayCache | None = None,
        clock: Callable[[], float] = time.time,
        lang: str = "de",
    ) -> None:
        self._config = config
        self._mode = Mode(mode)
        self._verifier = ModuleContextVerifier(
            modules, audience=config.audience, replay=replay, clock=clock
        )
        self._audit = audit
        self._clock = clock
        self._lang = lang

    @property
    def mode(self) -> Mode:
        return self._mode

    def check(
        self, value: str | None, *, token: str, principal: Principal, request: Request
    ) -> ContextOutcome:
        """Check the header ``value`` of a call the chain accepted as ``principal``."""
        if principal.audience != self._config.audience:
            raise ValueError("principal audience is not the audience of this server")
        if self._mode is Mode.OFF:
            return ContextOutcome(Mode.OFF, None, None)
        cid = principal.correlation_id
        try:
            context = self._verifier.verify(value, token=token, subject=principal.sub)
        except ContextInvalid as refused:
            logger.warning(
                "module context refused: code=%s mode=%s correlation_id=%s",
                refused.code.value,
                self._mode.value,
                cid,
            )
            if self._mode is Mode.LOG:
                return ContextOutcome(Mode.LOG, None, refused.code)
            raise self._deny(refused.code, principal, request) from None
        logger.info("module context: %s correlation_id=%s", context.log_fields(), cid)
        return ContextOutcome(self._mode, context, None)

    def _deny(self, code: Code, principal: Principal, request: Request) -> ContextDenied:
        envelope = build_envelope(
            DENIED_CODE,
            correlation_id=principal.correlation_id,
            lang=self._lang,
            status=DENIED_STATUS,
        )
        row: dict[str, Any] = {
            "format": AUDIT_FORMAT,
            "time": _timestamp(self._clock()),
            "writer": self._config.writer,
            "result": "denied",
            "event": "operation",
            **principal.audit_fields(),
            "catalog_id": request.catalog_id,
            "operation": request.operation,
            "effect": str(request.effect),
            "error_code": DENIED_CODE,
        }
        self._audit(row)
        return ContextDenied(code, envelope, row)
