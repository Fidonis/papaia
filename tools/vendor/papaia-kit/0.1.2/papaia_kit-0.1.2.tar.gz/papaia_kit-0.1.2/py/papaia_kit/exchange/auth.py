"""Client authentication at the token endpoint.

``private_key_jwt`` (RFC 7523 section 2.2) is the method for every confidential
client with token exchange (security 1.2). The key stays with the module: the
kit builds the assertion and hands the signing input to a ``Signer``. A client
secret is only a fallback while the ``private_key_jwt`` proof (MN-13) is open.
"""

from __future__ import annotations

import base64
import json
import uuid
from typing import Protocol, runtime_checkable
from urllib.parse import quote_plus

from papaia_kit.exchange._jwt import b64url_encode

ASSERTION_TYPE = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
ALLOWED_ALGORITHMS = frozenset({"RS256", "ES256"})
# Lifetime of one client assertion; it is built fresh for every request.
MAX_ASSERTION_LIFETIME = 60
_MAX_KID = 128
_MAX_SECRET = 512


@runtime_checkable
class Signer(Protocol):
    """Signs the assertion with the module's private key (kept outside the kit)."""

    @property
    def alg(self) -> str: ...

    @property
    def kid(self) -> str: ...

    def sign(self, signing_input: bytes) -> bytes: ...


class PrivateKeyJwt:
    """Client authentication with a signed assertion (``private_key_jwt``)."""

    method = "private_key_jwt"
    __slots__ = ("_signer",)

    def __init__(self, signer: Signer) -> None:
        if not isinstance(signer, Signer):
            raise TypeError("signer must provide alg, kid and sign(bytes)")
        if signer.alg not in ALLOWED_ALGORITHMS:
            raise ValueError(f"assertion algorithm must be one of {sorted(ALLOWED_ALGORITHMS)}")
        kid: object = signer.kid  # a signer from outside the kit; check what it returns
        if not isinstance(kid, str) or not 0 < len(kid) <= _MAX_KID or not kid.isprintable():
            raise ValueError(f"kid must be 1 to {_MAX_KID} printable characters")
        self._signer = signer

    def __repr__(self) -> str:
        return f"PrivateKeyJwt(alg={self._signer.alg!r}, kid={self._signer.kid!r})"

    def apply(
        self,
        client_id: str,
        token_endpoint: str,
        now: float,
        form: dict[str, str],
        headers: dict[str, str],
    ) -> None:
        header = {"alg": self._signer.alg, "kid": self._signer.kid, "typ": "JWT"}
        issued = int(now)
        claims = {
            "iss": client_id,
            "sub": client_id,
            "aud": token_endpoint,
            "jti": str(uuid.uuid4()),
            "iat": issued,
            "exp": issued + MAX_ASSERTION_LIFETIME,
        }
        signing_input = ".".join(
            b64url_encode(json.dumps(part, separators=(",", ":")).encode())
            for part in (header, claims)
        )
        signature: object = self._signer.sign(signing_input.encode("ascii"))
        if not isinstance(signature, bytes) or not signature:
            raise TypeError("signer must return the signature as non-empty bytes")
        form["client_id"] = client_id
        form["client_assertion_type"] = ASSERTION_TYPE
        form["client_assertion"] = f"{signing_input}.{b64url_encode(signature)}"


class ClientSecret:
    """Fallback client authentication with a secret (HTTP Basic, RFC 6749 2.3.1).

    Only while the ``private_key_jwt`` proof is open; the secret comes from the
    module's secret volume and is never shown in ``repr``.
    """

    method = "client_secret_basic"
    __slots__ = ("_secret",)

    def __init__(self, secret: str) -> None:
        if not isinstance(secret, str):
            raise TypeError("client secret must be a string")
        if not 0 < len(secret) <= _MAX_SECRET or not secret.isprintable():
            raise ValueError(f"client secret must have 1 to {_MAX_SECRET} printable characters")
        self._secret = secret

    def __repr__(self) -> str:
        return "ClientSecret(<redacted>)"

    def apply(
        self,
        client_id: str,
        token_endpoint: str,
        now: float,
        form: dict[str, str],
        headers: dict[str, str],
    ) -> None:
        pair = f"{quote_plus(client_id)}:{quote_plus(self._secret)}".encode()
        headers["Authorization"] = "Basic " + base64.b64encode(pair).decode("ascii")


ClientAuth = PrivateKeyJwt | ClientSecret
