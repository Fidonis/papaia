"""Kit versions in a suite bill of materials (interface spec 3.6, UXB-P13).

Modules may carry different kit versions of one major version (KE-31), but a
suite may combine two kit versions in modules that render kit UI only when no
release between them carries a ``visual`` change: otherwise two modules of one
suite render the same element differently (PLT-83-A4).

The compatibility matrix ``contract/versions.yaml`` (``papaia.kit-versions/1``)
lists every kit release in ascending order with its ``visual`` flag: ``true``
when its changelog entry marks a change of how existing markup renders.
:func:`check_bom` applies the rules to the kit versions of a bill of materials:

- contract rule, every entry: the version is in the matrix (a newer version
  needs the newer kit's matrix, so an unknown version is refused, never
  passed) and all versions have the same major version;
- visual rule, entries that render kit UI only: no release ``r`` with
  ``lowest < r <= highest`` is ``visual``.

An entry renders kit UI unless it says ``renders_ui: false`` (core tools,
connections, MCP servers): a missing flag never relaxes a check.

Two inputs carry the versions:

- ``papaia.kit-bom/1`` (schema ``contract/kit-bom.schema.json``): one entry
  per module with ``name``, ``kit`` and ``renders_ui``;
- ``papaia.suite-bom/1``, the suite bill of materials of the core: each repo
  may carry ``kit: {version, renders_ui}`` (schema of that field and of the
  part read here: ``contract/suite-bom-kit.schema.json``). Only ``schema``,
  ``repos[].name`` and ``repos[].kit`` are read; signature and the other
  fields are checked by the core (``papaia-ctl suite verify``).

Problems name the place, the versions and the modules; they never quote free
text of the file. A refusal names the version to move to: the newest version
of the suite.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, NamedTuple

import yaml
from jsonschema import Draft202012Validator

from papaia_kit._resources import contract_dir

__all__ = [
    "BOM_FORMAT",
    "MATRIX_FORMAT",
    "MAX_BOM_BYTES",
    "MAX_MODULES",
    "SUITE_BOM_FORMAT",
    "BomEntry",
    "BomError",
    "Release",
    "check_bom",
    "load_bom",
    "load_matrix",
]

BOM_FORMAT = "papaia.kit-bom/1"
MATRIX_FORMAT = "papaia.kit-versions/1"
SUITE_BOM_FORMAT = "papaia.suite-bom/1"
# The suite bill of materials of the core may be as large as the core accepts.
MAX_BOM_BYTES = 1024 * 1024
MAX_MODULES = 64
_MAX_MATRIX_BYTES = 64 * 1024
_MAX_RELEASES = 1000
_MAX_PROBLEMS = 20
_VERSION = re.compile(r"^(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})$")


class BomEntry(NamedTuple):
    """One module of a bill of materials: name, kit version, whether it renders kit UI."""

    name: str
    kit: str
    renders_ui: bool = True


class BomError(ValueError):
    """A bill of materials or the matrix failed a check. ``problems`` lists place and rule."""

    def __init__(self, problems: Iterable[str]) -> None:
        self.problems = tuple(problems)[:_MAX_PROBLEMS] or ("invalid",)
        super().__init__("; ".join(self.problems))


@dataclass(frozen=True, order=True)
class Release:
    """One kit release of the matrix; ordered by version."""

    key: tuple[int, int, int]
    visual: bool

    @classmethod
    def parse(cls, version: str, *, visual: bool) -> Release:
        found = _VERSION.fullmatch(version)
        if not found:
            raise BomError(["release version must be MAJOR.MINOR.PATCH"])
        major, minor, patch = (int(part) for part in found.groups())
        return cls((major, minor, patch), visual)

    @property
    def text(self) -> str:
        return ".".join(str(part) for part in self.key)


class _UniqueKeyLoader(yaml.SafeLoader):
    """Safe loader that rejects a mapping key written twice."""


def _mapping(loader: _UniqueKeyLoader, node: yaml.MappingNode) -> dict[Any, Any]:
    keys = [loader.construct_object(k) for k, _ in node.value]
    if len(keys) != len(set(map(repr, keys))):
        raise yaml.constructor.ConstructorError(None, None, "duplicate key", node.start_mark)
    return loader.construct_mapping(node)


_UniqueKeyLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


def _read(data: bytes, source: str, limit: int) -> Any:
    if len(data) > limit:
        raise BomError([f"{source}: larger than {limit} bytes"])
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        raise BomError([f"{source}: not UTF-8"]) from None
    try:
        return yaml.load(text, Loader=_UniqueKeyLoader)  # noqa: S506 (safe loader subclass)
    except yaml.constructor.ConstructorError as exc:
        if exc.problem == "duplicate key":
            raise BomError([f"{source}: duplicate key"]) from None
        raise BomError([f"{source}: not valid YAML or JSON"]) from None
    except yaml.YAMLError:
        raise BomError([f"{source}: not valid YAML or JSON"]) from None


# --- matrix -----------------------------------------------------------------------


def load_matrix(
    data: bytes | None = None, *, source: str = "contract/versions.yaml"
) -> tuple[Release, ...]:
    """Read the compatibility matrix; the kit's own file when ``data`` is ``None``."""
    if data is None:
        data = (contract_dir() / "versions.yaml").read_bytes()
    document = _read(data, source, _MAX_MATRIX_BYTES)
    if not isinstance(document, dict) or set(document) != {"format", "releases"}:
        raise BomError([f"{source}: exactly the fields format and releases"])
    if document["format"] != MATRIX_FORMAT:
        raise BomError([f"{source}: format must be {MATRIX_FORMAT}"])
    rows = document["releases"]
    if not isinstance(rows, list) or not 1 <= len(rows) <= _MAX_RELEASES:
        raise BomError([f"{source}: releases must list at least one release"])
    releases: list[Release] = []
    for index, row in enumerate(rows):
        where = f"{source}: releases/{index}"
        if not isinstance(row, dict) or set(row) - {"version", "visual"}:
            raise BomError([f"{where}: unknown field, only version and visual"])
        if not isinstance(row.get("visual"), bool):
            raise BomError([f"{where}: visual must be true or false"])
        version = row.get("version")
        if not isinstance(version, str) or not _VERSION.fullmatch(version):
            raise BomError([f"{where}: version must be MAJOR.MINOR.PATCH"])
        release = Release.parse(version, visual=row["visual"])
        if releases and release.key <= releases[-1].key:
            raise BomError([f"{where}: versions must be strictly ascending"])
        releases.append(release)
    return tuple(releases)


# --- bill of materials ------------------------------------------------------------


@lru_cache(maxsize=2)
def _validator(name: str) -> Draft202012Validator:
    schema = json.loads((contract_dir() / name).read_text(encoding="utf-8"))
    return Draft202012Validator(schema)


def _place(path: Iterable[Any]) -> str:
    return "/".join(str(part) for part in path) or "(top)"


def _schema_problems(document: Any, validator: Draft202012Validator, source: str) -> list[str]:
    problems = []
    for error in sorted(validator.iter_errors(document), key=lambda e: list(e.path)):
        place = _place(error.absolute_path)
        if error.validator == "additionalProperties":
            extra = sorted(set(error.instance) - set(error.schema.get("properties", {})))
            problems.append(f"{source}: {place}: unknown field {', '.join(extra)}")
        elif error.validator == "required":
            missing = sorted(set(error.validator_value) - set(error.instance))
            problems.append(f"{source}: {place}: missing field {', '.join(missing)}")
        else:
            # The rule, not the value: values of the file are never quoted.
            problems.append(f"{source}: {place}: breaks the rule {error.validator}")
    return problems


def load_bom(data: bytes, *, source: str = "bom") -> list[BomEntry]:
    """Check a bill of materials and return its entries in file order.

    ``data`` is a ``papaia.kit-bom/1`` document (field ``format``) or a suite
    bill of materials ``papaia.suite-bom/1`` (field ``schema``); of the latter
    only the repos with a ``kit`` field count.
    """
    document = _read(data, source, MAX_BOM_BYTES)
    if not isinstance(document, dict) or not ({"format", "schema"} & set(document)):
        raise BomError(
            [
                f"{source}: must be a mapping that names format {BOM_FORMAT} "
                f"or schema {SUITE_BOM_FORMAT}"
            ]
        )
    suite = "format" not in document
    validator = _validator("suite-bom-kit.schema.json" if suite else "kit-bom.schema.json")
    problems = _schema_problems(document, validator, source)
    if problems:
        raise BomError(problems)
    if suite:
        entries = [
            BomEntry(r["name"], r["kit"]["version"], r["kit"].get("renders_ui", True))
            for r in document["repos"]
            if "kit" in r
        ]
        if not entries:
            raise BomError([f"{source}: no repo names its kit version (repos/*/kit)"])
        names = [r["name"] for r in document["repos"]]
    else:
        entries = [
            BomEntry(m["name"], m["kit"], m.get("renders_ui", True)) for m in document["modules"]
        ]
        names = [entry.name for entry in entries]
    seen: set[str] = set()
    for index, name in enumerate(names):
        if name in seen:
            listed = "repos" if suite else "modules"
            problems.append(f"{source}: {listed}/{index}: {name} listed twice")
        seen.add(name)
    if problems:
        raise BomError(problems)
    return entries


def check_bom(
    entries: Iterable[tuple[str, str] | tuple[str, str, bool]], matrix: Sequence[Release]
) -> list[str]:
    """Problems of combining the kit versions of ``entries``; empty when allowed.

    An entry is ``(name, version)`` or ``(name, version, renders_ui)``; without
    the flag it renders kit UI. The contract rule (matrix, major version)
    applies to every entry, the visual rule to entries that render kit UI.
    """
    every: dict[tuple[int, int, int], list[str]] = {}
    ui: dict[tuple[int, int, int], list[str]] = {}
    for entry in entries:
        name, version = entry[0], entry[1]
        renders_ui = entry[2] if len(entry) > 2 else True  # noqa: PLR2004 (flag is third)
        key = Release.parse(version, visual=False).key
        every.setdefault(key, []).append(name)
        if renders_ui is not False:
            ui.setdefault(key, []).append(name)
    known = {release.key: release for release in matrix}
    newest = matrix[-1].text if matrix else "none"

    def _text(key: tuple[int, int, int]) -> str:
        return ".".join(str(part) for part in key)

    def _who(group: dict[tuple[int, int, int], list[str]], key: tuple[int, int, int]) -> str:
        return ", ".join(group[key])

    problems = [
        f"kit {_text(key)} is not in the compatibility matrix ({_who(every, key)}); the matrix "
        f"ends at {newest}, check with the kit that knows it"
        for key in sorted(every)
        if key not in known
    ]
    if problems or not every:
        return problems
    # The version to move to: the newest one among the modules that render kit
    # UI, or the newest of all when none does.
    target = max(ui or every)
    for key in sorted(every):
        if key[0] != target[0]:
            problems.append(
                f"kit {_text(key)} ({_who(every, key)}) and {_text(target)} "
                f"({_who(every, target)}) differ in the major version; move "
                f"{_who(every, key)} to kit {_text(target)}"
            )
    if problems:
        return problems
    for key in sorted(ui)[1:]:
        lower = max(k for k in ui if k < key)
        between = [r for r in matrix if lower < r.key <= key and r.visual]
        if between:
            problems.append(
                f"kit {_text(lower)} ({_who(ui, lower)}) and {_text(key)} ({_who(ui, key)}) "
                f"must not be combined: {between[0].text} is visual; move {_who(ui, lower)} "
                f"to kit {_text(target)}"
            )
    return problems
