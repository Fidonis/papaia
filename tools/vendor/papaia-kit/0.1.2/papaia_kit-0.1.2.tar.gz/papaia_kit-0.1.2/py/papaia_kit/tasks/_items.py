"""Readers for the task routes: ``papaia.task-item/1`` lists and summaries.

Every body is checked before a single value is used: at most ``MAX_BODY``
bytes, strict UTF-8 and strict JSON (no duplicate member names, no NaN or
infinities), the kit schema ``task-item.v1`` (unknown fields rejected at every
level) and the rules the schema language cannot express (integers that are
JSON integers, timestamps that are real instants, ``overdue`` not above
``open``, unique ids, the expected ``source``). Messages name the place and the rule, never a value.
"""

from __future__ import annotations

import datetime as dt
import json
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass
from functools import lru_cache
from types import MappingProxyType
from typing import Any, Final

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

from papaia_kit._resources import schemas_dir

FORMAT: Final = "papaia.task-item/1"
SCHEMA_FILE: Final = "task-item.v1.schema.json"
# Upper bound of one answer of a task route.
MAX_BODY: Final = 2 * 1024 * 1024
_MAX_PROBLEMS = 10


class TaskContractError(ValueError):
    """A task body broke the contract. ``problems`` lists place and rule, no values."""

    def __init__(self, problems: list[str] | tuple[str, ...]) -> None:
        self.problems = tuple(problems)[:_MAX_PROBLEMS] or ("invalid",)
        super().__init__("; ".join(self.problems))


@dataclass(frozen=True, slots=True)
class Summary:
    """Counts of one person in one source."""

    open: int
    overdue: int
    revision: str


class _DuplicateMemberError(ValueError):
    pass


class _NotFiniteError(ValueError):
    pass


def _unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, value in pairs:
        if name in result:
            raise _DuplicateMemberError
        result[name] = value
    return result


def _reject_constant(name: str) -> Any:
    raise _NotFiniteError


def _finite(literal: str) -> float:
    value = float(literal)
    if not math.isfinite(value):
        raise _NotFiniteError
    return value


def _load(body: object) -> Any:
    if not isinstance(body, bytes | bytearray):
        raise TypeError("a task body must be bytes")
    if len(body) > MAX_BODY:
        raise TaskContractError([f"body: larger than {MAX_BODY} bytes"])
    try:
        text = bytes(body).decode("utf-8")
    except UnicodeDecodeError:
        raise TaskContractError(["body: not UTF-8"]) from None
    try:
        return json.loads(
            text,
            object_pairs_hook=_unique,
            parse_constant=_reject_constant,
            parse_float=_finite,
        )
    except _DuplicateMemberError:
        raise TaskContractError(["body: duplicate member name"]) from None
    except RecursionError:
        raise TaskContractError(["body: nesting too deep"]) from None
    except ValueError:
        # JSONDecodeError, NaN or infinity, a number out of range.
        raise TaskContractError(["body: not JSON"]) from None


@lru_cache(maxsize=4)
def _validator(pointer: str) -> Draft202012Validator:
    schema = json.loads((schemas_dir() / SCHEMA_FILE).read_text(encoding="utf-8"))
    registry: Registry[Any] = Registry().with_resource(
        schema["$id"], Resource.from_contents(schema)
    )
    return Draft202012Validator(
        {"$ref": schema["$id"] + pointer}, registry=registry, format_checker=FormatChecker()
    )


def _check(document: object, pointer: str) -> None:
    problems = [
        f"{'/'.join(str(p) for p in error.absolute_path) or '(root)'}: fails {error.validator}"
        for error in sorted(
            _validator(pointer).iter_errors(document),
            key=lambda e: tuple(str(p) for p in e.absolute_path),
        )
    ]
    if problems:
        raise TaskContractError(problems)


def _integers(item: Mapping[str, Any], where: str) -> None:
    """JSON Schema counts ``1.0`` as an integer; the contract does not."""
    decide = item.get("decide")
    if isinstance(decide, Mapping) and type(decide.get("max_age_s")) is not int:
        raise TaskContractError([f"{where}/decide/max_age_s: not an integer"])
    ref = item.get("ref")
    if isinstance(ref, Mapping):
        for name, value in ref.items():
            if isinstance(value, float):
                raise TaskContractError([f"{where}/ref/{name}: not an integer"])


_TIMESTAMP_FIELDS: Final = ("due_at", "created_at")
# Shape of ``#/$defs/Timestamp``, with the offset captured: RFC 3339 allows
# offset hours 00-23 and minutes 00-59, which ``fromisoformat`` does not check.
_RFC3339: Final = re.compile(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,9})?"
    r"(?:Z|[+-](?P<oh>[0-9]{2}):(?P<om>[0-9]{2}))"
)


def instant(value: str) -> dt.datetime:
    """The UTC instant of a schema-shaped RFC 3339 timestamp; ``ValueError`` if there is none.

    The schema pattern checks only the digit shape (``format: date-time`` is
    not enforced without an RFC 3339 checker), so a day, hour, minute, second
    or offset out of range, and an instant outside the representable years,
    are refused here.
    """
    shape = _RFC3339.fullmatch(value)
    if shape is None or (shape["oh"] is not None and (shape["oh"] > "23" or shape["om"] > "59")):
        raise ValueError("not a valid timestamp")
    try:
        return dt.datetime.fromisoformat(value).astimezone(dt.UTC)
    except (ValueError, OverflowError):
        raise ValueError("not a valid timestamp") from None


def _timestamps(item: Mapping[str, Any], where: str) -> None:
    for name in _TIMESTAMP_FIELDS:
        value = item.get(name)
        if isinstance(value, str):
            try:
                instant(value)
            except ValueError:
                raise TaskContractError([f"{where}/{name}: not a valid timestamp"]) from None


def _mapping(document: object) -> Mapping[str, Any]:
    # The schema already demands an object; this keeps the type checker honest.
    if not isinstance(document, Mapping):
        raise TaskContractError(["(root): not an object"])
    return document


def freeze(value: Any) -> Any:
    """Read-only copy: mappings become ``MappingProxyType``, lists tuples."""
    if isinstance(value, Mapping):
        return MappingProxyType({key: freeze(item) for key, item in value.items()})
    if isinstance(value, list | tuple):
        return tuple(freeze(item) for item in value)
    return value


def validate_task_item(item: object) -> None:
    """Check one ``papaia.task-item/1`` object; raises :class:`TaskContractError`."""
    _check(item, "")
    _integers(_mapping(item), "(root)")
    _timestamps(_mapping(item), "(root)")


def check_task_list(document: object, *, source: str) -> tuple[Mapping[str, Any], ...]:
    """Check a decoded list body of ``source``; returns its items read-only."""
    _check(document, "#/$defs/list")
    tasks = _mapping(document)["tasks"]
    seen: set[str] = set()
    for index, item in enumerate(tasks):
        where = f"tasks/{index}"
        _integers(item, where)
        _timestamps(item, where)
        if item["source"] != source:
            raise TaskContractError([f"{where}/source: not the answering source"])
        if item["id"] in seen:
            raise TaskContractError([f"{where}/id: duplicate id"])
        seen.add(item["id"])
    return tuple(freeze(item) for item in tasks)


def check_summary(document: object) -> Summary:
    """Check a decoded summary body."""
    _check(document, "#/$defs/summary")
    summary = _mapping(document)
    open_, overdue = summary["open"], summary["overdue"]
    if type(open_) is not int or type(overdue) is not int:
        raise TaskContractError(["(root): counts must be JSON integers"])
    if overdue > open_:
        raise TaskContractError(["overdue: larger than open"])
    return Summary(open=open_, overdue=overdue, revision=summary["revision"])


def parse_task_list(body: bytes, *, source: str) -> tuple[Mapping[str, Any], ...]:
    """Check the body of ``GET /api/v1/me/tasks`` answered by ``source``."""
    return check_task_list(_load(body), source=source)


def parse_summary(body: bytes) -> Summary:
    """Check the body of ``GET /api/v1/me/tasks/summary``."""
    return check_summary(_load(body))
