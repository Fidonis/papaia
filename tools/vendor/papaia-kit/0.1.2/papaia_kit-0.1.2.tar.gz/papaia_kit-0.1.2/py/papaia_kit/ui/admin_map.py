"""Administration map and dependent places (interface spec 2.4 and 7).

``contract/admin-map.yaml`` fixes the navigation group "Verwaltung" of every
module: the same entries in the same order and with the same titles, the
emergency stop first, the audit log as a row into the manager without a module
route, the review group at ``/reviews``, permanent redirects (``308``) for the
old paths and the list task -> place -> role. ``contract/depends-on.yaml``
lists the places whose function depends on another module, where the fixed
sentence "<module> is not set up in this installation" replaces the link when
that module has no ``ui[]`` entry in the catalog.

Links are built from the catalog only (:mod:`papaia_kit.ui.address`). The map
decides what the navigation shows; every page checks rights server-side.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlencode, urlsplit

import yaml
from jsonschema import Draft202012Validator

from papaia_kit._resources import contract_dir
from papaia_kit.catalog.document import Catalog
from papaia_kit.ui.address import LIST_KEY, target_url

__all__ = [
    "AdminEntry",
    "AdminMap",
    "AdminMapError",
    "AdminTask",
    "DependentPlace",
    "DependsOn",
    "entry_url",
    "load_admin_map",
    "load_depends_on",
    "unmapped_admin_pages",
]

ADMIN_NAV_GROUP = "nav.admin"
"""``nav_group`` key of the group "Verwaltung" in the page list."""
_FIRST = "emergency_stop"
_NO_ADMINISTRATION = frozenset({"me", "manager"})
_ADMIN_URL = "admin_url"
"""Task path that stands for the module's ``admin_url`` in the catalog."""
_MODULE = re.compile(r"[a-z0-9][a-z0-9._-]{0,63}")
"""Module id grammar of the catalog (``Module`` in ``admin-map.schema.json``)."""


class AdminMapError(ValueError):
    """``admin-map.yaml`` or ``depends-on.yaml`` failed a check."""


@dataclass(frozen=True)
class AdminEntry:
    id: str
    title: Mapping[str, str]
    path: str | None
    """Own path of the module; ``None`` for a row that leads into the manager."""
    target: str | None
    """``<module>:<target>`` in the catalog for a row without a module route."""
    filter_module: bool
    modules: tuple[str, ...] | None
    """Only these modules show the entry; ``None``: every module with administration."""
    optional: bool


@dataclass(frozen=True)
class AdminTask:
    id: str
    place: str
    path: str
    """Own path, or ``admin_url`` for the module's administration overview."""
    role: str
    module: str | None = None
    """Only this module has the page (domain administration); ``None``: every module."""


@dataclass(frozen=True)
class AdminMap:
    group_title: Mapping[str, str]
    entries: tuple[AdminEntry, ...]
    review_title: Mapping[str, str]
    review_path: str
    redirect_status: int
    redirects: Mapping[str, tuple[str | None, str | None]]
    tasks: tuple[AdminTask, ...]

    def entries_for(self, module: str) -> tuple[AdminEntry, ...]:
        """Entries of the group "Verwaltung" of ``module``, in display order."""
        if module in _NO_ADMINISTRATION:
            return ()
        return tuple(e for e in self.entries if e.modules is None or module in e.modules)

    def redirect(self, catalog: Catalog, module: str, path: str) -> str | None:
        """New address for an old ``path`` of ``module``, or ``None`` if it is not an old path."""
        if path not in self.redirects:
            return None
        to, to_target = self.redirects[path]
        if to is not None:
            return _own(catalog, module, to)
        assert to_target is not None  # noqa: S101 - the schema requires one of both
        return _manager_link(catalog, to_target, module, filter_module=True)


@dataclass(frozen=True)
class DependentPlace:
    module: str
    place: str
    path: str
    needs: str


@dataclass(frozen=True)
class DependsOn:
    not_set_up: Mapping[str, str]
    places: tuple[DependentPlace, ...]

    def missing(self, catalog: Catalog, module: str) -> tuple[DependentPlace, ...]:
        """Places of ``module`` whose required module is not installed (no ``ui[]`` entry)."""
        return tuple(
            p for p in self.places if p.module == module and catalog.surface(p.needs) is None
        )

    def sentence(self, lang: str, module_title: str) -> str:
        """The fixed sentence for a place whose module ``module_title`` is not set up."""
        if lang not in self.not_set_up:
            raise ValueError(f"no sentence for language {lang!r}")
        return self.not_set_up[lang].replace("{module}", module_title)


def entry_url(catalog: Catalog, module: str, entry: AdminEntry) -> str | None:
    """Address of ``entry`` in ``module``; ``None`` when its target is not in the catalog."""
    if entry.path is not None:
        return _own(catalog, module, entry.path)
    assert entry.target is not None  # noqa: S101 - the schema requires path or target
    return _manager_link(catalog, entry.target, module, filter_module=entry.filter_module)


def unmapped_admin_pages(
    admin: AdminMap, pages: Mapping[str, Any], catalog: Catalog
) -> tuple[tuple[str, str], ...]:
    """``(module, path)`` of each page in group "Verwaltung" without a row in the map.

    The task path ``admin_url`` stands for the path of the module's
    ``admin_url`` in ``catalog``; a task with ``module`` counts only for that
    module.
    """
    cache: dict[str, frozenset[str]] = {}
    return tuple(
        (row["module"], row["path"])
        for row in pages["pages"]
        if row.get("nav_group") == ADMIN_NAV_GROUP
        and row.get("path")
        not in cache.setdefault(row["module"], _mapped_paths(admin, catalog, row["module"]))
    )


def _mapped_paths(admin: AdminMap, catalog: Catalog, module: str) -> frozenset[str]:
    mapped = {e.path for e in admin.entries_for(module) if e.path is not None}
    for task in admin.tasks:
        if task.place != "module" or task.module not in (None, module):
            continue
        if task.path != _ADMIN_URL:
            mapped.add(task.path)
            continue
        surface = catalog.surface(module)
        admin_url = None if surface is None else surface.data.get("admin_url")
        if isinstance(admin_url, str):
            mapped.add(urlsplit(admin_url).path)
    return frozenset(mapped)


def load_admin_map(path: Path | None = None) -> AdminMap:
    """Read and check ``contract/admin-map.yaml`` (or ``path``)."""
    doc = _load(path or contract_dir() / "admin-map.yaml", "admin-map.schema.json")
    entries = tuple(
        AdminEntry(
            id=e["id"],
            title=e["title"],
            path=e.get("path"),
            target=e.get("target"),
            filter_module=e.get("filter") == "module",
            modules=tuple(e["modules"]) if "modules" in e else None,
            optional=bool(e.get("optional", False)),
        )
        for e in doc["entries"]
    )
    tasks = tuple(
        AdminTask(t["id"], t["place"], t["path"], t["role"], t.get("module")) for t in doc["tasks"]
    )
    _unique("entries", [e.id for e in entries])
    _unique("tasks", [t.id for t in tasks])
    _unique("redirects", [r["from"] for r in doc["redirects"]])
    for task in tasks:
        if task.module is not None and task.place != "module":
            raise AdminMapError(f"tasks: {task.id}: module only for a task with place module")
    if not any(e.id == _FIRST for e in entries) or entries[0].id != _FIRST:
        raise AdminMapError(f"entries: {_FIRST} must be the first entry")
    return AdminMap(
        group_title=doc["group"]["title"],
        entries=entries,
        review_title=doc["review"]["title"],
        review_path=doc["review"]["path"],
        redirect_status=doc["redirect_status"],
        redirects={r["from"]: (r.get("to"), r.get("to_target")) for r in doc["redirects"]},
        tasks=tasks,
    )


def load_depends_on(path: Path | None = None) -> DependsOn:
    """Read and check ``contract/depends-on.yaml`` (or ``path``)."""
    doc = _load(path or contract_dir() / "depends-on.yaml", "depends-on.schema.json")
    places = tuple(
        DependentPlace(p["module"], p["place"], p["path"], p["needs"]) for p in doc["places"]
    )
    _unique("places", [f"{p.module}:{p.place}" for p in places])
    if any(p.module == p.needs for p in places):
        raise AdminMapError("places: a module cannot depend on itself")
    return DependsOn(not_set_up=doc["not_set_up"], places=places)


def _own(catalog: Catalog, module: str, path: str) -> str | None:
    surface = catalog.surface(module)
    return None if surface is None else surface.public_url.rstrip("/") + path


def _manager_link(catalog: Catalog, target: str, module: str, *, filter_module: bool) -> str | None:
    if filter_module and not _MODULE.fullmatch(module):
        raise ValueError("not a module id")
    owner, _, name = target.partition(":")
    url = target_url(catalog, owner, name, LIST_KEY)
    if url is None or not filter_module:
        return url
    return f"{url}?{urlencode({'module': module})}"


def _unique(place: str, ids: list[str]) -> None:
    seen: set[str] = set()
    for value in ids:
        if value in seen:
            raise AdminMapError(f"{place}: {value} listed twice")
        seen.add(value)


def _load(path: Path, schema_name: str) -> Any:
    schema = json.loads((contract_dir() / schema_name).read_text(encoding="utf-8"))
    try:
        document = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, yaml.YAMLError) as exc:
        raise AdminMapError(f"{path.name}: unreadable ({type(exc).__name__})") from None
    errors = list(Draft202012Validator(schema).iter_errors(document))
    if errors:
        first = min(errors, key=lambda e: len(list(e.absolute_path)))
        place = "/".join(str(p) for p in first.absolute_path) or "(document)"
        extra = ""
        if first.validator == "additionalProperties" and isinstance(first.instance, Mapping):
            known = first.schema.get("properties", {})
            extra = " " + ", ".join(sorted(k for k in first.instance if k not in known))
        raise AdminMapError(f"{path.name}: {place}: breaks rule {first.validator}{extra}")
    return document
