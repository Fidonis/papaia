"""Audit writer for the ``papaia.audit/1`` format, delivered through an outbox.

This module holds the format: the schema ``schemas/audit.v1.schema.json`` and
:func:`validate_event`, which every writer runs before an event leaves the
source and which ``papaia-audit`` runs again at ingest. Field rules live in
``contract/audit.md``.
"""

from __future__ import annotations

import copy
import json
from collections.abc import Mapping
from datetime import datetime
from functools import cache
from itertools import islice
from typing import Any, Literal

from jsonschema import Draft202012Validator, FormatChecker
from jsonschema.exceptions import ValidationError
from referencing import Registry, Resource

from papaia_kit._resources import schemas_dir

AUDIT_FORMAT = "papaia.audit/1"
AUDIT_SCHEMA_ID = "https://schemas.papaia.dev/audit.v1.schema.json"
SCHEMA_FILE = "audit.v1.schema.json"

Stage = Literal["submission", "stored"]
_TARGETS: dict[str, str] = {
    "submission": f"{AUDIT_SCHEMA_ID}#/$defs/submission",
    "stored": AUDIT_SCHEMA_ID,
}

# Problem texts name fields and rules, never values: a rejected event may carry
# exactly the token or content it is rejected for. A field name is only echoed
# when it is a field of the schema or one of the content field names below,
# which a writer most likely added by mistake; any other key may itself be a
# secret used as a key and is shown as <redacted>.
_CONTENT_FIELD_NAMES = frozenset(
    {
        "access_token",
        "answer",
        "authorization",
        "body",
        "content",
        "document",
        "embedding",
        "id_token",
        "message",
        "password",
        "payload",
        "prompt",
        "query",
        "refresh_token",
        "request",
        "response",
        "secret",
        "text",
        "title",
        "token",
        "vector",
    }
)
_MAX_PROBLEMS = 20

# Limits checked before any pattern runs (contract/audit.md, "Checks beyond the
# schema"). MAX_STRING_LENGTH is the largest maxLength in the schema; MAX_DEPTH
# counts the objects and arrays from the event down to detail.objects.
MAX_STRING_LENGTH = 256
MAX_EVENT_BYTES = 16 * 1024
MAX_DEPTH = 3
_MAX_NODES = 512
_TIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"

__all__ = [
    "AUDIT_FORMAT",
    "AUDIT_SCHEMA_ID",
    "MAX_DEPTH",
    "MAX_EVENT_BYTES",
    "MAX_STRING_LENGTH",
    "AuditEventError",
    "Stage",
    "audit_schema",
    "event_names",
    "validate_event",
]


class AuditEventError(ValueError):
    """An event does not conform to ``papaia.audit/1``.

    ``problems`` lists ``<json path>: <rule>`` entries without any value of the event.
    """

    def __init__(self, problems: list[str]) -> None:
        self.problems: tuple[str, ...] = tuple(problems)
        super().__init__("audit event rejected: " + "; ".join(self.problems))


@cache
def _schema() -> dict[str, Any]:
    """Private copy of the schema; only the validator and this module read it."""
    schema: dict[str, Any] = json.loads((schemas_dir() / SCHEMA_FILE).read_text(encoding="utf-8"))
    if schema.get("$id") != AUDIT_SCHEMA_ID:
        raise RuntimeError(f"{SCHEMA_FILE} carries an unexpected $id")
    return schema


def audit_schema() -> dict[str, Any]:
    """The ``papaia.audit/1`` schema as shipped with the kit (a fresh copy on every call)."""
    return copy.deepcopy(_schema())


def event_names() -> frozenset[str]:
    """All values allowed in the ``event`` field."""
    return frozenset(_schema()["$defs"]["event"]["enum"])


def _is_event_time(instance: object) -> bool:
    if not isinstance(instance, str):
        return True
    try:
        datetime.strptime(instance, _TIME_FORMAT)
    except ValueError:
        return False
    return True


@cache
def _validator(stage: str) -> Draft202012Validator:
    registry: Registry[Any] = Registry().with_resource(
        AUDIT_SCHEMA_ID, Resource.from_contents(copy.deepcopy(_schema()))
    )
    formats = FormatChecker(("ipv4", "ipv6"))
    formats.checks("date-time")(_is_event_time)
    return Draft202012Validator(
        {"$ref": _TARGETS[stage]},
        registry=registry,
        format_checker=formats,
    )


def validate_event(event: object, *, stage: Stage = "submission") -> None:
    """Check one event against ``papaia.audit/1``; raise :class:`AuditEventError` if it fails.

    ``stage`` is ``"submission"`` for an event a source writes (no ``source``,
    ``seq``, ``prev_hash`` or ``hash``) and ``"stored"`` for an event as
    ``papaia-audit`` keeps and exports it. The event is not modified.
    """
    if stage not in _TARGETS:
        raise ValueError(f"unknown stage {stage!r}; expected 'submission' or 'stored'")
    if not isinstance(event, Mapping):
        raise AuditEventError(["$: not a JSON object"])
    # Bound the work before any pattern runs: depth, node count and string
    # length first (without recursion), then the serialised size.
    _check_limits(event)
    try:
        # Round trip so that only plain JSON is validated: no NaN, no bytes, no
        # objects that compare like JSON but serialise otherwise. The size limit
        # applies to this compact UTF-8 form (contract/audit.md).
        text = json.dumps(event, allow_nan=False, ensure_ascii=False, separators=(",", ":"))
    except (TypeError, ValueError, RecursionError):
        raise AuditEventError(["$: not plain JSON"]) from None
    if len(text.encode("utf-8")) > MAX_EVENT_BYTES:
        raise AuditEventError(["$: event too large"])
    plain = json.loads(text)
    if not isinstance(plain, dict):
        raise AuditEventError(["$: not plain JSON"])
    errors = sorted(_validator(stage).iter_errors(plain), key=_error_order)
    if errors:
        problems: list[str] = []
        for error in errors:
            for problem in _describe(error):
                if problem not in problems:
                    problems.append(problem)
        raise AuditEventError(problems[:_MAX_PROBLEMS])


def _check_limits(event: Mapping[str, object]) -> None:
    """Reject oversized strings, deep nesting, huge containers, fractions and non-string keys.

    The walk uses no recursion. ``json.dumps`` would silently turn a key such as
    ``True`` or ``7`` into a string, so every object key is checked here.

    The schema has no field of type number: every number is a counter or an
    amount. JSON Schema treats 3.0 as an integer, the hash chain (JCS) and the
    bigint columns of papaia-audit do not, so any float is rejected here.
    """
    stack: list[tuple[object, tuple[str | int, ...], int]] = [(event, (), 1)]
    nodes = 0
    while stack:
        node, path, depth = stack.pop()
        nodes += 1
        if nodes > _MAX_NODES:
            raise AuditEventError(["$: event too large"])
        if isinstance(node, str):
            if len(node) > MAX_STRING_LENGTH:
                raise AuditEventError([f"{_path(path)}: too long"])
            continue
        if isinstance(node, float):
            raise AuditEventError([f"{_path(path)}: invalid value (type)"])
        if isinstance(node, Mapping):
            children: list[tuple[str | int, object]] = list(islice(node.items(), _MAX_NODES + 1))
        elif isinstance(node, (list, tuple)):
            children = list(enumerate(islice(node, _MAX_NODES + 1)))
        else:
            continue
        if depth > MAX_DEPTH:
            raise AuditEventError([f"{_path(path)}: nested too deeply"])
        if isinstance(node, Mapping) and not all(isinstance(key, str) for key, _ in children):
            raise AuditEventError(["$: not plain JSON"])
        for key, child in reversed(children):
            if isinstance(key, str) and len(key) > MAX_STRING_LENGTH:
                raise AuditEventError([f"{_path(path)}.<redacted>: too long"])
            stack.append((child, (*path, key), depth + 1))


def _error_order(error: ValidationError) -> tuple[str, str]:
    return (_path(error.absolute_path), str(error.validator))


def _path(parts: Any) -> str:
    text = "$"
    for part in parts:
        if isinstance(part, int):
            text += f"[{part}]"
        else:
            text += f".{_name(str(part))}"
    return text


@cache
def _shown_names() -> frozenset[str]:
    """Every property name the schema declares, plus the content field names."""
    names: set[str] = set(_CONTENT_FIELD_NAMES)
    stack: list[Any] = [_schema()]
    while stack:
        node = stack.pop()
        if isinstance(node, dict):
            properties = node.get("properties")
            if isinstance(properties, dict):
                names.update(properties)
            stack.extend(node.values())
        elif isinstance(node, list):
            stack.extend(node)
    return frozenset(names)


def _name(name: str) -> str:
    return name if name in _shown_names() else "<redacted>"


def _describe(error: ValidationError) -> list[str]:
    """Problem texts for one error, deepest cause first for composite rules."""
    path = _path(error.absolute_path)
    keyword = str(error.validator)
    instance = error.instance
    if keyword == "required" and isinstance(instance, dict):
        required = error.validator_value if isinstance(error.validator_value, list) else []
        return [
            f"{path}.{_name(str(field))}: missing" for field in required if field not in instance
        ] or [f"{path}: missing field"]
    if keyword in ("unevaluatedProperties", "additionalProperties") and isinstance(instance, dict):
        known = _known_properties(error)
        unknown = sorted(_name(str(key)) for key in instance if str(key) not in known)
        return [f"{path}.{name}: unknown field" for name in unknown] or [f"{path}: unknown field"]
    if keyword in ("anyOf", "allOf", "oneOf") and error.context:
        # Report the failures of the branches that could apply; the "or null"
        # branch of an optional field says nothing about a wrong string.
        relevant = [
            sub
            for sub in error.context
            if not (str(sub.validator) == "type" and sub.validator_value == "null")
        ]
        problems: list[str] = []
        for sub in sorted(relevant or error.context, key=_error_order):
            problems.extend(p for p in _describe(sub) if p not in problems)
        return problems
    if keyword == "not":
        return [f"{path}: value shaped like a token"]
    return [f"{path}: invalid value ({keyword})"]


def _known_properties(error: ValidationError) -> set[str]:
    """Property names the failing (sub)schema declares, gathered through its references."""
    names: set[str] = set()
    schema = _schema()
    stack: list[Any] = [error.schema]
    seen: set[int] = set()
    while stack:
        node = stack.pop()
        if not isinstance(node, dict) or id(node) in seen:
            continue
        seen.add(id(node))
        names.update(node.get("properties", {}))
        ref = node.get("$ref")
        if isinstance(ref, str):
            pointer = ref.split("#", 1)[1] if "#" in ref else ""
            target: Any = schema
            for part in filter(None, pointer.split("/")):
                target = target.get(part, {}) if isinstance(target, dict) else {}
            stack.append(target)
        stack.extend(node.get("allOf", []))
    return names
