"""Compact JWT encoding and reading of claims without verification.

The exchange client reads claims only to route a request (own token or chain)
and to check that the issuer answered what was asked. It never decides access
on them; the resource server verifies every token (``papaia_kit.authz``).
"""

from __future__ import annotations

import base64
import binascii
import json
import re

MAX_TOKEN_LENGTH = 16 * 1024
_SEGMENT = re.compile(r"[A-Za-z0-9_-]+")


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(segment: str) -> bytes:
    if not _SEGMENT.fullmatch(segment):
        raise ValueError("segment is not base64url")
    try:
        return base64.urlsafe_b64decode(segment + "=" * (-len(segment) % 4))
    except (binascii.Error, ValueError):
        raise ValueError("segment is not base64url") from None


def _unique_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate member {key!r}")
        result[key] = value
    return result


def parse_json_object(raw: bytes) -> dict[str, object]:
    """A JSON object with unique member names; anything else is a ValueError."""
    try:
        value = json.loads(raw, object_pairs_hook=_unique_keys)
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError):
        raise ValueError("not a JSON document") from None
    if not isinstance(value, dict):
        raise ValueError("not a JSON object")
    return value


def unverified_claims(token: object) -> dict[str, object]:
    """The claims of a compact JWS, read without checking its signature."""
    if not isinstance(token, str):
        raise ValueError("token must be a string")
    if not token or len(token) > MAX_TOKEN_LENGTH:
        raise ValueError(f"token must have 1 to {MAX_TOKEN_LENGTH} characters")
    parts = token.split(".")
    if len(parts) != 3 or not all(parts):  # noqa: PLR2004 - header.payload.signature
        raise ValueError("token is not a compact JWS")
    _b64url_decode(parts[2])
    parse_json_object(_b64url_decode(parts[0]))
    return parse_json_object(_b64url_decode(parts[1]))
