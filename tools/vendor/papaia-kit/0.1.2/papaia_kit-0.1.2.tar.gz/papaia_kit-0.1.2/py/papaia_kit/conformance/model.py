"""Model suite: the model requests of a module use only the allowed features (M-03).

The suite reads the recording of the kit test model (one JSON line per request
the module sent) and checks every request against the declared model needs of
the module (``exposes[].models.needs``): only the routes of the model gateway,
only declared platform aliases and never a model or provider name, only the
request fields the gateway unifies across providers, and features such as
tools, structured output or streaming only on an alias that declares them.

Failures name the request, the check and the field, never message content.
"""

from __future__ import annotations

import json
import re
import time
from collections.abc import Callable, Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any

from papaia_kit.conformance.result import Case, SuiteResult, case
from papaia_kit.conformance.static_patterns import MODEL

SUITE = "model"
MODEL_CHECKS = ("route", "alias", "features", "messages", "tools", "response_format", "sampling")
FEATURES = frozenset({"chat", "tools", "json_schema", "json_object", "stream", "embeddings"})
CHAT_ROUTE = ("POST", "/v1/chat/completions")
MODELS_ROUTE = ("GET", "/v1/models")
MAX_RECORDING_BYTES = 64 * 1024 * 1024
MAX_STOP = 4
MAX_TEMPERATURE = 2
MAX_TOOLS = 128

ALLOWED_FIELDS = frozenset(
    {
        "model",
        "messages",
        "temperature",
        "top_p",
        "max_tokens",
        "stop",
        "stream",
        "tools",
        "tool_choice",
        "response_format",
        "n",
    }
)
# Fields a module might be tempted to send, with the reason they are not allowed.
FORBIDDEN_FIELDS = {
    "user": "a person reference to the model gateway",
    "metadata": "may carry a person reference to the model gateway",
    "parallel_tool_calls": "not unified across providers",
    "logprobs": "not unified across providers",
    "top_logprobs": "not unified across providers",
    "logit_bias": "not unified across providers",
    "seed": "not unified across providers",
    "functions": "replaced by tools",
    "function_call": "replaced by tool_choice",
    "extra_body": "provider-specific",
    "stream_options": "provider-specific",
    "reasoning_effort": "reasoning parameters are provider-specific",
    "thinking": "reasoning parameters are provider-specific",
    "web_search_options": "search parameters are provider-specific",
    "modalities": "image and audio parts are not allowed",
    "audio": "image and audio parts are not allowed",
}
RECORD_FIELDS = frozenset(
    {"seq", "at", "method", "path", "key_id", "headers", "body", "mode", "status"}
)
_ALIAS = re.compile(r"papaia-[a-z0-9-]{1,40}")
_TOOL_NAME = re.compile(r"[A-Za-z0-9_-]{1,64}")
_PRINTABLE = re.compile(r"[^\x21-\x7e]")
_ROLE_FIELDS = {
    "system": frozenset({"role", "content"}),
    "user": frozenset({"role", "content"}),
    "assistant": frozenset({"role", "content", "tool_calls"}),
    "tool": frozenset({"role", "content", "tool_call_id"}),
}
_FEATURE_OF_FORMAT = {"json_schema": "json_schema", "json_object": "json_object"}

Needs = Mapping[str, frozenset[str]]


class ModelSuiteError(ValueError):
    """The declared model needs cannot be read (usage error, not a failed check)."""


def _name(value: object) -> str:
    """A field name for a message: printable, at most 64 characters."""
    return _PRINTABLE.sub("?", str(value))[:64]


# --- inputs -------------------------------------------------------------------


def load_model_needs(
    document: Mapping[str, Any], catalog_id: str | None = None
) -> dict[str, frozenset[str]]:
    """Alias to declared features, over all entries (or entry ``catalog_id``) of a manifest."""
    entries = [e for e in document.get("exposes", []) if isinstance(e, dict)]
    if catalog_id is not None:
        entries = [e for e in entries if e.get("id") == catalog_id]
        if not entries:
            raise ModelSuiteError(f"no entry {catalog_id!r} in the manifest")
    needs: dict[str, set[str]] = {}
    for entry in entries:
        models = entry.get("models")
        if models is None:
            continue
        listed = models.get("needs") if isinstance(models, dict) else None
        if not isinstance(listed, list):
            raise ModelSuiteError(f"entry {_name(entry.get('id'))}: models.needs is not a list")
        for need in listed:
            alias = need.get("alias") if isinstance(need, dict) else None
            features = need.get("features") if isinstance(need, dict) else None
            if not isinstance(alias, str) or not _ALIAS.fullmatch(alias):
                raise ModelSuiteError(f"entry {_name(entry.get('id'))}: malformed alias")
            if not isinstance(features, list) or not set(features) <= FEATURES:
                raise ModelSuiteError(f"entry {_name(entry.get('id'))}: malformed features")
            needs.setdefault(alias, set()).update(features)
    if not needs:
        raise ModelSuiteError("the manifest declares no models.needs; nothing to check against")
    return {alias: frozenset(features) for alias, features in needs.items()}


def load_model_recording(data: bytes) -> list[dict[str, Any]]:
    """Recording lines of the test model; raises ``ValueError`` naming the line."""
    if len(data) > MAX_RECORDING_BYTES:
        raise ValueError(f"larger than {MAX_RECORDING_BYTES} bytes")
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("not UTF-8") from None
    rows = []
    for number, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except (ValueError, RecursionError):
            raise ValueError(f"line {number}: not JSON") from None
        if not isinstance(row, dict) or set(row) != RECORD_FIELDS:
            raise ValueError(f"line {number}: expected exactly the fields {sorted(RECORD_FIELDS)}")
        if not isinstance(row["seq"], int) or not isinstance(row["path"], str):
            raise ValueError(f"line {number}: seq or path has the wrong type")
        if not isinstance(row["method"], str):
            raise ValueError(f"line {number}: method has the wrong type")
        rows.append(row)
    return rows


# --- checks of one chat request -------------------------------------------------


def _alias(body: Mapping[str, Any], needs: Needs) -> list[str]:
    model = body.get("model")
    if not isinstance(model, str):
        return ["model is missing or not a string"]
    if MODEL.search(model):
        return [f"model {_name(model)!r} is a model or provider name; use a platform alias"]
    if not _ALIAS.fullmatch(model):
        return [f"model {_name(model)!r} is not a platform alias (papaia-<purpose>)"]
    if model not in needs:
        return [f"alias {model!r} is not declared in models.needs"]
    return []


def _features(body: Mapping[str, Any], needs: Needs) -> list[str]:
    problems = []
    for field in sorted(set(body) - ALLOWED_FIELDS, key=str):
        reason = FORBIDDEN_FIELDS.get(field, "not an allowed request feature")
        problems.append(f"field {_name(field)!r} is not allowed: {reason}")
    if "n" in body and (isinstance(body["n"], bool) or body["n"] != 1):
        problems.append("field 'n' must be 1")
    model = body.get("model")
    declared = needs.get(model) if isinstance(model, str) else None
    used = []
    if "tools" in body:
        used.append("tools")
    response_format = body.get("response_format")
    if isinstance(response_format, dict) and response_format.get("type") in _FEATURE_OF_FORMAT:
        used.append(_FEATURE_OF_FORMAT[response_format["type"]])
    if body.get("stream") is True:
        used.append("stream")
    for feature in used:
        if declared is None:
            problems.append(f"feature {feature!r} used on an alias that is not declared")
        elif feature not in declared:
            problems.append(f"feature {feature!r} used on an alias that does not declare it")
    return problems


def _tool_call_problems(calls: object, where: str) -> list[str]:
    if not isinstance(calls, list) or not calls:
        return [f"{where}.tool_calls must be a non-empty list"]
    problems = []
    for index, call in enumerate(calls):
        at = f"{where}.tool_calls[{index}]"
        function = call.get("function") if isinstance(call, dict) else None
        if (
            not isinstance(call, dict)
            or set(call) != {"id", "type", "function"}
            or call["type"] != "function"
            or not isinstance(call["id"], str)
            or not isinstance(function, dict)
            or set(function) != {"name", "arguments"}
            or not isinstance(function["name"], str)
            or not isinstance(function["arguments"], str)
        ):
            problems.append(f"{at} must be {{id, type: function, function: {{name, arguments}}}}")
    return problems


def _messages(body: Mapping[str, Any]) -> list[str]:
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        return ["messages must be a non-empty list"]
    problems = []
    for index, message in enumerate(messages):
        where = f"messages[{index}]"
        if not isinstance(message, dict):
            problems.append(f"{where} is not an object")
            continue
        role = message.get("role")
        allowed = _ROLE_FIELDS.get(role) if isinstance(role, str) else None
        if allowed is None:
            problems.append(f"{where}: role is not one of {sorted(_ROLE_FIELDS)}")
            continue
        if unknown := set(message) - allowed:
            names = sorted(_name(u) for u in unknown)
            problems.append(f"{where}: fields {names} are not allowed for role {role}")
        content = message.get("content")
        with_calls = role == "assistant" and "tool_calls" in message
        if not isinstance(content, str) and not (with_calls and content is None):
            problems.append(f"{where}: content must be a string (no content parts)")
        if with_calls:
            problems += _tool_call_problems(message["tool_calls"], where)
        if role == "tool" and not isinstance(message.get("tool_call_id"), str):
            problems.append(f"{where}: a tool message needs tool_call_id")
    return problems


def _tools(body: Mapping[str, Any]) -> list[str]:
    problems = []
    if "tool_choice" in body:
        if body["tool_choice"] not in ("auto", "none"):
            problems.append("tool_choice must be 'auto' or 'none'")
        if "tools" not in body:
            problems.append("tool_choice without tools")
    if "tools" not in body:
        return problems
    tools = body["tools"]
    if not isinstance(tools, list) or not 0 < len(tools) <= MAX_TOOLS:
        return [*problems, f"tools must be a list of 1 to {MAX_TOOLS} tools"]
    for index, tool in enumerate(tools):
        where = f"tools[{index}]"
        function = tool.get("function") if isinstance(tool, dict) else None
        if (
            not isinstance(tool, dict)
            or set(tool) != {"type", "function"}
            or tool["type"] != "function"
        ):
            problems.append(f"{where} must be {{type: function, function}}")
            continue
        if not isinstance(function, dict) or not {"name"} <= set(function) <= {
            "name",
            "description",
            "parameters",
        }:
            problems.append(f"{where}.function holds only name, description and parameters")
            continue
        if not isinstance(function["name"], str) or not _TOOL_NAME.fullmatch(function["name"]):
            problems.append(f"{where}.function.name must be 1 to 64 of [A-Za-z0-9_-]")
        if "description" in function and not isinstance(function["description"], str):
            problems.append(f"{where}.function.description must be a string")
        if "parameters" in function and not isinstance(function["parameters"], dict):
            problems.append(f"{where}.function.parameters must be a JSON Schema object")
    return problems


def _response_format(body: Mapping[str, Any]) -> list[str]:
    if "response_format" not in body:
        return []
    value = body["response_format"]
    if isinstance(value, dict) and value == {"type": "json_object"}:
        return []
    if (
        isinstance(value, dict)
        and set(value) == {"type", "json_schema"}
        and value["type"] == "json_schema"
    ):
        spec = value["json_schema"]
        if (
            isinstance(spec, dict)
            and {"name", "schema"} <= set(spec) <= {"name", "schema", "strict"}
            and isinstance(spec["name"], str)
            and isinstance(spec["schema"], dict)
            and isinstance(spec.get("strict", False), bool)
        ):
            return []
    return [
        "response_format must be {type: json_schema, json_schema: {name, schema, strict?}} "
        "or {type: json_object}"
    ]


def _number(value: object) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _sampling(body: Mapping[str, Any]) -> list[str]:
    problems = []
    if "temperature" in body and not (
        _number(body["temperature"]) and 0 <= body["temperature"] <= MAX_TEMPERATURE
    ):
        problems.append("temperature must be a number from 0 to 2")
    if "top_p" in body and not (_number(body["top_p"]) and 0 <= body["top_p"] <= 1):
        problems.append("top_p must be a number from 0 to 1")
    max_tokens = body.get("max_tokens", 1)
    if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens < 1:
        problems.append("max_tokens must be a positive integer")
    if "stop" in body:
        stop = body["stop"]
        listed = stop if isinstance(stop, list) else [stop]
        if not 0 < len(listed) <= MAX_STOP or not all(isinstance(s, str) for s in listed):
            problems.append(f"stop must be a string or a list of 1 to {MAX_STOP} strings")
    if "stream" in body and not isinstance(body["stream"], bool):
        problems.append("stream must be true or false")
    return problems


_CHAT_CHECKS: dict[str, Callable[[Mapping[str, Any], Needs], list[str]]] = {
    "alias": _alias,
    "features": _features,
    "messages": lambda body, _: _messages(body),
    "tools": lambda body, _: _tools(body),
    "response_format": lambda body, _: _response_format(body),
    "sampling": lambda body, _: _sampling(body),
}


# --- suite ----------------------------------------------------------------------


def _request_cases(row: Mapping[str, Any], group: str, needs: Needs) -> Iterable[Case]:
    route = (row["method"], row["path"])
    if route not in (CHAT_ROUTE, MODELS_ROUTE):
        message = (
            f"route {_name(row['method'])} {_name(row['path'])} is not allowed; modules call "
            "only POST /v1/chat/completions and GET /v1/models"
        )
        yield case(SUITE, group, "route", [message])
        return
    yield case(SUITE, group, "route", [])
    if route == MODELS_ROUTE:
        return
    body = row["body"]
    for name, check in _CHAT_CHECKS.items():
        problems = check(body, needs) if isinstance(body, dict) else ["body is not a JSON object"]
        yield case(SUITE, group, name, problems)


def run_model_suite(
    rows: Sequence[Mapping[str, Any]], needs: Needs, *, source: str = "recording"
) -> SuiteResult:
    """One case per check of every recorded request; no chat request fails the run."""
    started = time.monotonic()
    cases: list[Case] = []
    for row in rows:
        cases += _request_cases(row, f"{source}#{row['seq']}", needs)
    chats = sum(1 for row in rows if (row["method"], row["path"]) == CHAT_ROUTE)
    if not chats:
        cases.append(
            case(SUITE, source, "requests", ["no chat completion request recorded; run the module"])
        )
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started)


def check_model_recording_file(path: Path, needs: Needs) -> SuiteResult:
    """The model suite over the recording file at ``path``; an unreadable file fails ``load``."""
    try:
        rows = load_model_recording(path.read_bytes())
    except OSError as exc:
        problem = f"cannot read ({exc.strerror or type(exc).__name__})"
        return SuiteResult(SUITE, (case(SUITE, path.name, "load", [problem]),))
    except ValueError as exc:
        return SuiteResult(SUITE, (case(SUITE, path.name, "load", [str(exc)]),))
    return run_model_suite(rows, needs, source=path.name)
