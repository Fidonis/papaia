"""The platform halt as every module reads it (security 4.11, PLT-61, OPS-20, KE-15).

The core's host command writes ``state/halt.json`` (``{active, since, reason,
by}``) below the platform configuration folder by renaming a complete file into
place. Every container that acts mounts the *folder* read-only (a mounted file
would keep showing the replaced one) and holds one :class:`HaltGuard`:

* :meth:`HaltGuard.require` before each write, send, delete, model call, flow
  step and delivery: one ``stat`` call, no network; the file is parsed again
  when it changed and at least every :data:`POLL_SECONDS`. A refused write,
  send or delete hands one ``papaia.audit/1`` row to the audit writer.
* :meth:`HaltGuard.start_polling` re-reads every :data:`POLL_SECONDS` for what
  has no action to guard (the notice in every interface, a waiting run).

Reading fails closed: a file that is not exactly the four fields, larger than
:data:`MAX_FILE_BYTES`, no regular file (a symbolic link, a folder, a pipe) or
unreadable, a missing folder, and a file that disappeared after the guard saw
one, all count as an active halt. No file in an existing folder is no halt.
The guard only reads; it never creates or changes the folder or the file.
See ``contract/halt.md``.
"""

from __future__ import annotations

import json
import logging
import os
import re
import stat
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Any, Final

from papaia_kit.authz import AUDIT_FORMAT, AuditSink, Principal, Request
from papaia_kit.errors import ErrorEnvelope, build_envelope

__all__ = [
    "DIR_VARIABLE",
    "EFFECTS",
    "HALTED_CODE",
    "HALTED_STATUS",
    "HALT_FILE",
    "MAX_FILE_BYTES",
    "POLL_SECONDS",
    "Action",
    "HaltGuard",
    "HaltPoller",
    "HaltState",
    "PlatformHalted",
    "parse",
    "read",
]

HALT_FILE: Final = "halt.json"
#: The guard re-reads the file at least this often, also without an action to guard.
POLL_SECONDS: Final = 5.0
MAX_FILE_BYTES: Final = 4096
MAX_REASON: Final = 500
MAX_BY: Final = 255
#: Kit code of a refusal (class ``upstream_unavailable``) and its HTTP status.
HALTED_CODE: Final = "PK-HALT-001"
HALTED_STATUS: Final = 503
#: Mount point of the platform's state folder inside the container.
DIR_VARIABLE: Final = "PAPAIA_HALT_DIR"
_SINCE_MAX: Final = 2**63 - 1
_FIELDS: Final = frozenset({"active", "since", "reason", "by"})
_WRITER = re.compile(r"[a-z][a-z0-9-]{0,62}(/[a-z0-9][a-z0-9_.-]{0,62})?")

logger = logging.getLogger("papaia_kit.halt")


class Action(StrEnum):
    """What the halt stops: everything that acts. Reading own data is never guarded."""

    WRITE = "write"
    SEND = "send"
    DELETE = "delete"
    MODEL = "model"
    STEP = "step"
    DELIVERY = "delivery"


#: The actions that are effects of an operation and write an audit row when refused.
EFFECTS: Final = frozenset({Action.WRITE, Action.SEND, Action.DELETE})


@dataclass(frozen=True, slots=True)
class HaltState:
    """The halt as read; ``problem`` says why an unusable file counts as active.

    ``problem`` never quotes the file: reason and author stay in it, the guard
    neither logs nor shows them.
    """

    active: bool
    since: int | None = None
    problem: str | None = None


_NO_HALT: Final = HaltState(False)


def _no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    keys = [key for key, _ in pairs]
    if len(set(keys)) != len(keys):
        raise ValueError("duplicate field")
    return dict(pairs)


def _format_problem(document: object) -> str | None:
    if not isinstance(document, dict) or set(document) != _FIELDS:
        return "unexpected fields"
    since, reason, by = document["since"], document["reason"], document["by"]
    checks = (
        (isinstance(document["active"], bool), "active is not a boolean"),
        (
            isinstance(since, int) and not isinstance(since, bool) and 0 <= since <= _SINCE_MAX,
            "since is not a time in seconds",
        ),
        (isinstance(reason, str) and len(reason) <= MAX_REASON, "reason is not a short text"),
        (isinstance(by, str) and 0 < len(by) <= MAX_BY, "by is not a name"),
    )
    return next((text for ok, text in checks if not ok), None)


def parse(data: bytes) -> HaltState:
    """The state in ``data``; anything but the documented format is an active halt."""
    if len(data) > MAX_FILE_BYTES:
        return HaltState(True, problem="larger than expected")
    try:
        document: object = json.loads(data.decode("utf-8"), object_pairs_hook=_no_duplicates)
    except (UnicodeDecodeError, ValueError, RecursionError):
        return HaltState(True, problem="not JSON")
    problem = _format_problem(document)
    if problem is not None:
        return HaltState(True, problem=problem)
    assert isinstance(document, dict)  # noqa: S101 - _format_problem checked it
    return HaltState(document["active"], document["since"])


def read(path: Path, *, expected: bool = False) -> HaltState:
    """The state at ``path``. No file: no halt, unless ``expected``. Unreadable: active."""
    try:
        # O_NONBLOCK: a named pipe in place of the file must not stall the guard.
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        if not path.parent.is_dir():
            return HaltState(True, problem="halt folder missing")
        return HaltState(True, problem="halt file missing") if expected else _NO_HALT
    except OSError as exc:
        return HaltState(True, problem=f"unreadable ({type(exc).__name__})")
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            return HaltState(True, problem="not a regular file")
        chunks: list[bytes] = []
        size = 0
        while size <= MAX_FILE_BYTES:
            chunk = os.read(fd, MAX_FILE_BYTES + 1 - size)
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
        return parse(b"".join(chunks))
    except OSError as exc:
        return HaltState(True, problem=f"unreadable ({type(exc).__name__})")
    finally:
        os.close(fd)


class PlatformHalted(Exception):  # noqa: N818 - reads as "raise PlatformHalted"
    """The platform halt refused ``action``; answer with ``envelope`` and ``status``."""

    def __init__(
        self,
        action: Action,
        state: HaltState,
        envelope: ErrorEnvelope,
        audit_row: dict[str, Any] | None,
    ) -> None:
        super().__init__(f"platform halt: {action.value} refused")
        self.action = action
        self.state = state
        self.envelope = envelope
        self.status = envelope.status
        self.audit_row = audit_row


def _timestamp(now: float) -> str:
    moment = datetime.fromtimestamp(now, UTC)
    return moment.strftime("%Y-%m-%dT%H:%M:%S.") + f"{moment.microsecond // 1000:03d}Z"


class HaltGuard:
    """Reader of the platform halt; ``directory=None`` switches it off (stand-alone).

    ``audit`` and ``writer`` are the module's audit writer and its ``writer``
    value; they are needed only to refuse writes, sends and deletes. An
    exception of ``audit`` propagates, so a refusal is never silently
    unrecorded; the action is refused either way. ``on_change`` is called with
    the new state whenever a read changes it.
    """

    def __init__(
        self,
        directory: Path | None,
        *,
        audit: AuditSink | None = None,
        writer: str | None = None,
        on_change: Callable[[HaltState], None] | None = None,
        poll_seconds: float = POLL_SECONDS,
        clock: Callable[[], float] = time.monotonic,
        wall_clock: Callable[[], float] = time.time,
        lang: str = "de",
    ) -> None:
        if directory is not None and not Path(directory).is_absolute():
            raise ValueError("the halt folder must be an absolute path")
        if writer is not None and not _WRITER.fullmatch(writer):
            raise ValueError("writer must be '<source>' or '<source>/<component>'")
        if not 0 < poll_seconds <= POLL_SECONDS:
            raise ValueError(f"poll_seconds must be above 0 and at most {POLL_SECONDS:g}")
        self._path = None if directory is None else Path(directory) / HALT_FILE
        self._audit = audit
        self._writer = writer
        self._on_change = on_change
        self._poll_seconds = poll_seconds
        self._clock = clock
        self._wall_clock = wall_clock
        self._lang = lang
        self._lock = threading.Lock()
        self._key: tuple[object, ...] | None = None
        self._read_at: float | None = None
        self._seen = False
        self._state = _NO_HALT

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None, **options: Any) -> HaltGuard:
        """Guard for ``PAPAIA_HALT_DIR``; unset or empty is stand-alone, refused in the suite."""
        env = os.environ if environ is None else environ
        folder = env.get(DIR_VARIABLE, "")
        if folder:
            return cls(Path(folder), **options)
        if env.get("PAPAIA_MODE") == "suite":
            raise ValueError(f"{DIR_VARIABLE} must name the mounted state folder in the suite")
        return cls(None, **options)

    @property
    def enabled(self) -> bool:
        """Whether a halt folder is configured."""
        return self._path is not None

    def check(self) -> HaltState:
        """The current state: one ``stat``; parsed again on change or when the poll is due."""
        return self._look(force=False)

    def poll(self) -> HaltState:
        """Read the file again whatever its ``stat`` says (timer step)."""
        return self._look(force=True)

    def halted(self) -> bool:
        """True while the platform halt is active or the file is unusable."""
        return self.check().active

    def require(
        self,
        action: Action,
        *,
        correlation_id: str,
        principal: Principal | None = None,
        request: Request | None = None,
    ) -> None:
        """Raise :class:`PlatformHalted` when ``action`` must not happen now.

        A write, send or delete needs the ``principal`` and ``request`` of the
        operation, whose effect must be the action: its refusal writes one
        ``denied`` row with error code ``PK-HALT-001``.
        """
        if not isinstance(action, Action):
            raise ValueError("action must be one of papaia_kit.halt.Action")
        if action in EFFECTS:
            self._check_effect(action, principal, request)
        state = self.check()
        if not state.active:
            return
        envelope = build_envelope(
            HALTED_CODE, correlation_id=correlation_id, lang=self._lang, status=HALTED_STATUS
        )
        row = None
        if action in EFFECTS and principal is not None and request is not None:
            row = self._row(principal, request)
        logger.warning(
            "platform halt: %s refused correlation_id=%s", action.value, envelope.correlation_id
        )
        if row is not None and self._audit is not None:
            self._audit(row)
        raise PlatformHalted(action, state, envelope, row)

    def start_polling(self, interval: float = POLL_SECONDS) -> HaltPoller:
        """Start a daemon thread that polls every ``interval`` seconds (at most 5)."""
        if not 0 < interval <= POLL_SECONDS:
            raise ValueError(f"interval must be above 0 and at most {POLL_SECONDS:g} s")
        poller = HaltPoller(self, interval)
        poller.start()
        return poller

    def _check_effect(
        self, action: Action, principal: Principal | None, request: Request | None
    ) -> None:
        if principal is None or request is None:
            raise ValueError(f"{action.value} needs the principal and request of the operation")
        if str(request.effect) != action.value:
            raise ValueError(f"request effect {request.effect} is not the action {action.value}")
        if self._audit is None or self._writer is None:
            raise ValueError(f"{action.value} needs an audit writer and writer name on the guard")

    def _row(self, principal: Principal, request: Request) -> dict[str, Any]:
        return {
            "format": AUDIT_FORMAT,
            "time": _timestamp(self._wall_clock()),
            "writer": self._writer,
            "result": "denied",
            "event": "operation",
            **principal.audit_fields(),
            "catalog_id": request.catalog_id,
            "operation": request.operation,
            "effect": str(request.effect),
            "error_code": HALTED_CODE,
        }

    def _look(self, *, force: bool) -> HaltState:
        path = self._path
        if path is None:
            return _NO_HALT
        with self._lock:
            key: tuple[object, ...] | None
            try:
                info = os.stat(path, follow_symlinks=False)
                key = (info.st_dev, info.st_ino, info.st_mode, info.st_size)
                key += (info.st_mtime_ns, info.st_ctime_ns)
            except FileNotFoundError:
                key = ("missing", path.parent.is_dir())
            except OSError:
                key = None  # never cached: read() reports it as active
            now = self._clock()
            due = self._read_at is None or now - self._read_at >= self._poll_seconds
            if not (force or due or key is None or key != self._key):
                return self._state
            state = read(path, expected=self._seen)
            if key is not None and key[0] != "missing":
                self._seen = True
            self._key, self._read_at = key, now
            old, self._state = self._state, state
        if state.active != old.active:
            self._changed(state)
        return state

    def _changed(self, new: HaltState) -> None:
        if new.active:
            logger.warning("platform halt active%s", f" ({new.problem})" if new.problem else "")
        else:
            logger.warning("platform halt lifted")
        if self._on_change is None:
            return
        try:
            self._on_change(new)
        except Exception:
            logger.exception("platform halt: change listener failed")


class HaltPoller(threading.Thread):
    """Timer thread of :meth:`HaltGuard.start_polling`; :meth:`stop` ends it."""

    def __init__(self, guard: HaltGuard, interval: float) -> None:
        super().__init__(name="papaia-halt-poll", daemon=True)
        self._guard = guard
        self._interval = interval
        self._stop_event = threading.Event()

    def run(self) -> None:
        while True:
            try:
                self._guard.poll()
            except Exception:
                logger.exception("platform halt: poll failed")
            if self._stop_event.wait(self._interval):
                return

    def stop(self, timeout: float | None = POLL_SECONDS) -> None:
        self._stop_event.set()
        self.join(timeout)
