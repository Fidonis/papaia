"""Finding record and text patterns shared by the scanners of the static suite."""

from __future__ import annotations

import base64
import re
from collections.abc import Iterator, Sequence
from dataclasses import dataclass

from papaia_kit.names.rules import AUD_PREFIX as SCOPE_PREFIX

# Anchor of a finding outside every function and class.
MODULE = "<module>"
# Stands for a runtime value inside query or scope text assembled from pieces.
HOLE = " ? "

# Constant text a scanner may paste into assembled strings, per file. Pasting a
# constant at every use multiplies its size, so without a bound a file of a few
# megabytes (or a constant doubled line by line) would expand to gigabytes.
MAX_RESOLVED_TEXT = 32 * 1024 * 1024

__all__ = [
    "HOLE",
    "MAX_RESOLVED_TEXT",
    "MODEL",
    "MODULE",
    "SCOPE_PREFIX",
    "Finding",
    "TextBoundError",
    "TextBudget",
    "is_query",
    "text_hits",
]


class TextBoundError(Exception):
    """Constant text pasted into assembled strings went over the bound of one file.

    Deliberately no ``ValueError``, ``KeyError`` or ``TypeError``: the scanners
    catch those while they fill in format values, and the overflow must reach
    the suite, which reports it as a ``load`` failure of the file.
    """


class TextBudget:
    """Counts the constant text pasted into assembled strings of one file.

    Going over the bound raises ``TextBoundError``, which the suite reports as
    a ``load`` failure of the file: the check fails closed instead of stalling.
    The overflow is also kept (``check``), so a scanner that caught it by
    mistake still fails the file after its scan.
    """

    def __init__(self, limit: int = MAX_RESOLVED_TEXT) -> None:
        self.left = limit

    def spend(self, text: str) -> str:
        self.left -= len(text)
        self.check()
        return text

    def check(self) -> None:
        if self.left < 0:
            mib = MAX_RESOLVED_TEXT // (1024 * 1024)
            msg = f"constants expand to more than {mib} MiB of text; split the file"
            raise TextBoundError(msg)


@dataclass(frozen=True, slots=True)
class Finding:
    """One finding: file, line, rule, subject, the function or class it is in, and the column.

    Two findings of the same rule and subject on one line are two places; the
    column tells them apart.
    """

    path: str
    line: int
    rule: str
    subject: str
    message: str
    within: str = MODULE
    column: int = 0


# Model and provider names. The pattern lists vendor and model names in plain
# text once decoded; it is stored base64-encoded because the wording rule of
# this repository keeps vendor names out of every file, the same way the
# denied-word patterns of ``papaia_kit.repo`` are stored. Readers decode it with
# ``python -c "from papaia_kit.conformance.static_patterns import MODEL; print(MODEL.pattern)"``.
# Decision recorded in the security notes of the change that added the suite.
_MODEL_B64 = (
    "KD88IVtcdy46Ly1dKSg/Oig/Om9wZW5haXxhbnRocm9waWN8YXp1cmV8YmVkcm9ja3x2ZXJ0ZXhfYWl8b2xsYW1hfGdyb3F8"
    "bWlzdHJhbHxjb2hlcmV8dG9nZXRoZXJfYWl8aHVnZ2luZ2ZhY2UpL1tcdy46LV0rfGdwdC0/KD86M1wuNXw0b3w0KD86XC5c"
    "ZCk/fDUpW1x3LjotXSp8b1sxMzRdLSg/Om1pbml8cHJldmlld3xwcm8pW1x3LjotXSp8Y2xhdWRlLVtcdy46LV0rfGdlbWlu"
    "aS1bXHcuOi1dK3woPzpjb2RlKT9sbGFtYS0/WzIzNF0oPzpcLlxkKyk/W1x3LjotXSp8KD86bWlzdHJhbHxtaXh0cmFsfGNv"
    "ZGVzdHJhbHxtaW5pc3RyYWwpLVtcdy46LV0rfHF3ZW5cZFtcdy46LV0qfHBoaS0/WzM0XVtcdy46LV0qfGRlZXBzZWVrLVtc"
    "dy46LV0rfGNvbW1hbmQtcltcdysuOi1dKnxnZW1tYVxkP1tcdy46LV0qfHRleHQtZW1iZWRkaW5nLVtcdy4tXSt8bm9taWMt"
    "ZW1iZWQtdGV4dFtcdy46LV0qKSg/IVx3KQ=="
)
MODEL = re.compile(base64.b64decode(_MODEL_B64).decode(), re.IGNORECASE)

# A whole statement at the start of the text (any letter case).
_QUERY = re.compile(
    r"\s*(?:SELECT\b.*\bFROM\b|SELECT\s+\*|INSERT\s+INTO\b|UPDATE\s+\S+\s+SET\b|DELETE\s+FROM\b"
    r"|MERGE\s+INTO\b|WITH\s+\S+\s+AS\s*\(|(?:CREATE|DROP|ALTER|TRUNCATE)\s+"
    r"(?:TABLE|VIEW|INDEX|SCHEMA|DATABASE|FUNCTION|PROCEDURE|ROLE|USER)\b)",
    re.IGNORECASE | re.DOTALL,
)
# A clause anywhere in the text, written in capitals as queries are: the pieces
# of a query built step by step (`base + f" WHERE id = {x}"`).
_FRAGMENT = re.compile(
    r"\b(?:WHERE|AND|OR|HAVING|ON)\s+[\w.\"`]+\s*(?:=|<|>|!=|\bLIKE\b|\bIN\b|\bIS\b|\bBETWEEN\b)"
    r"|\b(?:ORDER|GROUP)\s+BY\b|\bJOIN\s+\S+\s+(?:ON|USING)\b"
    r"|\bLIMIT\s+(?:\d+|\?|%s|\$\d+|:\w+)|\bVALUES\s*\(|\bRETURNING\s+[\w*]"
)


def is_query(template: str) -> bool:
    """Whether text assembled at runtime is query text or a piece of one."""
    return bool(_QUERY.match(template) or _FRAGMENT.search(template))


def text_hits(
    pieces: Sequence[str], *, built: bool, exchange: str, models: bool = True
) -> Iterator[tuple[str, str, str]]:
    """(rule, subject, message) for one string: its literal pieces, joined by runtime values.

    ``built`` says whether runtime values join the pieces; ``exchange`` names the
    kit function of the language that builds scopes. ``models`` is false for
    text that holds constants reported where they are defined.
    """
    template = HOLE.join(pieces)
    if built:
        if is_query(template):
            yield "query-build", "query", "query text assembled at runtime"
        if template.startswith(SCOPE_PREFIX) and template != SCOPE_PREFIX:
            yield "scope-build", SCOPE_PREFIX, "scope built from strings"
    elif list(pieces) == [SCOPE_PREFIX]:
        yield "scope-build", SCOPE_PREFIX, f"bare scope prefix; use {exchange}()"
    for piece in pieces if models else ():
        for match in MODEL.finditer(piece):
            yield "model-name", match.group(0), f"hard-coded model name {match.group(0)!r}"
