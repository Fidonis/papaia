"""``papaia-kit components page``: the fixture page of the components.

Prints the document with the examples of every component of
``contract/patterns/patterns.yaml`` inside the shell (browser test of the kit).
"""

from __future__ import annotations

import argparse
import sys
from typing import Any

from papaia_kit.ui.components import components_page
from papaia_kit.ui.patterns import PatternError
from papaia_kit.ui.shell import ShellInputError
from papaia_kit.ui.tokens import THEMES

__all__ = ["add_parser", "run"]

EXIT_OK, EXIT_FAIL = 0, 1


def add_parser(groups: Any) -> None:
    """Arguments of ``components``; ``groups`` is the top-level subparsers action."""
    components = groups.add_parser("components", help="components fixture page")
    sub = components.add_subparsers(dest="command", required=True)
    page = sub.add_parser("page", help="print the fixture document of the components")
    page.add_argument("--lang", choices=("de", "en"), default="de")
    page.add_argument("--theme", choices=THEMES, default="light")


def run(args: argparse.Namespace) -> int:
    try:
        sys.stdout.write(components_page(lang=args.lang, theme=args.theme))
    except (PatternError, ShellInputError, OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_FAIL
    return EXIT_OK
