"""HTTP transport for token requests.

The default transport uses the standard library, follows no redirect (a
redirect would carry the client credentials elsewhere), ignores proxy
variables of the environment and reads at most ``MAX_RESPONSE`` bytes. Every
failure below the HTTP status code (connection, malformed status or header
line, truncated body) is an ``OSError``.
"""

from __future__ import annotations

import http.client
import urllib.error
import urllib.request
from collections.abc import Mapping
from typing import Protocol
from urllib.parse import urlencode, urlsplit


class Transport(Protocol):
    """Sends one form-encoded POST and returns status code and body."""

    def post_form(
        self, url: str, form: Mapping[str, str], headers: Mapping[str, str], timeout: float
    ) -> tuple[int, bytes]: ...


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args: object, **kwargs: object) -> None:
        return None


class UrllibTransport:
    """Standard library transport; errors other than HTTP status codes raise ``OSError``."""

    MAX_RESPONSE = 64 * 1024

    def __init__(self) -> None:
        self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())

    def _read(self, response: object) -> bytes:
        read = getattr(response, "read", None)
        body = read(self.MAX_RESPONSE + 1) if callable(read) else b""
        if not isinstance(body, bytes):
            raise OSError("response body is not bytes")
        if len(body) > self.MAX_RESPONSE:
            raise OSError(f"response larger than {self.MAX_RESPONSE} bytes")
        # http.client returns a short body silently when the peer closes the
        # connection before Content-Length bytes arrived.
        remaining = getattr(response, "length", None)
        if type(remaining) is int and remaining > 0:
            raise OSError("response body truncated")
        return body

    def post_form(
        self, url: str, form: Mapping[str, str], headers: Mapping[str, str], timeout: float
    ) -> tuple[int, bytes]:
        if urlsplit(url).scheme not in ("http", "https"):
            raise OSError("token endpoint must use http or https")
        request = urllib.request.Request(  # noqa: S310 - scheme checked above
            url,
            data=urlencode(form).encode("ascii"),
            headers={**headers, "Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        try:
            return self._send(request, timeout)
        except http.client.HTTPException as error:
            # Not an OSError (BadStatusLine, LineTooLong, IncompleteRead); the
            # name of the class says enough, the request stays out of the chain.
            raise OSError(f"malformed response: {type(error).__name__}") from None

    def _send(self, request: urllib.request.Request, timeout: float) -> tuple[int, bytes]:
        try:
            with self._opener.open(request, timeout=timeout) as response:
                return int(response.status), self._read(response)
        except urllib.error.HTTPError as error:
            with error:
                return int(error.code), self._read(error)
