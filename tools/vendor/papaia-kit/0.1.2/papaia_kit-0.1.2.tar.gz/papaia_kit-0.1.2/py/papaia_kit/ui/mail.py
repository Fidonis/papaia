"""Notification mail of every module (interface spec 3.5 and 7; PLT-78 with Ä-32 and RE-48).

:func:`render_notification` checks one notification and renders the sender
name, the subject and both parts from ``dist/mail/notification.{html,txt}.j2``:

- sender name: the installation name, the same for every module (ASS-42-A6);
- subject: ``<Art>: <Titel>`` with the kinds ``Erinnerung``/``Reminder`` and
  ``Aufgabe``/``Task`` only;
- first line ``Aus <Modul>``, one link to the object, footer with the reason,
  the module and the link to the notifications in My area.

Sending is the core's mail outbound and not part of the kit. The input holds
no free text from integrations: only the title and up to three sentences the
module composes from its own fixed texts.
"""

from __future__ import annotations

import functools
import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import jinja2

from papaia_kit._resources import tokens_dir, ui_dist_dir
from papaia_kit.errors._patterns import has_hidden_characters
from papaia_kit.ui.edge import EdgePageError, https_url
from papaia_kit.ui.messages import LANGUAGES, load_texts, text
from papaia_kit.ui.tokens import load_tokens

__all__ = ["KINDS", "MailInputError", "Notification", "render_notification"]

KINDS = ("reminder", "task")
MAX_TITLE_CHARS = 120
MAX_NAME_CHARS = 60
MAX_BODY_LINES = 3
MAX_BODY_CHARS = 300
_REQUIRED = frozenset(
    {"lang", "kind", "title", "module", "installation", "object_url", "notifications_url"}
)
_OPTIONAL = frozenset({"body", "logo_src"})
_CID = re.compile(r"^cid:[A-Za-z0-9._@-]{1,64}$")


class MailInputError(ValueError):
    """A notification breaks the contract; the message names the field."""


@dataclass(frozen=True)
class Notification:
    sender_name: str
    subject: str
    text: str
    html: str


def _line(field: str, value: object, limit: int) -> str:
    """A single line of text: no line break (header injection), no hidden character."""
    if not isinstance(value, str) or not 0 < len(value) <= limit:
        raise MailInputError(f"{field}: must be a text of 1 to {limit} characters")
    if "\n" in value or "\r" in value or has_hidden_characters(value):
        raise MailInputError(f"{field}: holds a line break or a hidden character")
    return value


def _url(field: str, value: object) -> str:
    try:
        return https_url(field, value)
    except EdgePageError as exc:
        raise MailInputError(str(exc)) from None


def _logo_src(value: object) -> str | None:
    """``cid:`` of an attached logo or an https address; no ``data:`` addresses in mails."""
    if value is None:
        return None
    if isinstance(value, str) and _CID.match(value):
        return value
    if isinstance(value, str) and value.startswith("https:"):
        return _url("logo_src", value)
    raise MailInputError("logo_src: must be cid:<id> or an https address")


def _body(value: object) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or len(value) > MAX_BODY_LINES:
        raise MailInputError(f"body: must be a list of at most {MAX_BODY_LINES} sentences")
    return [_line("body", line, MAX_BODY_CHARS) for line in value]


@functools.cache
def _colors() -> Mapping[str, str]:
    """Literal token values for the style attributes (light theme; mail has no variables)."""
    tokens = load_tokens(tokens_dir() / "papaia.tokens.json")
    colors = tokens.themes["light"].colors

    def family(name: str) -> str:
        return ", ".join(
            f if f in {"sans-serif", "serif", "monospace"} else f"'{f}'"
            for f in tokens.families[name]
        )

    return {
        "page": colors["surface-page"].hex,
        "raised": colors["surface-raised"].hex,
        "border": colors["border"].hex,
        "text": colors["text"].hex,
        "muted": colors["text-muted"].hex,
        "link": colors["secondary"].hex,  # the link colour with text contrast in both themes
        "radius": tokens.shared["--pk-radius-box"],
        "font": family("--pk-font-body"),
        "brand_font": family("--pk-font-brand"),
    }


@functools.cache
def _environment(autoescape: bool) -> jinja2.Environment:
    return jinja2.Environment(
        loader=jinja2.FileSystemLoader(ui_dist_dir() / "mail"),
        # The plain text part is not HTML; every value in it is a checked single line.
        autoescape=autoescape,  # noqa: S701
        undefined=jinja2.StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )


def render_notification(data: Mapping[str, Any]) -> Notification:
    """Check one notification and render sender name, subject, text and HTML part."""
    if not isinstance(data, Mapping):
        raise MailInputError("input: expected a mapping")
    if unknown := set(data) - _REQUIRED - _OPTIONAL:
        raise MailInputError(f"input: unknown field {sorted(unknown)[0]}")
    if missing := _REQUIRED - set(data):
        raise MailInputError(f"{sorted(missing)[0]}: required")
    lang = data["lang"]
    if lang not in LANGUAGES:
        raise MailInputError(f"lang: expected one of {list(LANGUAGES)}")
    if data["kind"] not in KINDS:
        raise MailInputError(f"kind: expected one of {list(KINDS)}")
    title = _line("title", data["title"], MAX_TITLE_CHARS)
    module = _line("module", data["module"], MAX_NAME_CHARS)
    installation = _line("installation", data["installation"], MAX_NAME_CHARS)
    texts = load_texts("mail", lang)
    kind = texts[f"kind.{data['kind']}"]
    context = {
        "lang": lang,
        "m": texts,
        "c": _colors(),
        "subject": text("mail", lang, "subject", kind=kind, title=title),
        "title": title,
        "installation": installation,
        "from_module": text("mail", lang, "from_module", module=module),
        "reason": text("mail", lang, "reason", module=module),
        "body": _body(data.get("body")),
        "object_url": _url("object_url", data["object_url"]),
        "notifications_url": _url("notifications_url", data["notifications_url"]),
        "logo_src": _logo_src(data.get("logo_src")),
    }
    return Notification(
        sender_name=installation,
        subject=context["subject"],
        text=_environment(False).get_template("notification.txt.j2").render(context),
        html=_environment(True).get_template("notification.html.j2").render(context),
    )
