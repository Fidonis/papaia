"""``collect``: the one place that merges 'Meine Aufgaben' (PLT-81, RE-71).

Flow (relay), Data and Studio each serve ``GET /api/v1/me/tasks`` and
``GET /api/v1/me/tasks/summary`` in ``papaia.task-item/1``. ``collect`` reads
both routes of every source the catalog lists, with a token exchanged for the
person and for exactly that source's audience, merges the items, sorts them by
due date (items without one last) and adds the counts. It keeps nothing
between calls, so no answer of one person can reach another.

A source that is stopped, unreachable or answers outside the contract counts
as unavailable: its items and counts are left out and ``Collected.hints()``
carries the hint line for it. A source the catalog does not list is not part
of the installation and gets no hint.
"""

from __future__ import annotations

import datetime as dt
import http.client
import logging
from collections.abc import Callable, Mapping
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from functools import partial
from types import MappingProxyType
from typing import Any, Final, Protocol

from papaia_kit.catalog import Catalog, Entry, State
from papaia_kit.errors import ErrorClass, normalize_correlation_id
from papaia_kit.exchange import ExchangedToken, ExchangeError
from papaia_kit.tasks._items import (
    Summary,
    TaskContractError,
    check_summary,
    check_task_list,
    instant,
    parse_summary,
    parse_task_list,
)
from papaia_kit.tasks.transport import GetTransport, UrllibGetTransport

log = logging.getLogger("papaia_kit.tasks")

TASKS_PATH: Final = "/api/v1/me/tasks"
SUMMARY_PATH: Final = "/api/v1/me/tasks/summary"
MAX_TIMEOUT: Final = 60.0
_OK = 200
_HINTS: Final = {
    "de": "{m} ist gerade nicht erreichbar. Aufgaben aus {m} sind gerade nicht abrufbar.",
    "en": "{m} is not reachable right now. Tasks from {m} cannot be retrieved right now.",
}
# Refusals that concern the person's sign-in, not one source: the caller has
# to sign the person in again, a hint per source would hide that.
_PERSON_ERRORS: Final = frozenset(
    {ErrorClass.UNAUTHENTICATED, ErrorClass.IDENTITY_REVOKED, ErrorClass.INVALID_INPUT}
)


@dataclass(frozen=True, slots=True)
class TaskSource:
    """A module that serves the task routes: item ``source``, display name, audience."""

    name: str
    label: str
    audience: str


SOURCES: Final = (
    TaskSource("flow", "Flow", "flow"),
    TaskSource("data", "Data", "papaia-data"),
    TaskSource("studio", "Studio", "papaia-studio"),
)


class Exchanger(Protocol):
    """What ``collect`` needs of ``papaia_kit.exchange.ExchangeClient``."""

    def exchange(
        self, subject_token: str, audience: str, *, correlation_id: str | None = None
    ) -> ExchangedToken: ...


@dataclass(frozen=True, slots=True)
class LocalSource:
    """The calling module's own tasks, read in process instead of over HTTP.

    ``tasks`` returns the body of its own ``GET /api/v1/me/tasks`` and
    ``summary`` the body of ``/summary``, both as decoded JSON, for the person
    the caller has already checked. They are checked like a remote answer.
    """

    name: str
    tasks: Callable[[], object]
    summary: Callable[[], object]


def hint_line(label: str, lang: str = "de") -> str:
    """The hint line for an unavailable source (oberflaeche 2.6)."""
    return _HINTS[lang].format(m=label)


@dataclass(frozen=True)
class Collected:
    """The one list 'Meine Aufgaben' of a person and its count.

    ``tasks`` are the items read-only, sorted by due date; ``count`` and
    ``overdue`` add up the summaries of the sources that answered;
    ``unavailable`` lists the sources that did not, in source order;
    ``revisions`` holds the summary revision per source that answered.
    """

    tasks: tuple[Mapping[str, Any], ...]
    count: int
    overdue: int
    unavailable: tuple[TaskSource, ...]
    revisions: Mapping[str, str]

    def hints(self, lang: str = "de") -> tuple[str, ...]:
        if lang not in _HINTS:
            raise ValueError("lang must be 'de' or 'en'")
        return tuple(hint_line(source.label, lang) for source in self.unavailable)


@dataclass(frozen=True, slots=True)
class _Answer:
    tasks: tuple[Mapping[str, Any], ...]
    summary: Summary


class _Unavailable(Exception):  # noqa: N818 - internal signal, becomes a hint
    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


def collect(
    subject_token: str,
    *,
    catalog: Catalog,
    exchange: Exchanger,
    http: GetTransport | None = None,
    local: LocalSource | None = None,
    sources: tuple[TaskSource, ...] = SOURCES,
    correlation_id: str | None = None,
    timeout: float = 5.0,
) -> Collected:
    """Read, merge, sort and count the tasks of the person behind ``subject_token``.

    ``subject_token`` is the person's token the caller has verified
    (``papaia_kit.authz``) or obtained from its own sign-in; it is exchanged
    per source and never sent to a source as it is. ``local`` replaces the
    remote call for the caller's own module. A refusal that concerns the
    person (session ended, token expired or malformed) raises
    :class:`~papaia_kit.exchange.ExchangeError`.
    """
    _check_arguments(subject_token, catalog, local, sources, timeout)
    cid = normalize_correlation_id(correlation_id)
    remote = _Remote(
        subject_token=subject_token,
        exchange=exchange,
        transport=http if http is not None else UrllibGetTransport(),
        cid=cid,
        timeout=float(timeout),
    )

    work: list[tuple[TaskSource, Callable[[], _Answer]]] = []
    unavailable: set[str] = set()
    for source in sources:
        if local is not None and source.name == local.name:
            work.append((source, partial(_read_local, local)))
            continue
        entry = _entry(catalog, source.audience)
        if entry is None:
            continue  # not installed: no hint (STU-22-A5)
        if entry.state is State.STOPPED:
            log.info(
                "task source unavailable: source=%s reason=stopped correlation_id=%s",
                source.name,
                cid,
            )
            unavailable.add(source.name)
            continue
        address = str(entry.data["address"]).rstrip("/")
        work.append((source, partial(remote.read, source, address)))

    answers: dict[str, _Answer] = {}
    if work:
        with ThreadPoolExecutor(max_workers=len(work), thread_name_prefix="pk-tasks") as pool:
            futures = [(source, pool.submit(read)) for source, read in work]
            for source, future in futures:
                try:
                    answers[source.name] = future.result()
                except _Unavailable as missing:
                    log.info(
                        "task source unavailable: source=%s reason=%s correlation_id=%s",
                        source.name,
                        missing.reason,
                        cid,
                    )
                    unavailable.add(source.name)

    tasks = sorted(
        (item for answer in answers.values() for item in answer.tasks),
        key=_order_key({s.name: i for i, s in enumerate(sources)}),
    )
    return Collected(
        tasks=tuple(tasks),
        count=sum(a.summary.open for a in answers.values()),
        overdue=sum(a.summary.overdue for a in answers.values()),
        unavailable=tuple(s for s in sources if s.name in unavailable),
        revisions=MappingProxyType(
            {s.name: answers[s.name].summary.revision for s in sources if s.name in answers}
        ),
    )


def _entry(catalog: Catalog, audience: str) -> Entry | None:
    """The catalog entry that serves ``audience`` over HTTP, if the installation has one."""
    for entry in catalog.entries.values():
        if entry.data.get("audience") == audience and "address" in entry.data:
            return entry
    return None


def _read_local(local: LocalSource) -> _Answer:
    try:
        return _Answer(
            tasks=check_task_list(local.tasks(), source=local.name),
            summary=check_summary(local.summary()),
        )
    except TaskContractError:
        raise _Unavailable("contract_mismatch") from None
    except Exception as error:  # noqa: BLE001 - any failure of the own source is an outage
        raise _Unavailable(f"local_error:{type(error).__name__}") from None


@dataclass(frozen=True, slots=True)
class _Remote:
    """One person's reads from remote sources; holds the token, never logs it."""

    subject_token: str = field(repr=False)
    exchange: Exchanger
    transport: GetTransport
    cid: str
    timeout: float

    def read(self, source: TaskSource, address: str) -> _Answer:
        try:
            token = self.exchange.exchange(
                self.subject_token, source.audience, correlation_id=self.cid
            )
        except ExchangeError as error:
            if error.error_class in _PERSON_ERRORS:
                raise
            raise _Unavailable(f"exchange_{error.reason}") from None
        headers = token.headers()
        try:
            tasks = parse_task_list(self._get(address + TASKS_PATH, headers), source=source.name)
            summary = parse_summary(self._get(address + SUMMARY_PATH, headers))
        except TaskContractError:
            raise _Unavailable("contract_mismatch") from None
        return _Answer(tasks=tasks, summary=summary)

    def _get(self, url: str, headers: Mapping[str, str]) -> bytes:
        try:
            status, body = self.transport.get(url, headers, self.timeout)
        except (OSError, ValueError, http.client.HTTPException):
            raise _Unavailable("unreachable") from None
        if status != _OK:
            raise _Unavailable(f"status_{int(status)}")
        return body


def _check_arguments(
    subject_token: object,
    catalog: object,
    local: object,
    sources: object,
    timeout: object,
) -> None:
    if not isinstance(subject_token, str):
        raise TypeError("subject_token must be a string")
    if not isinstance(catalog, Catalog):
        raise TypeError("catalog must be a papaia_kit.catalog.Catalog")
    if isinstance(timeout, bool) or not isinstance(timeout, int | float):
        raise TypeError("timeout must be a number")
    if not 0 < timeout <= MAX_TIMEOUT:
        raise ValueError(f"timeout must be within (0, {MAX_TIMEOUT}] seconds")
    if not isinstance(sources, tuple) or not all(isinstance(s, TaskSource) for s in sources):
        raise TypeError("sources must be a tuple of TaskSource")
    if local is not None:
        if not isinstance(local, LocalSource):
            raise TypeError("local must be a LocalSource")
        if local.name not in {s.name for s in sources}:
            raise ValueError("local must name one of the sources")


def _instant(value: object) -> dt.datetime | None:
    # Items reach the sort only after check_task_list, which refused any
    # timestamp ``instant`` cannot read.
    return instant(value) if isinstance(value, str) else None


_LAST = dt.datetime.max.replace(tzinfo=dt.UTC)
_FIRST = dt.datetime.min.replace(tzinfo=dt.UTC)


def _order_key(rank: Mapping[str, int]) -> Callable[[Mapping[str, Any]], tuple[Any, ...]]:
    """Due date ascending, items without one last; then newest first; then source and id."""

    def key(item: Mapping[str, Any]) -> tuple[Any, ...]:
        due = _instant(item.get("due_at"))
        created = _instant(item.get("created_at"))
        return (
            due is None,
            due or _LAST,
            created is None,
            # Newest first: compare the negated distance from the earliest instant.
            -((created or _FIRST) - _FIRST).total_seconds(),
            rank.get(item["source"], len(rank)),
            item["id"],
        )

    return key
