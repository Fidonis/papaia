"""Naming register for clients, audiences, scopes and service accounts.

The register is binding (architecture V-12): every audience, scope, client,
role, service account, core service and core network of the reference stack is
listed with the repository that owns it, and every new name follows the rule of
its kind:

- audience and resource server: ``mcp-<system>`` or ``papaia-<module>[-<surface>]``
- exchange scope: ``aud-<audience>``, built only by ``exchange_scope``
- client: ``papaia-<module>[-<surface>]`` (resource servers ``mcp-<system>``)
- role: ``<module>-<role>`` with a known module, platform roles ``papaia-<role>``
- service account: ``svc-<module>-<purpose>``
- person identifier: ``sub``; ``person_id = sub`` for persons, absent for
  service accounts

Existing names (``flow``, ``assist-api``, ``flow-engine`` and others) stay valid
because they are registered. Removed names are rejected with their successor;
``transitional`` names the ones the realm may still carry during a transition.
Keycloak built-in objects are listed in ``BUILTIN`` and not managed.
"""

from papaia_kit.names._data import BUILTIN, OWNERS, REMOVED, ROLE_MODULES
from papaia_kit.names._model import Entry, InvalidName, Kind, Removed
from papaia_kit.names.person import InvalidClaims, person_id
from papaia_kit.names.register import REGISTER, entries, lookup
from papaia_kit.names.rules import (
    MAX_AUDIENCE_LENGTH,
    MAX_NAME_LENGTH,
    builtin,
    exchange_scope,
    has_exchange_prefix,
    is_valid,
    successor,
    transitional,
    validate,
)

__all__ = [
    "BUILTIN",
    "MAX_AUDIENCE_LENGTH",
    "MAX_NAME_LENGTH",
    "OWNERS",
    "REGISTER",
    "REMOVED",
    "ROLE_MODULES",
    "Entry",
    "InvalidClaims",
    "InvalidName",
    "Kind",
    "Removed",
    "builtin",
    "entries",
    "exchange_scope",
    "has_exchange_prefix",
    "is_valid",
    "lookup",
    "person_id",
    "successor",
    "transitional",
    "validate",
]
