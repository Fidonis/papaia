"""Syntax check of ECMA-262 regular expressions in Unicode mode.

JSON Schema 2020-12 defines ``pattern`` and the keys of ``patternProperties``
as ECMA-262 regular expressions. Python's ``re`` accepts a different dialect,
so the manifest suite checks the syntax itself, against the grammar of
ECMAScript 2024 (section 22.2.1) with the ``u`` flag. The ``u`` grammar is the
strict one: a pattern it accepts also compiles without the flag, and
validators such as Ajv compile patterns with it.

Values of ``\\p{Script=...}`` and ``\\p{Script_Extensions=...}`` are checked by
form only (the list of scripts grows with every Unicode version); property
names and General_Category values are checked against the full lists.
"""

from __future__ import annotations

import re

_SYNTAX_CHARACTERS = frozenset("^$\\.*+?()[]{}|")
_CONTROL_ESCAPES = {"f": 0x0C, "n": 0x0A, "r": 0x0D, "t": 0x09, "v": 0x0B}
_BRACE_QUANTIFIER = re.compile(r"\{([0-9]+)(?:(,)([0-9]*))?\}")
_HEX = frozenset("0123456789abcdefABCDEF")
_MAX_DEPTH = 100
_MAX_CODE_POINT = 0x10FFFF
_LEAD_SURROGATE_FIRST, _LEAD_SURROGATE_LAST = 0xD800, 0xDBFF
_TRAIL_SURROGATE_FIRST = 0xDC00
_TRAIL_ESCAPE = re.compile(r"\\u([dD][c-fC-F][0-9a-fA-F]{2})")

_GENERAL_CATEGORY = frozenset(
    [
        "C",
        "Other",
        "Cc",
        "Control",
        "cntrl",
        "Cf",
        "Format",
        "Cn",
        "Unassigned",
        "Co",
        "Private_Use",
        "Cs",
        "Surrogate",
        "L",
        "Letter",
        "LC",
        "Cased_Letter",
        "Ll",
        "Lowercase_Letter",
        "Lm",
        "Modifier_Letter",
        "Lo",
        "Other_Letter",
        "Lt",
        "Titlecase_Letter",
        "Lu",
        "Uppercase_Letter",
        "M",
        "Mark",
        "Combining_Mark",
        "Mc",
        "Spacing_Mark",
        "Me",
        "Enclosing_Mark",
        "Mn",
        "Nonspacing_Mark",
        "N",
        "Number",
        "Nd",
        "Decimal_Number",
        "digit",
        "Nl",
        "Letter_Number",
        "No",
        "Other_Number",
        "P",
        "Punctuation",
        "punct",
        "Pc",
        "Connector_Punctuation",
        "Pd",
        "Dash_Punctuation",
        "Pe",
        "Close_Punctuation",
        "Pf",
        "Final_Punctuation",
        "Pi",
        "Initial_Punctuation",
        "Po",
        "Other_Punctuation",
        "Ps",
        "Open_Punctuation",
        "S",
        "Symbol",
        "Sc",
        "Currency_Symbol",
        "Sk",
        "Modifier_Symbol",
        "Sm",
        "Math_Symbol",
        "So",
        "Other_Symbol",
        "Z",
        "Separator",
        "Zl",
        "Line_Separator",
        "Zp",
        "Paragraph_Separator",
        "Zs",
        "Space_Separator",
    ]
)

_BINARY_PROPERTIES = frozenset(
    [
        "ASCII",
        "ASCII_Hex_Digit",
        "AHex",
        "Alphabetic",
        "Alpha",
        "Any",
        "Assigned",
        "Bidi_Control",
        "Bidi_C",
        "Bidi_Mirrored",
        "Bidi_M",
        "Case_Ignorable",
        "CI",
        "Cased",
        "Changes_When_Casefolded",
        "CWCF",
        "Changes_When_Casemapped",
        "CWCM",
        "Changes_When_Lowercased",
        "CWL",
        "Changes_When_NFKC_Casefolded",
        "CWKCF",
        "Changes_When_Titlecased",
        "CWT",
        "Changes_When_Uppercased",
        "CWU",
        "Dash",
        "Default_Ignorable_Code_Point",
        "DI",
        "Deprecated",
        "Dep",
        "Diacritic",
        "Dia",
        "Emoji",
        "Emoji_Component",
        "EComp",
        "Emoji_Modifier",
        "EMod",
        "Emoji_Modifier_Base",
        "EBase",
        "Emoji_Presentation",
        "EPres",
        "Extended_Pictographic",
        "ExtPict",
        "Extender",
        "Ext",
        "Grapheme_Base",
        "Gr_Base",
        "Grapheme_Extend",
        "Gr_Ext",
        "Hex_Digit",
        "Hex",
        "IDS_Binary_Operator",
        "IDSB",
        "IDS_Trinary_Operator",
        "IDST",
        "ID_Continue",
        "IDC",
        "ID_Start",
        "IDS",
        "Ideographic",
        "Ideo",
        "Join_Control",
        "Join_C",
        "Logical_Order_Exception",
        "LOE",
        "Lowercase",
        "Lower",
        "Math",
        "Noncharacter_Code_Point",
        "NChar",
        "Pattern_Syntax",
        "Pat_Syn",
        "Pattern_White_Space",
        "Pat_WS",
        "Quotation_Mark",
        "QMark",
        "Radical",
        "Regional_Indicator",
        "RI",
        "Sentence_Terminal",
        "STerm",
        "Soft_Dotted",
        "SD",
        "Terminal_Punctuation",
        "Term",
        "Unified_Ideograph",
        "UIdeo",
        "Uppercase",
        "Upper",
        "Variation_Selector",
        "VS",
        "White_Space",
        "space",
        "XID_Continue",
        "XIDC",
        "XID_Start",
        "XIDS",
    ]
)

_GENERAL_CATEGORY_NAMES = frozenset({"General_Category", "gc"})
_SCRIPT_NAMES = frozenset({"Script", "sc", "Script_Extensions", "scx"})
_SCRIPT_VALUE = re.compile(r"[A-Za-z]+(?:_[A-Za-z]+)*")
_PROPERTY_BODY = re.compile(r"\{([A-Za-z0-9_]+)(?:=([A-Za-z0-9_]*))?\}")


class _PatternError(Exception):
    def __init__(self, reason: str, position: int) -> None:
        super().__init__(reason)
        self.reason = reason
        self.position = position


def ecma_pattern_error(pattern: str) -> str | None:
    """None if ``pattern`` compiles as an ECMA-262 regular expression (``u`` flag), else why not."""
    if not isinstance(pattern, str):
        raise TypeError(f"pattern must be a string, not {type(pattern).__name__}")
    try:
        _Parser(pattern).parse()
    except _PatternError as exc:
        return f"{exc.reason} at position {exc.position}"
    except RecursionError:  # pragma: no cover - the depth limit stops nesting first
        return "groups nested too deep"
    return None


class _Parser:
    def __init__(self, source: str) -> None:
        self.source = source
        self.pos = 0
        self.depth = 0
        self.groups = 0
        self.names: set[str] = set()
        self.backreferences: list[tuple[int, int]] = []
        self.named_references: list[tuple[str, int]] = []

    # --- helpers --------------------------------------------------------------

    def peek(self, ahead: int = 0) -> str | None:
        index = self.pos + ahead
        return self.source[index] if index < len(self.source) else None

    def startswith(self, text: str) -> bool:
        return self.source.startswith(text, self.pos)

    def fail(self, reason: str, position: int | None = None) -> _PatternError:
        return _PatternError(reason, self.pos if position is None else position)

    # --- grammar --------------------------------------------------------------

    def parse(self) -> None:
        self.disjunction()
        if self.pos < len(self.source):
            raise self.fail("unmatched ')'")
        for number, position in self.backreferences:
            if number > self.groups:
                raise self.fail(f"back reference \\{number} without group {number}", position)
        for name, position in self.named_references:
            if name not in self.names:
                raise self.fail(f"unknown group name {name!r}", position)

    def disjunction(self) -> None:
        self.depth += 1
        if self.depth > _MAX_DEPTH:
            raise self.fail("groups nested too deep")
        self.alternative()
        while self.peek() == "|":
            self.pos += 1
            self.alternative()
        self.depth -= 1

    def alternative(self) -> None:
        while self.peek() not in (None, "|", ")"):
            self.term()

    def close_group(self) -> None:
        if self.peek() != ")":
            raise self.fail("missing ')'")
        self.pos += 1

    def term(self) -> None:
        char = self.peek()
        if char in ("^", "$"):
            self.pos += 1
            self.no_quantifier()
            return
        if char == "\\" and self.peek(1) in ("b", "B"):
            self.pos += 2
            self.no_quantifier()
            return
        for opener in ("(?=", "(?!", "(?<=", "(?<!"):
            if self.startswith(opener):
                self.pos += len(opener)
                self.disjunction()
                self.close_group()
                self.no_quantifier()
                return
        self.atom()
        self.quantifier()

    def at_quantifier(self) -> bool:
        char = self.peek()
        if char in ("*", "+", "?"):
            return True
        return char == "{" and _BRACE_QUANTIFIER.match(self.source, self.pos) is not None

    def no_quantifier(self) -> None:
        if self.at_quantifier():
            raise self.fail("nothing to repeat")

    def quantifier(self) -> None:
        char = self.peek()
        if char in ("*", "+", "?"):
            self.pos += 1
        elif char == "{":
            match = _BRACE_QUANTIFIER.match(self.source, self.pos)
            if match is None:
                raise self.fail("lone '{'")
            low, comma, high = match.groups()
            if comma and high and int(high) < int(low):
                raise self.fail("numbers out of order in {} quantifier")
            self.pos = match.end()
        else:
            return
        if self.peek() == "?":
            self.pos += 1
        self.no_quantifier()

    def atom(self) -> None:
        char = self.peek()
        if char == ".":
            self.pos += 1
        elif char == "(":
            self.group()
        elif char == "[":
            self.character_class()
        elif char == "\\":
            self.pos += 1
            self.atom_escape()
        elif char in ("*", "+", "?"):
            raise self.fail("nothing to repeat")
        elif char == "{":
            raise self.fail("nothing to repeat" if self.at_quantifier() else "lone '{'")
        elif char in ("]", "}"):
            raise self.fail(f"lone {char!r}")
        else:
            self.pos += 1

    def group(self) -> None:
        start = self.pos
        if self.startswith("(?:"):
            self.pos += 3
        elif self.startswith("(?<"):
            self.pos += 3
            name = self.group_name()
            if name in self.names:
                raise self.fail(f"duplicate group name {name!r}", start)
            self.names.add(name)
            self.groups += 1
        elif self.startswith("(?"):
            raise self.fail("invalid group")
        else:
            self.pos += 1
            self.groups += 1
        self.disjunction()
        self.close_group()

    def group_name(self) -> str:
        """``RegExpIdentifierName`` up to the closing ``>``, with ``\\u`` escapes resolved."""
        start = self.pos
        name: list[str] = []
        while self.peek() not in (None, ">"):
            if self.peek() == "\\":
                if self.peek(1) != "u":
                    raise self.fail("invalid group name", start)
                self.pos += 1
                char = chr(self.unicode_escape())
            else:
                char = self.source[self.pos]
                self.pos += 1
            valid = _identifier_start(char) if not name else _identifier_part(char)
            if not valid:
                raise self.fail("invalid group name", start)
            name.append(char)
        if self.peek() != ">" or not name:
            raise self.fail("invalid group name", start)
        self.pos += 1
        return "".join(name)

    def atom_escape(self) -> None:
        char = self.peek()
        if char is None:
            raise self.fail("\\ at end of pattern")
        if char in "123456789":
            start = self.pos - 1
            end = self.pos
            while (
                end < len(self.source) and self.source[end].isascii() and self.source[end].isdigit()
            ):
                end += 1
            self.backreferences.append((int(self.source[self.pos : end]), start))
            self.pos = end
        elif char == "k":
            start = self.pos - 1
            self.pos += 1
            if self.peek() != "<":
                raise self.fail("invalid group name", start)
            self.pos += 1
            self.named_references.append((self.group_name(), start))
        else:
            self.character_escape(in_class=False)

    def character_escape(self, *, in_class: bool) -> int | None:  # noqa: PLR0911
        """The code point of a character escape, or None for a class escape (``\\d``, ``\\p``)."""
        char = self.peek()
        start = self.pos - 1
        if char is None:
            raise self.fail("\\ at end of pattern")
        if char in "dDsSwW":
            self.pos += 1
            return None
        if char in "pP":
            self.pos += 1
            self.property_escape(start)
            return None
        if char in _CONTROL_ESCAPES:
            self.pos += 1
            return _CONTROL_ESCAPES[char]
        if char == "c":
            letter = self.peek(1)
            if letter is None or not ("a" <= letter <= "z" or "A" <= letter <= "Z"):
                raise self.fail("invalid \\c escape", start)
            self.pos += 2
            return ord(letter) % 32
        if char == "0":
            following = self.peek(1)
            if following is not None and following.isdigit():
                raise self.fail("invalid escape '\\0' before a digit", start)
            self.pos += 1
            return 0
        if char == "x":
            self.pos += 1
            return self.hex_digits(2, "invalid \\x escape", start)
        if char == "u":
            return self.unicode_escape()
        if char in _SYNTAX_CHARACTERS or char == "/":
            self.pos += 1
            return ord(char)
        if in_class and char in ("-", "b"):
            self.pos += 1
            return ord("-") if char == "-" else 0x08
        raise self.fail(f"invalid escape {chr(92) + char!r}", start)

    def hex_digits(self, count: int, reason: str, start: int) -> int:
        text = self.source[self.pos : self.pos + count]
        if len(text) != count or not set(text) <= _HEX:
            raise self.fail(reason, start)
        self.pos += count
        return int(text, 16)

    def unicode_escape(self) -> int:
        """At the ``u`` of ``\\u``: ``\\uHHHH`` (with surrogate pairs) or ``\\u{H...}``."""
        start = self.pos - 1
        self.pos += 1
        if self.peek() == "{":
            end = self.source.find("}", self.pos)
            digits = self.source[self.pos + 1 : end] if end != -1 else ""
            if not digits or not set(digits) <= _HEX or int(digits, 16) > _MAX_CODE_POINT:
                raise self.fail("invalid \\u escape", start)
            self.pos = end + 1
            return int(digits, 16)
        value = self.hex_digits(4, "invalid \\u escape", start)
        trail = _TRAIL_ESCAPE.match(self.source, self.pos)
        if _LEAD_SURROGATE_FIRST <= value <= _LEAD_SURROGATE_LAST and trail is not None:
            self.pos = trail.end()
            high = (value - _LEAD_SURROGATE_FIRST) << 10
            return 0x10000 + high + (int(trail.group(1), 16) - _TRAIL_SURROGATE_FIRST)
        return value

    def property_escape(self, start: int) -> None:
        match = _PROPERTY_BODY.match(self.source, self.pos)
        if match is None:
            raise self.fail("invalid property escape", start)
        name, value = match.groups()
        self.pos = match.end()
        if value is None:
            known = name in _GENERAL_CATEGORY or name in _BINARY_PROPERTIES
        elif name in _GENERAL_CATEGORY_NAMES:
            known = value in _GENERAL_CATEGORY
        elif name in _SCRIPT_NAMES:
            known = _SCRIPT_VALUE.fullmatch(value) is not None
        else:
            known = False
        if not known:
            raise self.fail(f"unknown Unicode property {match.group()[1:-1]!r}", start)

    def character_class(self) -> None:
        start = self.pos
        self.pos += 1
        if self.peek() == "^":
            self.pos += 1
        while True:
            char = self.peek()
            if char is None:
                raise self.fail("missing ']'", start)
            if char == "]":
                self.pos += 1
                return
            low = self.class_atom()
            if self.peek() == "-" and self.peek(1) not in (None, "]"):
                range_start = self.pos
                self.pos += 1
                high = self.class_atom()
                if low is None or high is None:
                    raise self.fail("invalid character class range", range_start)
                if low > high:
                    raise self.fail("range out of order in character class", range_start)

    def class_atom(self) -> int | None:
        char = self.source[self.pos]
        self.pos += 1
        if char != "\\":
            return ord(char)
        return self.character_escape(in_class=True)


def _identifier_start(char: str) -> bool:
    return char in ("$", "_") or char.isidentifier()


def _identifier_part(char: str) -> bool:
    return char in ("$", "‌", "‍") or f"a{char}".isidentifier()
