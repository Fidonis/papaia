"""HTTP transport for the two task routes.

The default transport is the one of the token exchange (standard library, no
redirect, no proxy variables of the environment, bounded body) with a GET and
a larger bound for task lists. Every failure below the HTTP status code is an
``OSError``.
"""

from __future__ import annotations

import http.client
import urllib.request
from collections.abc import Mapping
from typing import Protocol
from urllib.parse import urlsplit

from papaia_kit.exchange.transport import UrllibTransport
from papaia_kit.tasks._items import MAX_BODY


class GetTransport(Protocol):
    """Sends one GET and returns status code and body."""

    def get(self, url: str, headers: Mapping[str, str], timeout: float) -> tuple[int, bytes]: ...


class UrllibGetTransport(UrllibTransport):
    """Standard library transport for task routes; other errors than a status are ``OSError``."""

    MAX_RESPONSE = MAX_BODY

    def get(self, url: str, headers: Mapping[str, str], timeout: float) -> tuple[int, bytes]:
        if urlsplit(url).scheme not in ("http", "https"):
            raise OSError("task route must use http or https")
        request = urllib.request.Request(  # noqa: S310 - scheme checked above
            url, headers={**headers, "Accept": "application/json"}, method="GET"
        )
        try:
            return self._send(request, timeout)
        except http.client.HTTPException as error:
            raise OSError(f"malformed response: {type(error).__name__}") from None
