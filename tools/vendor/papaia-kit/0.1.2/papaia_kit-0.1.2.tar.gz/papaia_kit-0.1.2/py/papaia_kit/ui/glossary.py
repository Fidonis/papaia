"""The binding glossary (``glossary/glossary.yaml``) and its patterns.

``load_glossary`` checks the file against ``glossary.schema.json``, compiles
every pattern with the standard library module ``re`` on ``str`` (Unicode
``\\w``) and stops at the first problem with the line of the file. A pattern
is translated at load according to the ``compound`` mode of its entry, and a
glossary whose own terms match one of its replaced patterns is rejected.
"""

from __future__ import annotations

import functools
import json
import re
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import jsonschema
import yaml

from papaia_kit._resources import glossary_dir

LANGUAGES = ("de", "en")
MANDATORY_MODULE_TITLE = "module_title"
NOT_PRESENT = "nicht vorhanden"
MAX_FILE_BYTES = 2 * 1024 * 1024

Compound = Literal["head", "any"]
_LEADS = ("(?<!\\w)", "(?<![\\w-])")
_TRAILS = ("(?!\\w)", "(?![\\w-])")

Path_ = tuple[str | int, ...]


class GlossaryError(ValueError):
    """The glossary file is malformed; the message starts with ``<file>:<line>:``."""


@dataclass(frozen=True)
class Replacement:
    """One replaced word: the pattern as written and as compiled for its compound mode."""

    source: str
    regex: re.Pattern[str]
    line: int


@dataclass(frozen=True)
class LangPart:
    term: str
    plural: str | None
    variants: tuple[str, ...]
    definition: str
    replaces: tuple[Replacement, ...]
    allow_in_sentence: tuple[re.Pattern[str], ...]
    compound: Compound
    restricted_words: tuple[str, ...]

    @property
    def forms(self) -> tuple[str, ...]:
        """Every spelling of the term: term, plural, variants."""
        plural = () if self.plural is None else (self.plural,)
        return (self.term, *plural, *self.variants)


@dataclass(frozen=True)
class Entry:
    id: str
    nr: int
    restricted: bool
    scope: frozenset[str]
    de: LangPart
    en: LangPart
    note: str | None = None

    def lang(self, lang: str) -> LangPart:
        if lang == "de":
            return self.de
        if lang == "en":
            return self.en
        raise ValueError(f"unknown language {lang!r}")


@dataclass(frozen=True)
class Fixed:
    address: str
    address_forbidden_de: re.Pattern[str]
    modules: Mapping[str, Mapping[str, str]]
    role_formats: Mapping[str, str]
    role_levels: Mapping[str, Mapping[str, str]]
    mandatory: tuple[str, ...]


# Compared by identity: a loaded glossary is a cache key of the compiled patterns.
@dataclass(frozen=True, eq=False)
class Glossary:
    entries: tuple[Entry, ...]
    fixed: Fixed
    by_id: Mapping[str, Entry] = field(repr=False)

    def ids(self) -> frozenset[str]:
        """Every id a module may map: glossary ids plus the module title."""
        return frozenset(self.by_id) | {MANDATORY_MODULE_TITLE}


def default_path() -> Path:
    return glossary_dir() / "glossary.yaml"


def _schema() -> dict[str, Any]:
    with (glossary_dir() / "glossary.schema.json").open(encoding="utf-8") as handle:
        schema: dict[str, Any] = json.load(handle)
    return schema


def _line_map(text: str) -> dict[Path_, int]:
    """1-based line of every node of the YAML document, keyed by its path."""
    lines: dict[Path_, int] = {}

    def walk(node: yaml.Node, path: Path_) -> None:
        lines[path] = node.start_mark.line + 1
        if isinstance(node, yaml.MappingNode):
            for key, value in node.value:
                walk(value, (*path, str(key.value)))
        elif isinstance(node, yaml.SequenceNode):
            for index, item in enumerate(node.value):
                walk(item, (*path, index))

    root = yaml.compose(text, Loader=yaml.SafeLoader)
    if root is not None:
        walk(root, ())
    return lines


class _Context:
    def __init__(self, path: Path, lines: Mapping[Path_, int]) -> None:
        self.path = path
        self.lines = lines

    def line(self, where: Sequence[str | int]) -> int:
        key = tuple(where)
        while key and key not in self.lines:
            key = key[:-1]
        return self.lines.get(key, 1)

    def error(self, where: Sequence[str | int], message: str) -> GlossaryError:
        dotted = ".".join(str(part) for part in where) or "document"
        return GlossaryError(f"{self.path}:{self.line(where)}: {dotted}: {message}")


def _schema_message(error: jsonschema.ValidationError) -> str:
    boundary = _schema()["$defs"]["replacePattern"]["pattern"]
    if error.validator == "pattern" and error.validator_value == boundary:
        return (
            f"{error.instance!r} needs the word boundary: start with (?<!\\w) and end with "
            "(?!\\w), or the forms with [\\w-]"
        )
    if error.validator == "not":
        return (
            f"{error.instance!r} uses \\b or \\p{{...}}; write the boundary as (?<!\\w)...(?!\\w)"
        )
    return error.message


def _check_schema(ctx: _Context, data: object) -> None:
    validator = jsonschema.Draft202012Validator(_schema())
    errors = sorted(validator.iter_errors(data), key=lambda e: list(map(str, e.absolute_path)))
    if errors:
        first = errors[0]
        raise ctx.error(list(first.absolute_path), _schema_message(first))


def _strip(source: str, compound: Compound) -> str:
    out = source
    lead = next(prefix for prefix in _LEADS if out.startswith(prefix))
    out = out[len(lead) :]
    if compound == "any":
        trail = next(suffix for suffix in _TRAILS if out.endswith(suffix))
        out = out[: -len(trail)]
    return out


def _has_boundaries(source: str) -> bool:
    return source.startswith(_LEADS) and source.endswith(_TRAILS)


def _compile(ctx: _Context, where: Path_, source: str) -> re.Pattern[str]:
    try:
        return re.compile(source, re.IGNORECASE)
    except re.error as exc:
        raise ctx.error(where, f"pattern {source!r} does not compile: {exc}") from exc


def _lang_part(ctx: _Context, where: Path_, raw: Mapping[str, Any]) -> LangPart:
    compound: Compound = raw.get("compound", "head")
    replaces = []
    for index, source in enumerate(raw["replaces"]):
        at = (*where, "replaces", index)
        _compile(ctx, at, source)  # the pattern as written must compile, too
        replaces.append(
            Replacement(source, _compile(ctx, at, _strip(source, compound)), ctx.line(at))
        )
    allowed = []
    for index, source in enumerate(raw.get("allow_in_sentence", ())):
        at = (*where, "allow_in_sentence", index)
        _compile(ctx, at, source)
        translated = _strip(source, compound) if _has_boundaries(source) else source
        allowed.append(_compile(ctx, at, translated))
    term, plural = raw["term"], raw.get("plural")
    variants = tuple(raw.get("variants", ()))
    forms = (term, *(() if plural is None else (plural,)), *variants)
    if len(set(forms)) != len(forms):
        raise ctx.error(where, "term, plural and variants must differ")
    return LangPart(
        term=term,
        plural=plural,
        variants=variants,
        definition=raw["definition"],
        replaces=tuple(replaces),
        allow_in_sentence=tuple(allowed),
        compound=compound,
        restricted_words=tuple(raw.get("restricted_words", forms)),
    )


def _named(
    ctx: _Context, where: Path_, items: Sequence[Mapping[str, str]]
) -> dict[str, dict[str, str]]:
    out: dict[str, dict[str, str]] = {}
    for index, item in enumerate(items):
        if item["id"] in out:
            raise ctx.error((*where, index, "id"), f"duplicate id {item['id']!r}")
        out[item["id"]] = {"de": item["de"], "en": item["en"]}
    return out


def _fixed(ctx: _Context, raw: Mapping[str, Any], ids: frozenset[str]) -> Fixed:
    address = raw["address"]
    at: Path_ = ("fixed", "address", "forbidden_de")
    forbidden = _compile(ctx, at, address["forbidden_de"])
    roles = raw["roles"]
    for index, mandatory in enumerate(raw["mandatory"]):
        if mandatory != MANDATORY_MODULE_TITLE and mandatory not in ids:
            raise ctx.error(("fixed", "mandatory", index), f"unknown glossary id {mandatory!r}")
    return Fixed(
        address=address["de"],
        address_forbidden_de=forbidden,
        modules=_named(ctx, ("fixed", "modules"), raw["modules"]),
        role_formats={"de": roles["format_de"], "en": roles["format_en"]},
        role_levels=_named(ctx, ("fixed", "roles", "levels"), roles["levels"]),
        mandatory=tuple(raw["mandatory"]),
    )


def _check_consistency(ctx: _Context, entries: Sequence[Entry]) -> None:
    """No term of the glossary may be reported by one of its own replaced patterns."""
    for lang in LANGUAGES:
        forms = [(entry, form) for entry in entries for form in entry.lang(lang).forms]
        for index, entry in enumerate(entries):
            for number, replaced in enumerate(entry.lang(lang).replaces):
                for owner, form in forms:
                    if replaced.regex.search(form):
                        raise ctx.error(
                            ("entries", index, lang, "replaces", number),
                            f"pattern {replaced.source!r} matches the term {form!r} of "
                            f"entry {owner.id!r}",
                        )


def _iter_entries(ctx: _Context, raw: Sequence[Mapping[str, Any]]) -> Iterator[Entry]:
    seen_ids: set[str] = set()
    seen_nrs: set[int] = set()
    for index, item in enumerate(raw):
        if item["id"] in seen_ids:
            raise ctx.error(("entries", index, "id"), f"duplicate id {item['id']!r}")
        if item["nr"] in seen_nrs:
            raise ctx.error(("entries", index, "nr"), f"duplicate nr {item['nr']}")
        seen_ids.add(item["id"])
        seen_nrs.add(item["nr"])
        yield Entry(
            id=item["id"],
            nr=item["nr"],
            restricted=item["restricted"],
            scope=frozenset(item["scope"]),
            de=_lang_part(ctx, ("entries", index, "de"), item["de"]),
            en=_lang_part(ctx, ("entries", index, "en"), item["en"]),
            note=item.get("note"),
        )


def parse_glossary(text: str, path: Path) -> Glossary:
    """Check and compile glossary ``text``; ``path`` names the file in messages."""
    ctx = _Context(path, {})
    try:
        ctx = _Context(path, _line_map(text))
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        line = mark.line + 1 if mark is not None else 1
        raise GlossaryError(f"{path}:{line}: not valid YAML") from exc
    _check_schema(ctx, data)
    entries = tuple(_iter_entries(ctx, data["entries"]))
    _check_consistency(ctx, entries)
    by_id = {entry.id: entry for entry in entries}
    return Glossary(entries, _fixed(ctx, data["fixed"], frozenset(by_id)), by_id)


@functools.cache
def _default_glossary() -> Glossary:
    path = default_path()
    return parse_glossary(path.read_text(encoding="utf-8"), path)


def load_glossary(path: Path | None = None) -> Glossary:
    """The kit's glossary, or the file at ``path`` (checked and compiled)."""
    if path is None:
        return _default_glossary()
    if path.stat().st_size > MAX_FILE_BYTES:
        raise GlossaryError(f"{path}:1: file larger than {MAX_FILE_BYTES} bytes")
    return parse_glossary(path.read_text(encoding="utf-8"), path)


def role_display(module: str, level: str, lang: str, glossary: Glossary | None = None) -> str:
    """Shown role name such as "Studio-Prüfer" or "Data Reviewer" (E-12)."""
    fixed = (glossary or load_glossary()).fixed
    if lang not in LANGUAGES:
        raise ValueError(f"unknown language {lang!r}")
    if module not in fixed.modules:
        raise ValueError(f"unknown module {module!r}")
    if level not in fixed.role_levels:
        raise ValueError(f"unknown level {level!r}")
    return fixed.role_formats[lang].format(
        module=fixed.modules[module][lang], level=fixed.role_levels[level][lang]
    )
