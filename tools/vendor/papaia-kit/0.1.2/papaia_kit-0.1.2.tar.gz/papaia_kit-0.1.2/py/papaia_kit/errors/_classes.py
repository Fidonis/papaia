"""Error classes, their HTTP statuses and retry behaviour (architecture V-06)."""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import StrEnum

TYPE_BASE = "https://schemas.papaia.dev/errors/"

# Code whose class and texts apply to every unknown or malformed code.
GENERIC_CODE = "PK-INTERNAL-001"

MODULE_PREFIXES = ("PK", "FLOW", "DATA", "STUDIO", "ASSIST", "ME", "CONNECTIONS", "MCP")

# <MODULE>-<AREA>-<NR>; some modules use more or fewer word segments.
CODE_PATTERN = r"(?:" + "|".join(MODULE_PREFIXES) + r")(?:-[A-Z0-9]{1,24}){1,5}"
CODE_MAX_LENGTH = 64
_CODE_RE = re.compile(CODE_PATTERN)


class ErrorClass(StrEnum):
    """Error classes shared by every module. ``internal_error`` is the generic class."""

    UNAUTHENTICATED = "unauthenticated"
    FORBIDDEN_OR_NOT_FOUND = "forbidden_or_not_found"
    INVALID_INPUT = "invalid_input"
    CONFLICT = "conflict"
    RATE_LIMITED = "rate_limited"
    UPSTREAM_UNAVAILABLE = "upstream_unavailable"
    IDENTITY_REVOKED = "identity_revoked"
    CLASS_EXCEEDED = "class_exceeded"
    CONTRACT_MISMATCH = "contract_mismatch"
    BUDGET_EXCEEDED = "budget_exceeded"
    INTERNAL_ERROR = "internal_error"

    @property
    def type_uri(self) -> str:
        return TYPE_BASE + self.value


@dataclass(frozen=True)
class ClassSpec:
    """Allowed HTTP statuses (first is the default) and whether a retry can succeed."""

    statuses: tuple[int, ...]
    retryable: bool

    @property
    def default_status(self) -> int:
        return self.statuses[0]


# forbidden_or_not_found defaults to 404 so that "exists but not allowed" and
# "does not exist" give the same answer unless the target decides otherwise.
CLASSES: dict[ErrorClass, ClassSpec] = {
    ErrorClass.UNAUTHENTICATED: ClassSpec((401,), retryable=False),
    ErrorClass.FORBIDDEN_OR_NOT_FOUND: ClassSpec((404, 403), retryable=False),
    ErrorClass.INVALID_INPUT: ClassSpec((422, 400), retryable=False),
    ErrorClass.CONFLICT: ClassSpec((409, 412), retryable=False),
    ErrorClass.RATE_LIMITED: ClassSpec((429,), retryable=True),
    ErrorClass.UPSTREAM_UNAVAILABLE: ClassSpec((503, 502, 504), retryable=True),
    ErrorClass.IDENTITY_REVOKED: ClassSpec((401,), retryable=False),
    ErrorClass.CLASS_EXCEEDED: ClassSpec((403,), retryable=False),
    ErrorClass.CONTRACT_MISMATCH: ClassSpec((409,), retryable=False),
    ErrorClass.BUDGET_EXCEEDED: ClassSpec((429,), retryable=False),
    ErrorClass.INTERNAL_ERROR: ClassSpec((500,), retryable=False),
}


def is_well_formed_code(code: object) -> bool:
    """True for a string of the form ``<MODULE>-<AREA>-<NR>`` with a known module."""
    return (
        isinstance(code, str)
        and len(code) <= CODE_MAX_LENGTH
        and _CODE_RE.fullmatch(code) is not None
    )
