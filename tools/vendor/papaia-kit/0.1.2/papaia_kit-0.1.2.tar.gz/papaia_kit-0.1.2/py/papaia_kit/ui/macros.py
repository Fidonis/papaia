"""Jinja2 macros of the patterns and components for server-rendered modules.

``pk/components.html`` holds one macro per pattern and component of
``contract/patterns/`` (table in ``contract/patterns/README.md``, section
"Macros"). :func:`extend_environment` adds the kit's template loader and the
helpers the macros use to a module's own Jinja2 environment::

    env = jinja2.Environment(loader=..., autoescape=True)
    extend_environment(env)
    # in a template, with the page language and the CSRF token in the context:
    # {% import "pk/components.html" as pk with context %}
    # {{ pk.button("Speichern", variant="primary", type="submit") }}
    env.get_template("page.html").render(pk_lang="de", pk_csrf=token)

The macros read ``pk_lang`` (``de`` or ``en``) and, for forms posting to the
module, ``pk_csrf`` from the context; fixed texts come from
``contract/messages`` in that language. Every value is escaped (the
environment must autoescape), every argument is checked here, an unknown
argument raises ``TypeError`` (Jinja2) and a bad value :class:`MacroError`.
No macro emits a script, a ``style`` attribute or an event handler, so the
output stays within a strict Content Security Policy.

The macros are display only: hiding an action grants nothing, every module
checks rights server-side on every request.
"""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from datetime import datetime
from functools import cache
from typing import Any

import jinja2
from markupsafe import Markup, escape

from papaia_kit._resources import ui_dist_dir
from papaia_kit.correlation import is_valid_correlation_id
from papaia_kit.errors import (
    CatalogError,
    check_code_text,
    consequence_text,
    display_text,
    load_catalog,
)
from papaia_kit.errors._patterns import has_hidden_characters
from papaia_kit.ui import messages
from papaia_kit.ui.formats import FormatError, format_moment, format_number, moment_html
from papaia_kit.ui.shell import ASSET_ROOT, kit_loader

__all__ = [
    "DEFAULT_SPRITE",
    "MacroError",
    "extend_environment",
    "symbol_names",
]

DEFAULT_SPRITE = f"{ASSET_ROOT}/icons/sprite.svg"
TEMPLATE = "pk/components.html"
MAX_TEXT_CHARS = 2000
MAX_ITEMS = 500
# Symbols whose name differs from their drawing in the sprite.
SYMBOL_ALIASES = {"go": "chevron-down"}
_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]{0,127}")
_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_.\[\]-]{0,127}")
_SCHEME = re.compile(r"^([A-Za-z][A-Za-z0-9+.-]*):")
_SAFE_SCHEMES = frozenset({"http", "https", "mailto"})
_PLACEHOLDER = re.compile(r"\{([a-z_]+)\}")
_SPRITE_ID = re.compile(r'<symbol\b[^>]*\bid="pk-icon-([a-z0-9-]+)"')
_SPRITE_URL = re.compile(r"(?:/[A-Za-z0-9._~%/+-]*)?")
_UNSAFE_LINK = re.compile(r"[\x00-\x20\x7f]")
_TOKEN = re.compile(r"[\x21-\x7e]{1,512}")
_CONTROL = re.compile(r"<(?:a|button|input|select|textarea|summary|details)\b", re.IGNORECASE)


class MacroError(ValueError):
    """A macro was called with a value outside its contract."""


@cache
def symbol_names() -> frozenset[str]:
    """Symbol names a macro accepts: every drawing of the kit's sprite and the aliases."""
    sprite = (ui_dist_dir() / "icons" / "sprite.svg").read_text(encoding="utf-8")
    return frozenset(_SPRITE_ID.findall(sprite)) | frozenset(SYMBOL_ALIASES)


def _fail(text: str) -> MacroError:
    return MacroError(f"pk/components.html: {text}")


def _lang(value: object) -> str:
    if not isinstance(value, str) or value not in messages.LANGUAGES:
        raise _fail(f"pk_lang must be one of {list(messages.LANGUAGES)} (import with context)")
    return value


class Helpers:
    """Checks and texts the macros call as ``pk_ui``; every failure raises :class:`MacroError`."""

    def __init__(self, sprite: str) -> None:
        self.sprite = sprite

    # --- values -----------------------------------------------------------------------

    def text(self, what: str, value: object, optional: bool = False) -> Any:
        """A shown text: non-empty, at most ``MAX_TEXT_CHARS``, no hidden characters."""
        if value is None or isinstance(value, jinja2.Undefined):
            if optional:
                return None
            raise _fail(f"{what} is required")
        if isinstance(value, bool) or not isinstance(value, str | int):
            raise _fail(f"{what} must be a text")
        shown = str(value)
        if not shown.strip() or len(shown) > MAX_TEXT_CHARS:
            raise _fail(f"{what} must be a text of 1 to {MAX_TEXT_CHARS} characters")
        if not isinstance(value, Markup) and has_hidden_characters(shown):
            raise _fail(f"{what} holds a hidden character")
        return value

    def value(self, what: str, value: object) -> str | None:
        """A form value: a text (may be empty) or a number, never a bool."""
        if value is None or isinstance(value, jinja2.Undefined):
            return None
        if isinstance(value, bool) or not isinstance(value, str | int | float):
            raise _fail(f"{what} must be a text or a number")
        shown = str(value)
        if len(shown) > MAX_TEXT_CHARS:
            raise _fail(f"{what} is longer than {MAX_TEXT_CHARS} characters")
        return shown

    def choice(self, what: str, value: object, allowed: Sequence[object]) -> Any:
        if isinstance(value, bool) != any(isinstance(a, bool) for a in allowed) or (
            value not in allowed
        ):
            raise _fail(f"{what} must be one of {list(allowed)}, not {value!r}")
        return value

    def ident(self, what: str, value: object) -> str:
        if not isinstance(value, str) or not _ID.fullmatch(value):
            raise _fail(f"{what} must be an id (letter, then letters, digits, - or _)")
        return value

    def name(self, what: str, value: object) -> str:
        if not isinstance(value, str) or not _NAME.fullmatch(value):
            raise _fail(f"{what} must be a form field name")
        return value

    def href(self, what: str, value: object) -> str:
        """A link target: relative, or http, https or mailto; no control characters."""
        if not isinstance(value, str) or not 0 < len(value) <= MAX_TEXT_CHARS:
            raise _fail(f"{what} must be a link")
        if _UNSAFE_LINK.search(value) or has_hidden_characters(value):
            raise _fail(f"{what} holds a space or a control character")
        scheme = _SCHEME.match(value)
        if scheme and scheme.group(1).lower() not in _SAFE_SCHEMES:
            raise _fail(f"{what} uses the scheme {scheme.group(1)!r}")
        if value.startswith("//"):
            raise _fail(f"{what} must not be protocol-relative")
        return value

    def count(self, what: str, value: object, minimum: int = 0) -> int:
        if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
            raise _fail(f"{what} must be a whole number of at least {minimum}")
        return value

    def items(self, what: str, value: object) -> list[Any]:
        if isinstance(value, str | bytes | Mapping) or not isinstance(value, Sequence):
            raise _fail(f"{what} must be a list")
        if len(value) > MAX_ITEMS:
            raise _fail(f"{what} has more than {MAX_ITEMS} entries")
        return list(value)

    def mapping(
        self, what: str, value: object, required: Sequence[str], optional: Sequence[str]
    ) -> Any:
        """``value`` as a dict with exactly the named keys; an unknown key raises."""
        if not isinstance(value, Mapping):
            raise _fail(f"{what} must be a mapping")
        keys = {str(k) for k in value}
        if missing := set(required) - keys:
            raise _fail(f"{what}: missing {sorted(missing)}")
        if unknown := keys - set(required) - set(optional):
            raise _fail(f"{what}: unknown {sorted(unknown)}")
        return dict(value)

    def mappings(
        self, what: str, value: object, required: Sequence[str], optional: Sequence[str]
    ) -> list[Any]:
        return [self.mapping(what, item, required, optional) for item in self.items(what, value)]

    def pair(self, value: object) -> tuple[Any, Any]:
        if isinstance(value, str | bytes | Mapping) or not isinstance(value, Sequence):
            raise _fail("a description list item is a pair (term, value)")
        if len(value) != 2:  # noqa: PLR2004 - term and value
            raise _fail("a description list item is a pair (term, value)")
        return value[0], value[1]

    def options(self, value: object) -> list[dict[str, str]]:
        """Choices of a select or group: at least one ``{value, label}``."""
        options = self.mappings("options", value, ["value", "label"], [])
        if not options:
            raise _fail("options must list at least one choice")
        return [
            {"value": self.value("option value", o["value"]) or "",
             "label": self.text("option label", o["label"])}
            for o in options
        ]  # fmt: skip

    def no_options(self, value: object) -> None:
        if value is not None and not isinstance(value, jinja2.Undefined):
            raise _fail("options belong to select, checkbox_group and radio_group")

    def selected(self, value: object) -> list[str]:
        if value is None or isinstance(value, jinja2.Undefined):
            return []
        if isinstance(value, str | int | float) and not isinstance(value, bool):
            return [str(value)]
        return [self.value("selected value", v) or "" for v in self.items("value", value)]

    def no_control(self, what: str, value: object) -> str:
        if _CONTROL.search(str(value)):
            raise _fail(f"{what} holds a link or a control (one tab stop per row)")
        return ""

    def csrf(self, value: object) -> str:
        if not isinstance(value, str) or not _TOKEN.fullmatch(value):
            raise _fail("pk_csrf must be the request's CSRF token (import with context)")
        return value

    def token(self, value: object) -> str:
        """An opaque token for a hidden field (``undo_token``)."""
        if not isinstance(value, str) or not _TOKEN.fullmatch(value or "x"):
            raise _fail("undo_token must be a token of at most 512 visible characters")
        return value

    def undo_ms(self) -> int:
        return messages.timing()["undo_window_s"] * 1000

    def fail(self, text: str) -> None:
        raise _fail(text)

    def symbol(self, value: object) -> str:
        """``href`` of a symbol in the configured sprite."""
        if not isinstance(value, str) or value not in symbol_names():
            raise _fail(f"unknown symbol {value!r}")
        return f"{self.sprite}#pk-icon-{SYMBOL_ALIASES.get(value, value)}"

    def reference(self, value: object) -> str:
        if not is_valid_correlation_id(value):
            raise _fail("reference must be a correlation id (1 to 64 of A-Z, a-z, 0-9, -)")
        return value

    # --- fixed texts ------------------------------------------------------------------

    def fixed(self, lang: object, name: str, key: str, /, **values: object) -> str:
        """A fixed text of ``contract/messages/<name>.<lang>.yaml``."""
        try:
            return messages.text(name, _lang(lang), key, **{k: str(v) for k, v in values.items()})
        except messages.MessageError as exc:
            raise _fail(str(exc)) from None

    def fixed_markup(self, lang: object, name: str, key: str, /, **values: object) -> Markup:
        """A fixed text whose placeholders take markup (``<time>``, ``<code>``), escaped."""
        try:
            template = messages.load_texts(name, _lang(lang))[key]
        except (KeyError, messages.MessageError):
            raise _fail(f"unknown text {name}.{key}") from None
        wanted = set(_PLACEHOLDER.findall(template))
        if wanted != set(values):
            raise _fail(f"{name}.{key}: values must be exactly {sorted(wanted)}")
        parts = _PLACEHOLDER.split(template)
        out = Markup()
        for index, part in enumerate(parts):
            out += escape(values[part]) if index % 2 else escape(part)
        return out

    def split_count(self, lang: object) -> tuple[str, str]:
        """``count_open`` around its number: visible before, hidden words after."""
        template = messages.load_texts("patterns", _lang(lang))["count_open"]
        before, _, after = template.partition("{count}")
        return before, after

    def range_text(self, lang: object, first: object, last: object, total: object) -> str:
        """``table_range`` ("1–50 von 120") for rows ``first`` to ``last`` of ``total``."""
        start, end = self.count("first", first, 1), self.count("last", last, 1)
        rows = self.count("total", total)
        if not start <= end <= rows:
            raise _fail("pager: first <= last <= total")
        values = {"from": start, "to": end, "total": rows}
        return self.fixed(lang, "patterns", "table_range", **values)

    def consequence(self, lang: object, key: str) -> str | None:
        return consequence_text(_lang(lang), key, {})

    def no_access(self, lang: object, module: object, contact: object) -> tuple[str, str, str]:
        return messages.no_access_texts(
            _lang(lang),
            module=str(self.text("module", module)),
            contact=None if contact is None else str(self.text("contact", contact)),
        )

    def reference_label(self, lang: object) -> str:
        return load_catalog().reference_label[_lang(lang)]

    def error(
        self,
        lang: object,
        code: object,
        text: object,
        reference: object,
        params: object,
    ) -> dict[str, str | None]:
        """Parts of a pattern 8 message from a kit code or from a module's own code text."""
        language = _lang(lang)
        correlation = self.reference(reference)
        if params is not None and not isinstance(params, Mapping):
            raise _fail("params must be a mapping")
        values = {str(k): self.text(f"params.{k}", v) for k, v in (params or {}).items()}
        if (code is None) == (text is None):
            raise _fail("error_message takes either code or text")
        if code is not None:
            shown = display_text(code, correlation_id=correlation, lang=language, params=values)
            return {"what": shown.what, "consequence": shown.consequence, "todo": shown.todo}
        try:
            entry = check_code_text(text, lang=language)
        except CatalogError as exc:
            raise _fail(f"text: {exc}") from None
        consequence = None
        if entry.consequence is not None:
            consequence = consequence_text(language, entry.consequence, values)
        return {
            "what": _fill(entry.what, values),
            "consequence": consequence,
            "todo": _fill(entry.todo, values),
        }

    # --- pattern 9 --------------------------------------------------------------------

    def moment(self, lang: object, value: object, kind: object, time_zone: object) -> Markup:
        if isinstance(value, str):
            try:
                value = datetime.fromisoformat(value)
            except ValueError:
                raise _fail("datetime value must be ISO 8601 with offset") from None
        try:
            moment = format_moment(value, kind=kind, lang=_lang(lang), time_zone=time_zone)
        except FormatError as exc:
            raise _fail(str(exc)) from None
        return Markup(moment_html(moment))  # noqa: S704 - moment_html escapes every part

    def number(self, lang: object, value: object, decimals: object) -> tuple[str, str]:
        if isinstance(value, bool):
            raise _fail("number value must be a number")
        try:
            shown = format_number(value, _lang(lang), decimals)
        except FormatError as exc:
            raise _fail(str(exc)) from None
        return str(value), shown


def _fill(template: str, values: Mapping[str, str]) -> str:
    def replace(match: re.Match[str]) -> str:
        key = match.group(1)
        if key not in values:
            raise _fail(f"text: missing value for {{{key}}}")
        return values[key]

    return _PLACEHOLDER.sub(replace, template)


@jinja2.pass_context
def _pk_text(context: jinja2.runtime.Context, name: str, key: str, /, **values: object) -> str:
    """Fixed text in the language of the page (``pk_lang``) for a module's own template."""
    helpers = context.environment.globals["pk_ui"]
    assert isinstance(helpers, Helpers)  # noqa: S101 - set by extend_environment
    return helpers.fixed(context.get("pk_lang"), name, key, **values)


def _autoescapes(env: jinja2.Environment) -> bool:
    setting = env.autoescape
    return bool(setting(TEMPLATE) if callable(setting) else setting)


def extend_environment(env: jinja2.Environment, *, sprite: str = DEFAULT_SPRITE) -> None:
    """Add the kit loader (after the module's own) and the macro helpers to ``env``.

    ``sprite`` is the path of the module's copy of ``icons/sprite.svg``
    (empty: symbol references stay fragments ``#pk-icon-<name>``).
    """
    if not _autoescapes(env):
        raise _fail("the environment must autoescape .html templates")
    if not _SPRITE_URL.fullmatch(sprite):
        raise _fail("sprite must be an absolute path without query or fragment, or empty")
    if "pk_ui" not in env.globals:
        own = env.loader
        env.loader = kit_loader() if own is None else jinja2.ChoiceLoader([own, kit_loader()])
    env.globals["pk_ui"] = Helpers(sprite)
    env.globals["pk_text"] = _pk_text
