"""Token exchange client: the only place that builds exchange requests for an audience,
including chained exchange where the policy allows it.

One exchange pattern is allowed (architecture V-13): RFC 8693 in the core realm
with ``audience=<a>`` and ``scope=aud-<a>``, exactly one audience per token. A
received token is exchanged further only for audiences the client declares as
``downstream``; the result then names the origin in the informational header
``X-Papaia-Origin-Azp``. Client authentication is ``private_key_jwt``; a client
secret is a fallback while that proof is open. See ``contract/exchange.md``.
"""

from papaia_kit.exchange.auth import (
    ALLOWED_ALGORITHMS,
    MAX_ASSERTION_LIFETIME,
    ClientAuth,
    ClientSecret,
    PrivateKeyJwt,
    Signer,
)
from papaia_kit.exchange.client import (
    ACCESS_TOKEN_TYPE,
    CACHE_MARGIN,
    CORRELATION_HEADER,
    GRANT_TYPE,
    ORIGIN_HEADER,
    ExchangeClient,
    ExchangedToken,
    ExchangeError,
)
from papaia_kit.exchange.transport import Transport, UrllibTransport

__all__ = [
    "ACCESS_TOKEN_TYPE",
    "ALLOWED_ALGORITHMS",
    "CACHE_MARGIN",
    "CORRELATION_HEADER",
    "GRANT_TYPE",
    "MAX_ASSERTION_LIFETIME",
    "ORIGIN_HEADER",
    "ClientAuth",
    "ClientSecret",
    "ExchangeClient",
    "ExchangeError",
    "ExchangedToken",
    "PrivateKeyJwt",
    "Signer",
    "Transport",
    "UrllibTransport",
]
