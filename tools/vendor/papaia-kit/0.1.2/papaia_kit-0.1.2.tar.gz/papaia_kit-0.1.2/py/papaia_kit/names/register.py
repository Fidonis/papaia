"""The register: every name of the reference stack with its owner."""

from __future__ import annotations

from papaia_kit.names._data import BASE
from papaia_kit.names._model import Entry, Kind
from papaia_kit.names.rules import _kind, exchange_scope


def _exchange_scopes() -> tuple[Entry, ...]:
    return tuple(
        Entry(exchange_scope(e.name), Kind.SCOPE, e.owner, f"exchange scope of audience {e.name}")
        for e in BASE
        if e.kind is Kind.AUDIENCE
    )


REGISTER: tuple[Entry, ...] = BASE + _exchange_scopes()

_INDEX: dict[tuple[str, Kind], Entry] = {(e.name, e.kind): e for e in REGISTER}


def entries(kind: Kind | str | None = None) -> tuple[Entry, ...]:
    """All registered entries, or those of one kind."""
    if kind is None:
        return REGISTER
    wanted = _kind(kind)
    return tuple(e for e in REGISTER if e.kind is wanted)


def lookup(name: str, kind: Kind | str) -> Entry | None:
    """The registered entry for ``name`` of ``kind``, or None."""
    return _INDEX.get((name, _kind(kind)))
