"""Catalog reader: loads the platform catalog, validates it against its schema, computes
its hash, derives the modules visible to a set of roles and resolves the return path
(``from`` parameter) to an address of a catalog target.

Every module reads ``platform/services.json`` and ``platform/groups.json`` with
this package and nothing else, so behaviour on an invalid, new, changed or
vanished file is the same everywhere. ``four_eyes_required`` gives every module
the one four-eyes rule of the installation. See ``contract/platform-services.md``
section 4 and ``contract/catalog-reader.md``.
"""

from papaia_kit.catalog.approval import (
    REMOVED_CAUSE,
    REMOVED_ERROR_CLASS,
    REMOVED_ERROR_CODE,
    ApprovalState,
    EntryRemovedError,
    approval_state,
    require_entry,
)
from papaia_kit.catalog.canonical import canonical_json, content_hash
from papaia_kit.catalog.delegations import (
    DELEGATION_DAYS_LIMIT,
    DelegationLifetime,
    default_lifetime,
)
from papaia_kit.catalog.document import (
    GROUPS_FORMAT,
    MAX_BYTES,
    MAX_DEPTH,
    SERVICES_FORMAT,
    Catalog,
    CatalogError,
    Entry,
    Group,
    GroupList,
    State,
    Surface,
    parse_groups,
    parse_services,
)
from papaia_kit.catalog.four_eyes import (
    FOUR_EYES_DEFAULT,
    SELF_APPROVAL_FLAG,
    SELF_REVIEW_CODE,
    FourEyes,
    ReviewDecision,
    four_eyes_required,
    four_eyes_setting,
    review_decision,
)
from papaia_kit.catalog.reader import (
    INTERNAL_CHECK_ERROR,
    MAX_AGE_SECONDS,
    Changes,
    GroupsReader,
    Reader,
    ReaderStatus,
    ServicesReader,
    diff,
)
from papaia_kit.catalog.return_path import (
    ADMIN_TARGET,
    MAX_FROM_LENGTH,
    ReturnTarget,
    resolve_from,
)
from papaia_kit.catalog.visible import LinkState, link_state, visible_modules

__all__ = [
    "ADMIN_TARGET",
    "DELEGATION_DAYS_LIMIT",
    "FOUR_EYES_DEFAULT",
    "GROUPS_FORMAT",
    "INTERNAL_CHECK_ERROR",
    "MAX_AGE_SECONDS",
    "MAX_BYTES",
    "MAX_DEPTH",
    "MAX_FROM_LENGTH",
    "REMOVED_CAUSE",
    "REMOVED_ERROR_CLASS",
    "REMOVED_ERROR_CODE",
    "SELF_APPROVAL_FLAG",
    "SELF_REVIEW_CODE",
    "SERVICES_FORMAT",
    "ApprovalState",
    "Catalog",
    "CatalogError",
    "Changes",
    "DelegationLifetime",
    "Entry",
    "EntryRemovedError",
    "FourEyes",
    "Group",
    "GroupList",
    "GroupsReader",
    "LinkState",
    "Reader",
    "ReaderStatus",
    "ReturnTarget",
    "ReviewDecision",
    "ServicesReader",
    "State",
    "Surface",
    "approval_state",
    "canonical_json",
    "content_hash",
    "default_lifetime",
    "diff",
    "four_eyes_required",
    "four_eyes_setting",
    "link_state",
    "parse_groups",
    "parse_services",
    "require_entry",
    "resolve_from",
    "review_decision",
    "visible_modules",
]
