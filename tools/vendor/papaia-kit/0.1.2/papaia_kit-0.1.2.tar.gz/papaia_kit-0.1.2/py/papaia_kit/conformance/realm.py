"""Realm suite: clients with token exchange versus audiences (separation rule).

A client with standard token exchange is never an audience of a resource
server; the only exception is the chain holder ``papaia-data``, so the
intersection of exchange clients and audiences is exactly ``{papaia-data}``
(security 1.2, RE-01). Audiences come from ``oidc-audience-mapper`` on clients
and client scopes and from client roles that reach a token through
``oidc-audience-resolve-mapper``. The suite reads the realm from a realm export
or, read-only, from the admin API, and never prints a value of the realm other
than names of clients, client scopes, mappers, roles, policies and audiences.
Any other mapper that writes the ``aud`` claim counts as well: a hardcoded value
as the audiences it names, anything else (user attributes, scripts) as an
audience the realm does not show, which fails the checks that need it. Mappers
that add a client role to the token (hardcoded role, role name) count as the
client role they name. A mapper type outside the list of built-in types the
suite knows counts as an unknown audience source (fail closed).

See ``contract/conformance.md``.
"""

from __future__ import annotations

import http.client
import ipaddress
import json
import re
import time
import urllib.error
import urllib.request
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import quote, urlsplit

from papaia_kit.conformance.result import Case, SuiteResult, case
from papaia_kit.names import has_exchange_prefix

SUITE = "realm"
REALM_CHECKS = (
    "load",
    "separation",
    "chain-holder",
    "exchange-default-scopes",
    "never-audience",
    "client-policies",
)

CHAIN_HOLDER = "papaia-data"
CHAIN_HOLDER_ATTRIBUTE = "papaia.chain-holder"
TOKEN_EXCHANGE_ATTRIBUTE = "standard.token.exchange.enabled"  # noqa: S105 - attribute name
# Clients that are never an audience, with or without token exchange (security 1.2,
# RE-59, RE-93, RE-97).
NEVER_AUDIENCE = ("flow-console", "flow-engine", "papaia-data-ui")
# Resource servers that never hold token exchange, with the module's one exchange
# client (PLT-11-A1 as changed by its review: for Flow ``flow-engine``, never ``flow``).
NEVER_EXCHANGE = {"flow": "flow-engine"}
AUDIENCE_MAPPER = "oidc-audience-mapper"
AUDIENCE_RESOLVE_MAPPER = "oidc-audience-resolve-mapper"
_AUDIENCE_KEYS = ("included.client.audience", "included.custom.audience")
AUD_CLAIM = "aud"
HARDCODED_CLAIM_MAPPER = "oidc-hardcoded-claim-mapper"
SCRIPT_MAPPER = "oidc-script-based-protocol-mapper"
SCRIPT_MAPPER_PREFIX = "script-"
HARDCODED_ROLE_MAPPER = "oidc-hardcoded-role-mapper"
ROLE_NAME_MAPPER = "oidc-role-name-mapper"
# The configuration key that names the role a role-adding mapper puts into the token.
ROLE_MAPPER_KEYS = {HARDCODED_ROLE_MAPPER: "role", ROLE_NAME_MAPPER: "new.role.name"}
OIDC_PROTOCOL = "openid-connect"
# Built-in OIDC mapper types whose effect on ``aud`` and on the token's roles the
# suite understands: they write ``aud`` only through ``claim.name`` (checked) or are
# handled above. Every other type is an unknown audience source.
KNOWN_MAPPERS = frozenset(
    {
        AUDIENCE_MAPPER,
        AUDIENCE_RESOLVE_MAPPER,
        HARDCODED_CLAIM_MAPPER,
        HARDCODED_ROLE_MAPPER,
        ROLE_NAME_MAPPER,
        "oidc-acr-mapper",
        "oidc-address-mapper",
        "oidc-allowed-origins-mapper",
        "oidc-amr-mapper",
        "oidc-claims-param-token-mapper",
        "oidc-full-name-mapper",
        "oidc-group-membership-mapper",
        "oidc-nonce-backwards-compatible-mapper",
        "oidc-organization-membership-mapper",
        "oidc-sha256-pairwise-sub-mapper",
        "oidc-sub-mapper",
        "oidc-usermodel-attribute-mapper",
        "oidc-usermodel-client-role-mapper",
        "oidc-usermodel-property-mapper",
        "oidc-usermodel-realm-role-mapper",
        "oidc-usersessionmodel-note-mapper",
    }
)
UNKNOWN_AUD = "writes the aud claim with values the realm does not show"
UNKNOWN_ROLE = "adds a role the suite cannot resolve to a realm role or a client role"
# Client policy conditions that limit a policy to named clients or scopes (PLT-16-A1),
# with the configuration key that names them.
LIMITING_CONDITIONS = {
    "client-attributes": "attributes",
    "client-roles": "roles",
    "client-scopes": "scopes",
}
NEGATIVE_LOGIC = "is-negative-logic"

MAX_EXPORT_BYTES = 64 * 1024 * 1024
MAX_NAME = 255
MAX_ITEMS = 100_000
MAX_TOKEN = 16 * 1024
MAX_CONFIG_VALUE = 64 * 1024
PAGE_SIZE = 100
_REALM_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}")
_TOKEN = re.compile(r"[\x21-\x7e]+")
# A value of a hardcoded ``aud`` claim that reads as an audience (client id or URI).
_AUDIENCE_VALUE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,254}")


class RealmError(ValueError):
    """The realm could not be read or does not have the expected shape."""


@dataclass(frozen=True, slots=True, order=True)
class RoleRef:
    """A realm role (``client`` is ``None``) or a client role of ``client``."""

    client: str | None
    name: str


@dataclass(frozen=True, slots=True)
class Mapper:
    """A protocol mapper; ``audience`` are the values it writes into ``aud``,
    ``role`` the role it adds to the token (``<clientId>.<role>`` or a realm role,
    resolved against the realm by the checks) and ``unknown`` says why it is an
    audience source the realm does not show (empty when it is none)."""

    name: str
    kind: str
    audience: tuple[str, ...] = ()
    unknown: str = ""
    role: str | None = None


@dataclass(frozen=True, slots=True)
class ClientScope:
    name: str
    mappers: tuple[Mapper, ...]
    roles: frozenset[RoleRef]


@dataclass(frozen=True, slots=True)
class Client:
    client_id: str
    token_exchange: bool
    chain_holder: str | None
    default_scopes: tuple[str, ...]
    optional_scopes: tuple[str, ...]
    mappers: tuple[Mapper, ...]
    full_scope: bool
    roles: frozenset[RoleRef]


@dataclass(frozen=True, slots=True)
class Condition:
    """A client policy condition; ``limiting`` when it limits the policy to named
    clients, roles, scopes or attributes, else ``note`` says why not."""

    name: str
    limiting: bool
    note: str = ""


@dataclass(frozen=True, slots=True)
class Policy:
    name: str
    conditions: tuple[Condition, ...]
    is_global: bool = False


@dataclass(frozen=True, slots=True)
class Realm:
    name: str
    clients: tuple[Client, ...]
    scopes: Mapping[str, ClientScope]
    client_roles: frozenset[RoleRef]
    composites: Mapping[RoleRef, frozenset[RoleRef]]
    policies: tuple[Policy, ...]
    realm_roles: frozenset[str] = frozenset()


# -- reading a realm export ---------------------------------------------------


def _name(value: object, where: str) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= MAX_NAME or not value.isprintable():
        raise RealmError(f"{where}: expected a printable name of 1 to {MAX_NAME} characters")
    return value


def _list(value: object, where: str) -> list[Any]:
    if not isinstance(value, list) or len(value) > MAX_ITEMS:
        raise RealmError(f"{where}: expected a list of at most {MAX_ITEMS} items")
    return value


def _object(value: object, where: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise RealmError(f"{where}: expected an object")
    return value


def _optional(document: Mapping[str, Any], key: str, default: Any) -> Any:
    value = document.get(key)
    return default if value is None else value


def _names(value: object, where: str) -> tuple[str, ...]:
    return tuple(_name(item, where) for item in _list(value, where))


def _config_text(config: Mapping[str, Any], key: str, where: str) -> str | None:
    value = config.get(key)
    if value is None:
        return None
    if not isinstance(value, str) or len(value) > MAX_CONFIG_VALUE:
        raise RealmError(f"{where}.config.{key}: expected a string of at most {MAX_CONFIG_VALUE}")
    return value


def _writes_aud(claim: str) -> bool:
    """``aud`` itself or a nested name below it, compared without case."""
    folded = claim.strip().casefold()
    return folded == AUD_CLAIM or folded.startswith(f"{AUD_CLAIM}.")


def _hardcoded_audiences(value: str | None) -> tuple[str, ...] | None:
    """The audiences a hardcoded ``aud`` value names, or ``None`` when it does not
    read as one audience or a JSON list of audiences."""
    if value is None:
        return None
    text = value.strip()
    if text.startswith("["):
        try:
            items = json.loads(text, parse_constant=_no_constant)
        except (json.JSONDecodeError, RealmError, RecursionError):
            return None
    else:
        items = [text]
    if (
        not isinstance(items, list)
        or not items
        or not all(isinstance(i, str) and _AUDIENCE_VALUE.fullmatch(i) for i in items)
    ):
        return None
    return tuple(items)


def _mapper(raw: Mapping[str, Any], name: str, kind: str, where: str) -> Mapper:
    config = _object(_optional(raw, "config", {}), f"{where}.config")
    if kind == AUDIENCE_MAPPER:
        audience = tuple(
            _name(config[key], f"{where}.config.{key}") for key in _AUDIENCE_KEYS if config.get(key)
        )
        return Mapper(name, kind, audience)
    if kind == SCRIPT_MAPPER or kind.startswith(SCRIPT_MAPPER_PREFIX):
        return Mapper(name, kind, unknown=UNKNOWN_AUD)
    if kind not in KNOWN_MAPPERS:
        return Mapper(
            name,
            kind,
            unknown=f"is of the mapper type {kind!r}, which the suite does not know; it may "
            "write the aud claim or add roles",
        )
    role: str | None = None
    if kind in ROLE_MAPPER_KEYS:
        role = (_config_text(config, ROLE_MAPPER_KEYS[kind], where) or "").strip()
    claim = _config_text(config, "claim.name", where)
    if claim is None or not _writes_aud(claim):
        return Mapper(name, kind, role=role)
    if kind == HARDCODED_CLAIM_MAPPER and claim.strip().casefold() == AUD_CLAIM:
        named = _hardcoded_audiences(_config_text(config, "claim.value", where))
        if named is not None:
            return Mapper(name, kind, named)
    return Mapper(name, kind, unknown=UNKNOWN_AUD, role=role)


def _mappers(value: object, where: str) -> tuple[Mapper, ...]:
    """The mappers that act on OIDC tokens; a mapper of another protocol (``saml``)
    never reaches one. A mapper without ``protocol`` counts as OIDC."""
    where = f"{where}.protocolMappers"
    found: list[Mapper] = []
    for item in _list(value, where):
        raw = _object(item, where)
        name = _name(raw.get("name"), f"{where}.name")
        kind = _name(raw.get("protocolMapper"), f"{where}[{name!r}].protocolMapper")
        protocol = _name(_optional(raw, "protocol", OIDC_PROTOCOL), f"{where}[{name!r}].protocol")
        if protocol != OIDC_PROTOCOL:
            continue
        found.append(_mapper(raw, name, kind, f"{where}[{name!r}]"))
    return tuple(found)


def _attribute(attributes: Mapping[str, Any], key: str, where: str) -> str | None:
    value = attributes.get(key)
    if value is None:
        return None
    if not isinstance(value, str) or len(value) > MAX_NAME:
        raise RealmError(f"{where}.attributes.{key}: expected a string")
    return value


def _client(raw: object, index: int) -> Client:
    item = _object(raw, f"clients[{index}]")
    cid = _name(item.get("clientId"), f"clients[{index}].clientId")
    where = f"clients[{cid!r}]"
    attributes = _object(_optional(item, "attributes", {}), f"{where}.attributes")
    exchange = _attribute(attributes, TOKEN_EXCHANGE_ATTRIBUTE, where)
    full_scope = _optional(item, "fullScopeAllowed", True)
    if not isinstance(full_scope, bool):
        raise RealmError(f"{where}.fullScopeAllowed: expected true or false")
    return Client(
        client_id=cid,
        token_exchange=(exchange or "").strip().lower() == "true",
        chain_holder=_attribute(attributes, CHAIN_HOLDER_ATTRIBUTE, where),
        default_scopes=_names(
            _optional(item, "defaultClientScopes", []), f"{where}.defaultClientScopes"
        ),
        optional_scopes=_names(
            _optional(item, "optionalClientScopes", []), f"{where}.optionalClientScopes"
        ),
        mappers=_mappers(_optional(item, "protocolMappers", []), where),
        full_scope=full_scope,
        roles=frozenset(),
    )


def _roles_section(
    document: Mapping[str, Any],
) -> tuple[set[RoleRef], dict[RoleRef, frozenset[RoleRef]]]:
    roles = _object(_optional(document, "roles", {}), "roles")
    known: set[RoleRef] = set()
    composites: dict[RoleRef, frozenset[RoleRef]] = {}

    def read(items: object, owner: str | None, where: str) -> None:
        for item in _list(items, where):
            raw = _object(item, where)
            ref = RoleRef(owner, _name(raw.get("name"), f"{where}.name"))
            known.add(ref)
            comps = _object(_optional(raw, "composites", {}), f"{where}[{ref.name!r}].composites")
            children = {
                RoleRef(None, n)
                for n in _names(_optional(comps, "realm", []), f"{where}.composites.realm")
            }
            by_client = _object(_optional(comps, "client", {}), f"{where}.composites.client")
            for cid, names in by_client.items():
                owner_id = _name(cid, f"{where}.composites.client")
                children |= {
                    RoleRef(owner_id, n) for n in _names(names, f"{where}.composites.client")
                }
            if children:
                composites[ref] = frozenset(children)

    read(_optional(roles, "realm", []), None, "roles.realm")
    for cid, items in _object(_optional(roles, "client", {}), "roles.client").items():
        read(items, _name(cid, "roles.client"), f"roles.client[{cid!r}]")
    return known, composites


def _scope_mappings(
    document: Mapping[str, Any],
) -> tuple[dict[str, set[RoleRef]], dict[str, set[RoleRef]]]:
    """Roles in scope per client and per client scope (``scopeMappings``,
    ``clientScopeMappings``)."""
    by_client: dict[str, set[RoleRef]] = {}
    by_scope: dict[str, set[RoleRef]] = {}

    def add(entry: object, owner: str | None, where: str) -> None:
        raw = _object(entry, where)
        holders = [k for k in ("client", "clientScope") if raw.get(k) is not None]
        if len(holders) != 1:
            raise RealmError(f"{where}: expected exactly one of client and clientScope")
        target = by_client if holders[0] == "client" else by_scope
        holder = _name(raw[holders[0]], f"{where}.{holders[0]}")
        names = _names(_optional(raw, "roles", []), f"{where}.roles")
        target.setdefault(holder, set()).update(RoleRef(owner, n) for n in names)

    for index, entry in enumerate(_list(_optional(document, "scopeMappings", []), "scopeMappings")):
        add(entry, None, f"scopeMappings[{index}]")
    mappings = _object(_optional(document, "clientScopeMappings", {}), "clientScopeMappings")
    for cid, entries in mappings.items():
        owner = _name(cid, "clientScopeMappings")
        where = f"clientScopeMappings[{owner!r}]"
        for entry in _list(entries, where):
            add(entry, owner, where)
    return by_client, by_scope


def _negated(config: Mapping[str, Any], where: str) -> bool:
    value = config.get(NEGATIVE_LOGIC)
    if value is None or isinstance(value, bool):
        return value is True
    if isinstance(value, str) and len(value) <= MAX_NAME:
        return value.strip().lower() == "true"
    raise RealmError(f"{where}.{NEGATIVE_LOGIC}: expected true or false")


def _attribute_entries(value: object, where: str) -> int:
    """Number of attribute entries; Keycloak keeps them as a list or as JSON text."""
    if isinstance(value, str):
        if len(value) > MAX_CONFIG_VALUE:
            raise RealmError(f"{where}: attribute list is too long")
        try:
            value = json.loads(value, parse_constant=_no_constant)
        except (json.JSONDecodeError, RealmError, RecursionError):
            raise RealmError(f"{where}: attribute list is not JSON") from None
    entries = _list(value, where)
    for entry in entries:
        _name(_object(entry, where).get("key"), f"{where}.key")
    return len(entries)


def _condition(raw: object, where: str) -> Condition:
    item = _object(raw, where)
    name = _name(item.get("condition"), f"{where}.condition")
    config = _object(_optional(item, "configuration", {}), f"{where}[{name!r}].configuration")
    key = LIMITING_CONDITIONS.get(name)
    if key is None:
        return Condition(name, limiting=False)
    where = f"{where}[{name!r}].configuration"
    negated = _negated(config, where)
    value = _optional(config, key, [])
    if key == "attributes":
        count = _attribute_entries(value, f"{where}.{key}")
    else:
        count = len(_names(value, f"{where}.{key}"))
    if negated:
        return Condition(name, limiting=False, note="negated")
    if count == 0:
        return Condition(name, limiting=False, note=f"no {key}")
    return Condition(name, limiting=True)


def _policies(document: Mapping[str, Any]) -> tuple[Policy, ...]:
    """Realm and global client policies, enabled or not (a disabled policy can be
    enabled without a new check)."""
    section = _object(_optional(document, "clientPolicies", {}), "clientPolicies")
    found: list[Policy] = []
    for key, is_global in (("policies", False), ("globalPolicies", True)):
        for item in _list(_optional(section, key, []), f"clientPolicies.{key}"):
            raw = _object(item, f"clientPolicies.{key}")
            name = _name(raw.get("name"), f"clientPolicies.{key}.name")
            where = f"clientPolicies.{key}[{name!r}].conditions"
            conditions = tuple(
                _condition(c, where) for c in _list(_optional(raw, "conditions", []), where)
            )
            found.append(Policy(name, conditions, is_global))
    return tuple(found)


def realm_from_export(document: object) -> Realm:
    """The realm of a Keycloak realm export (``RealmRepresentation``).

    Only the fields the checks read are type-checked; every other field of the
    representation is ignored and never printed.
    """
    doc = _object(document, "realm export")
    name = _name(doc.get("realm"), "realm")
    clients: list[Client] = []
    for index, raw in enumerate(_list(_optional(doc, "clients", []), "clients")):
        clients.append(_client(raw, index))
    ids = [c.client_id for c in clients]
    duplicates = sorted({i for i in ids if ids.count(i) > 1})
    if duplicates:
        raise RealmError(f"clients: duplicate clientId {duplicates[0]!r}")
    scopes: dict[str, ClientScope] = {}
    client_scope_roles_by_client, scope_roles = _scope_mappings(doc)
    for raw in _list(_optional(doc, "clientScopes", []), "clientScopes"):
        item = _object(raw, "clientScopes")
        scope_name = _name(item.get("name"), "clientScopes.name")
        if scope_name in scopes:
            raise RealmError(f"clientScopes: duplicate name {scope_name!r}")
        where = f"clientScopes[{scope_name!r}]"
        scopes[scope_name] = ClientScope(
            scope_name,
            _mappers(_optional(item, "protocolMappers", []), where),
            frozenset(scope_roles.get(scope_name, ())),
        )
    known, composites = _roles_section(doc)
    clients = [
        Client(
            c.client_id,
            c.token_exchange,
            c.chain_holder,
            c.default_scopes,
            c.optional_scopes,
            c.mappers,
            c.full_scope,
            frozenset(client_scope_roles_by_client.get(c.client_id, ())),
        )
        for c in clients
    ]
    return Realm(
        name=name,
        clients=tuple(clients),
        scopes=scopes,
        client_roles=frozenset(r for r in known if r.client is not None),
        composites=composites,
        policies=_policies(doc),
        realm_roles=frozenset(r.name for r in known if r.client is None),
    )


def _strict_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise RealmError(f"duplicate key {key[:MAX_NAME]!r}")
        result[key] = value
    return result


def _no_constant(name: str) -> None:
    raise RealmError(f"{name} is not JSON")


def parse_json(raw: bytes, where: str) -> object:
    """Strict JSON: UTF-8, no duplicate keys, no ``NaN`` or ``Infinity``."""
    try:
        return json.loads(
            raw.decode("utf-8"), object_pairs_hook=_strict_object, parse_constant=_no_constant
        )
    except RealmError as exc:
        raise RealmError(f"{where}: {exc}") from None
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as exc:
        raise RealmError(f"{where}: not valid JSON ({type(exc).__name__})") from None


def load_realm_export(path: Path) -> Realm:
    """Read a realm export file (at most ``MAX_EXPORT_BYTES``, strict JSON)."""
    try:
        with path.open("rb") as handle:
            raw = handle.read(MAX_EXPORT_BYTES + 1)
    except OSError as exc:
        raise RealmError(f"cannot read {path.name}: {exc.strerror}") from None
    if len(raw) > MAX_EXPORT_BYTES:
        raise RealmError(f"{path.name} is larger than {MAX_EXPORT_BYTES} bytes")
    return realm_from_export(parse_json(raw, path.name))


# -- reading the admin API ------------------------------------------------------


class Fetch(Protocol):
    """Sends one GET request and returns status code and body."""

    def get(self, url: str, headers: Mapping[str, str], timeout: float) -> tuple[int, bytes]: ...


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args: object, **kwargs: object) -> None:
        return None


class UrllibFetch:
    """Standard library GET: no redirect (it would carry the token elsewhere), no proxy
    from the environment, at most ``MAX_RESPONSE`` bytes; other failures raise ``OSError``."""

    MAX_RESPONSE = 16 * 1024 * 1024

    def __init__(self) -> None:
        self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())

    def _read(self, response: Any) -> bytes:
        body = response.read(self.MAX_RESPONSE + 1)
        if not isinstance(body, bytes):
            raise OSError("response body is not bytes")
        if len(body) > self.MAX_RESPONSE:
            raise OSError(f"response larger than {self.MAX_RESPONSE} bytes")
        remaining = getattr(response, "length", None)
        if type(remaining) is int and remaining > 0:
            raise OSError("response body truncated")
        return body

    def get(self, url: str, headers: Mapping[str, str], timeout: float) -> tuple[int, bytes]:
        if urlsplit(url).scheme not in ("http", "https"):
            raise OSError("admin URL must use http or https")
        request = urllib.request.Request(url, headers=dict(headers), method="GET")  # noqa: S310
        try:
            with self._opener.open(request, timeout=timeout) as response:
                return int(response.status), self._read(response)
        except urllib.error.HTTPError as error:
            with error:
                return int(error.code), self._read(error)
        except http.client.HTTPException as error:
            raise OSError(f"malformed response: {type(error).__name__}") from None


def _loopback(host: str) -> bool:
    """Only a literal loopback address; a name such as ``localhost`` goes through the
    resolver and could lead elsewhere."""
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _admin_base(admin_url: str, realm: str) -> str:
    parts = urlsplit(admin_url)
    host = parts.hostname or ""
    if (
        parts.scheme not in ("http", "https")
        or not host
        or parts.username is not None
        or parts.password is not None
        or parts.query
        or parts.fragment
        or (parts.scheme == "http" and not _loopback(host))
    ):
        raise RealmError(
            "admin URL must be https://<host>[:port][/path] without credentials, query or "
            "fragment (plain http only on a literal loopback address such as 127.0.0.1)"
        )
    if not _REALM_NAME.fullmatch(realm) or realm in (".", ".."):
        raise RealmError("realm name must be 1 to 64 letters, digits, '.', '_' or '-'")
    return f"{admin_url.rstrip('/')}/admin/realms/{quote(realm, safe='')}"


class _Admin:
    def __init__(self, base: str, token: str, fetch: Fetch, timeout: float) -> None:
        self._base = base
        self._headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
        self._fetch = fetch
        self._timeout = timeout

    def get(self, path: str) -> Any:
        url = f"{self._base}/{path}"
        shown = path.split("?", 1)[0]
        try:
            status, body = self._fetch.get(url, self._headers, self._timeout)
        except OSError as exc:
            raise RealmError(f"admin API {shown}: {exc}") from None
        if status != 200:  # noqa: PLR2004 - the one status of a successful read
            raise RealmError(f"admin API {shown}: HTTP {status}")
        return parse_json(body, f"admin API {shown}")

    def pages(self, path: str, extra: str = "") -> list[Any]:
        items: list[Any] = []
        while True:
            page = _list(self.get(f"{path}?first={len(items)}&max={PAGE_SIZE}{extra}"), path)
            items += page
            if len(page) < PAGE_SIZE:
                return items
            if len(items) > MAX_ITEMS:
                raise RealmError(f"admin API {path}: more than {MAX_ITEMS} items")


def _internal_id(item: Mapping[str, Any], where: str) -> str:
    value = item.get("id")
    if not isinstance(value, str) or not 0 < len(value) <= MAX_NAME or not value.isprintable():
        raise RealmError(f"{where}: expected an id")
    return value


def _path_id(item: Mapping[str, Any], where: str) -> str:
    return quote(_internal_id(item, where), safe="")


def _mapping_rows(
    body: object, where: str, rows: dict[str | None, list[dict[str, Any]]], holder: dict[str, str]
) -> None:
    """Scope mappings of the admin API in the shape of a realm export."""
    mappings = _object(body, where)
    realm_names = [
        _name(_object(r, where).get("name"), where)
        for r in _list(_optional(mappings, "realmMappings", []), where)
    ]
    if realm_names:
        rows.setdefault(None, []).append({**holder, "roles": realm_names})
    for owner, entry in _object(_optional(mappings, "clientMappings", {}), where).items():
        names = [
            _name(_object(r, where).get("name"), where)
            for r in _list(_optional(_object(entry, where), "mappings", []), where)
        ]
        rows.setdefault(_name(owner, where), []).append({**holder, "roles": names})


def read_realm_admin(
    admin_url: str,
    realm: str,
    token: str,
    *,
    fetch: Fetch | None = None,
    timeout: float = 10.0,
) -> Realm:
    """Read the realm through the admin API with a read-only account's access token.

    The account needs ``view-clients`` and ``view-realm`` of ``realm-management``
    and nothing else; the suite sends only GET requests. The token is never part
    of a message.
    """
    if not 0 < len(token) <= MAX_TOKEN or not _TOKEN.fullmatch(token):
        raise RealmError(f"admin token must be 1 to {MAX_TOKEN} visible ASCII characters")
    admin = _Admin(_admin_base(admin_url, realm), token, fetch or UrllibFetch(), timeout)

    clients = [_object(c, "clients") for c in admin.pages("clients")]
    by_internal = {_internal_id(c, "clients"): c.get("clientId") for c in clients}
    scopes = [
        _object(s, "client-scopes") for s in _list(admin.get("client-scopes"), "client-scopes")
    ]
    rows: dict[str | None, list[dict[str, Any]]] = {}
    for item in clients:
        cid = _name(item.get("clientId"), "clients.clientId")
        body = admin.get(f"clients/{_path_id(item, 'clients')}/scope-mappings")
        _mapping_rows(body, f"scope mappings of {cid!r}", rows, {"client": cid})
    for item in scopes:
        name = _name(item.get("name"), "client-scopes.name")
        body = admin.get(f"client-scopes/{_path_id(item, 'client-scopes')}/scope-mappings")
        _mapping_rows(body, f"scope mappings of {name!r}", rows, {"clientScope": name})

    def role_rows(items: Iterable[object], where: str) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for raw in items:
            role = _object(raw, where)
            row: dict[str, Any] = {"name": _name(role.get("name"), f"{where}.name")}
            if role.get("composite") is True:
                children = _list(
                    admin.get(f"roles-by-id/{_path_id(role, where)}/composites"), where
                )
                comps: dict[str, Any] = {"realm": [], "client": {}}
                for child_raw in children:
                    child = _object(child_raw, where)
                    child_name = _name(child.get("name"), f"{where}.composites")
                    if child.get("clientRole") is True:
                        owner = by_internal.get(str(child.get("containerId")))
                        owner = _name(owner, f"{where}.composites: client of a composite role")
                        comps["client"].setdefault(owner, []).append(child_name)
                    else:
                        comps["realm"].append(child_name)
                row["composites"] = comps
            result.append(row)
        return result

    client_roles: dict[str, list[dict[str, Any]]] = {}
    for item in clients:
        cid = _name(item.get("clientId"), "clients.clientId")
        listed = _list(
            admin.get(f"clients/{_path_id(item, 'clients')}/roles?briefRepresentation=false"),
            "roles",
        )
        if listed:
            client_roles[cid] = role_rows(listed, f"roles of {cid!r}")
    realm_roles = role_rows(admin.pages("roles", "&briefRepresentation=false"), "realm roles")
    policies = admin.get("client-policies/policies?include-global-policies=true")

    export = {
        "realm": realm,
        "clients": clients,
        "clientScopes": scopes,
        "roles": {"realm": realm_roles, "client": client_roles},
        "scopeMappings": rows.pop(None, []),
        "clientScopeMappings": rows,
        "clientPolicies": policies,
    }
    return realm_from_export(export)


# -- the checks -------------------------------------------------------------------


def exchange_clients(realm: Realm) -> frozenset[str]:
    """Client ids with standard token exchange enabled."""
    return frozenset(c.client_id for c in realm.clients if c.token_exchange)


def _closure(
    start: Iterable[RoleRef], composites: Mapping[RoleRef, frozenset[RoleRef]]
) -> set[RoleRef]:
    seen: set[RoleRef] = set()
    stack = list(start)
    while stack:
        ref = stack.pop()
        if ref not in seen:
            seen.add(ref)
            stack.extend(composites.get(ref, ()))
    return seen


def _in_scope(realm: Realm, client: Client, scopes: Sequence[ClientScope]) -> set[RoleRef]:
    """Client roles a token of ``client`` can carry through ``scopes``, without the
    client's own roles: the audience resolve mapper never adds the client itself.

    Without full scope the client's own roles are always in scope, so the
    composites of an own role bring their children in."""
    if client.full_scope:
        roles: set[RoleRef] = set(realm.client_roles)
    else:
        own = {r for r in realm.client_roles if r.client == client.client_id}
        direct = own.union(client.roles, *(s.roles for s in scopes))
        roles = _closure(direct, realm.composites)
    return {r for r in roles if r.client is not None and r.client != client.client_id}


def mapper_roles(realm: Realm, mapper: Mapper) -> tuple[RoleRef, ...] | None:
    """The roles a role-adding mapper puts into the token, or ``None`` when its role
    cannot be resolved. ``<clientId>.<role>`` counts for every split at a dot whose
    left part is a client of the realm; a name without such a client is a realm role
    when it has no dot or names one (its composites count through the closure), and
    cannot be resolved otherwise."""
    value = mapper.role
    if value is None:
        return ()
    clients = {c.client_id for c in realm.clients}
    found = tuple(
        RoleRef(value[:i], value[i + 1 :])
        for i, char in enumerate(value)
        if char == "." and value[:i] in clients and value[i + 1 :]
    )
    if found:
        return found
    if value and ("." not in value or value in realm.realm_roles):
        return (RoleRef(None, value),)
    return None


def mapper_unknown(realm: Realm, mapper: Mapper) -> str:
    """Why ``mapper`` is an audience source the realm does not show, or ``""``."""
    if mapper.unknown:
        return mapper.unknown
    return UNKNOWN_ROLE if mapper_roles(realm, mapper) is None else ""


def _resolved(
    realm: Realm,
    client: Client,
    scopes: Sequence[ClientScope],
    add: Callable[[str, str], None],
    prefix: str,
) -> None:
    mappers = [*client.mappers, *(m for s in scopes for m in s.mappers)]
    resolve = next((m for m in mappers if m.kind == AUDIENCE_RESOLVE_MAPPER), None)
    if resolve is None:
        return
    via = f"of client {client.client_id!r} through the audience resolve mapper {resolve.name!r}"
    for ref in sorted(_in_scope(realm, client, scopes)):
        add(str(ref.client), f"client role {ref.client}/{ref.name} in the {prefix}scope {via}")
    for mapper in mappers:
        added = _closure(mapper_roles(realm, mapper) or (), realm.composites)
        for ref in sorted(r for r in added if r.client not in (None, client.client_id)):
            add(
                str(ref.client),
                f"client role {ref.client}/{ref.name} added by the mapper {mapper.name!r} "
                f"in the {prefix}token {via}",
            )


def audiences(realm: Realm) -> dict[str, tuple[str, ...]]:
    """Every audience the realm shows, with the places it comes from.

    A mapper that writes ``aud`` counts wherever it is, whatever its token flags;
    a client role counts as the audience of its client when the role is in the
    scope of another client that reaches an audience resolve mapper (own mapper
    or one of its default or optional client scopes). With ``fullScopeAllowed``
    every client role is in scope. Mappers that write ``aud`` with values the
    realm does not show are in :func:`unknown_audience_sources`.
    """
    found: dict[str, set[str]] = {}

    def add(audience: str, source: str) -> None:
        found.setdefault(audience, set()).add(source)

    for client in realm.clients:
        for mapper in client.mappers:
            for audience in mapper.audience:
                add(audience, f"mapper {mapper.name!r} of client {client.client_id!r}")
    for scope in realm.scopes.values():
        for mapper in scope.mappers:
            for audience in mapper.audience:
                add(audience, f"mapper {mapper.name!r} of client scope {scope.name!r}")
    for client in realm.clients:
        assigned = [
            realm.scopes[s]
            for s in (*client.default_scopes, *client.optional_scopes)
            if s in realm.scopes
        ]
        _resolved(realm, client, assigned, add, "")
    return {a: tuple(sorted(s)) for a, s in sorted(found.items())}


def unknown_audience_sources(realm: Realm) -> tuple[str, ...]:
    """Mappers that may put audiences into a token the realm does not show, each with
    the reason."""
    holders = [(f"client {c.client_id!r}", c.mappers) for c in realm.clients]
    holders += [(f"client scope {s.name!r}", s.mappers) for s in realm.scopes.values()]
    found = [
        f"mapper {m.name!r} of {holder} {reason}"
        for holder, mappers in holders
        for m in mappers
        if (reason := mapper_unknown(realm, m))
    ]
    return tuple(sorted(found))


def default_audiences(realm: Realm, client: Client) -> tuple[dict[str, list[str]], list[str]]:
    """Audiences in a token of ``client`` without any requested scope: its own
    mappers and its default client scopes, client roles in scope from
    ``fullScopeAllowed``, its scope mappings and those of its default scopes.
    The second value lists mappers in reach that write ``aud`` with unknown values.
    ``aud-*`` default scopes are left out; the check reports them by name."""
    defaults = [
        realm.scopes[s]
        for s in client.default_scopes
        if s in realm.scopes and not has_exchange_prefix(s)
    ]
    found: dict[str, list[str]] = {}
    unknown: list[str] = []

    def add(audience: str, source: str) -> None:
        found.setdefault(audience, []).append(source)

    places = [("own mapper", client.mappers)]
    places += [(f"default scope {s.name!r}", s.mappers) for s in defaults]
    for place, mappers in places:
        for mapper in mappers:
            where = (
                f"own mapper {mapper.name!r}"
                if place == "own mapper"
                else f"mapper {mapper.name!r} of {place}"
            )
            for audience in mapper.audience:
                add(audience, where)
            if reason := mapper_unknown(realm, mapper):
                unknown.append(f"{where}, which {reason}")
    _resolved(realm, client, defaults, add, "default ")
    return found, unknown


def _separation(realm: Realm, found: Mapping[str, Sequence[str]]) -> list[str]:
    exchange = exchange_clients(realm)
    problems = [
        f"exchange client {cid!r} is an audience: {'; '.join(found[cid])}"
        for cid in sorted(exchange & found.keys())
        if cid != CHAIN_HOLDER
    ]
    problems += [
        f"client {cid!r} holds token exchange; the module's only exchange client is "
        f"{holder!r} (PLT-11-A1)"
        for cid, holder in sorted(NEVER_EXCHANGE.items())
        if cid in exchange
    ]
    problems += [
        f"{source}; the separation cannot be proven" for source in unknown_audience_sources(realm)
    ]
    if CHAIN_HOLDER not in exchange or CHAIN_HOLDER not in found:
        missing = []
        if CHAIN_HOLDER not in exchange:
            missing.append("has no token exchange")
        if CHAIN_HOLDER not in found:
            missing.append("is no audience")
        problems.append(
            f"expected the intersection {{{CHAIN_HOLDER}}}, but {CHAIN_HOLDER!r} "
            + " and ".join(missing)
        )
    return problems


def _chain_holder(realm: Realm) -> list[str]:
    return [
        f"client {c.client_id!r} carries {CHAIN_HOLDER_ATTRIBUTE}; only {CHAIN_HOLDER!r} may"
        for c in realm.clients
        if c.client_id != CHAIN_HOLDER
        and c.chain_holder is not None
        and c.chain_holder.strip().lower() != "false"
    ]


def _exchange_default_scopes(realm: Realm) -> list[str]:
    problems: list[str] = []
    for client in realm.clients:
        if not client.token_exchange:
            continue
        cid = client.client_id
        if client.full_scope:
            problems.append(
                f"exchange client {cid!r} has fullScopeAllowed (true or missing); "
                "it must be false (PLT-11-A1)"
            )
        problems += [
            f"exchange client {cid!r} has {scope!r} as default scope"
            for scope in client.default_scopes
            if has_exchange_prefix(scope)
        ]
        found, unknown = default_audiences(realm, client)
        problems += [
            f"exchange client {cid!r} has the audience {audience!r} in its default token: "
            + "; ".join(sorted(set(sources)))
            for audience, sources in sorted(found.items())
        ]
        problems += [f"exchange client {cid!r} reaches {source}" for source in unknown]
    return problems


def _never_audience(realm: Realm, found: Mapping[str, Sequence[str]]) -> list[str]:
    problems = [
        f"client {cid!r} is never an audience, but is one: {'; '.join(found[cid])}"
        for cid in NEVER_AUDIENCE
        if cid in found
    ]
    problems += [
        f"{source}; it may name {', '.join(NEVER_AUDIENCE)}"
        for source in unknown_audience_sources(realm)
    ]
    return problems


def _client_policies(realm: Realm) -> list[str]:
    problems: list[str] = []
    for policy in realm.policies:
        if any(c.limiting for c in policy.conditions):
            continue
        shown = (
            ", ".join(f"{c.name} ({c.note})" if c.note else c.name for c in policy.conditions)
            or "none"
        )
        kind = "global client policy" if policy.is_global else "client policy"
        problems.append(
            f"{kind} {policy.name!r} is not limited to named clients or scopes "
            f"(conditions: {shown})"
        )
    return problems


def check_realm(realm: Realm, *, source: str) -> SuiteResult:
    """Run every check of the realm suite; ``source`` names the input in the result."""
    started = time.monotonic()
    found = audiences(realm)
    results = {
        "separation": _separation(realm, found),
        "chain-holder": _chain_holder(realm),
        "exchange-default-scopes": _exchange_default_scopes(realm),
        "never-audience": _never_audience(realm, found),
        "client-policies": _client_policies(realm),
    }
    cases: tuple[Case, ...] = tuple(
        case(SUITE, source, name, results[name]) for name in REALM_CHECKS[1:]
    )
    return SuiteResult(SUITE, cases, time.monotonic() - started)


def check_realm_export_file(path: Path) -> SuiteResult:
    """The realm suite over an export file; an unreadable file reports only ``load``."""
    try:
        realm = load_realm_export(path)
    except RealmError as exc:
        return SuiteResult(SUITE, (case(SUITE, path.name, "load", [str(exc)]),))
    return check_realm(realm, source=realm.name)
