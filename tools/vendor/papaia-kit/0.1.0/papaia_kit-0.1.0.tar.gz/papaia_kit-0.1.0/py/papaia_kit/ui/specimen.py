"""Specimen page ``/_kit/specimen``: contract, expected computed styles, reference page.

``contract/specimen.yaml`` names every element of the specimen page and the
computed styles that ``pk-conform`` reads from it (``contract/specimen.md``).
Expected values come from the token file only: :func:`expected_values` resolves
each ``var(--pk-*)`` for one theme and normalises it with the comparison rule
(colours as sRGB with 8 bits and alpha, lengths in CSS pixels rounded to 0.5,
the first font family in lower case, weights as numbers). The TypeScript side
(``js/src/conform/specimen.ts``) normalises what the browser reports with the
same rule.

:func:`specimen_body` is the kit's reference content of the page, built with
the kit's pattern classes; Jinja2 modules mount it unchanged, React consoles
render their own components with the same ``data-pk-specimen`` hooks.
"""

from __future__ import annotations

import copy
import json
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

import jinja2
import yaml
from markupsafe import Markup

from papaia_kit._resources import contract_dir, tokens_dir
from papaia_kit.ui import formats, messages
from papaia_kit.ui.macros import extend_environment
from papaia_kit.ui.shell import ASSET_ROOT, parse_shell_input, render_shell, shell_environment
from papaia_kit.ui.tokens import THEMES, TokenSet, load_tokens

FORMAT = "papaia.specimen/1"
EXPECTED_FORMAT = "papaia.specimen-expected/1"
STATES = frozenset({"rest", "hover", "focus", "disabled", "invalid"})
COLOR_PROPS = frozenset({"background-color", "color", "border-top-color", "outline-color"})
LENGTH_PROPS = frozenset(
    {
        "font-size",
        "line-height",
        "border-top-left-radius",
        "padding-top",
        "padding-left",
        "outline-width",
        "outline-offset",
    }
)
PROPERTIES = COLOR_PROPS | LENGTH_PROPS | {"font-family", "font-weight", "outline-style", "opacity"}
ROOT_FONT_PX = 16
MAX_FILE_BYTES = 256 * 1024
MAX_NAME = 64
MAX_VALUE = 64
VIEWPORT_MIN, VIEWPORT_MAX = 200, 4000
MAX_VAR_DEPTH = 8
REFERENCE_INPUT = "rs-anna-de-light.json"
# Form token of the reference pages: a fixed sample value, never a token of a running module.
REFERENCE_CSRF = "csrf-reference-input-0001"

_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_VAR = re.compile(r"^var\((--pk-[a-z0-9-]+)\)$")
_VAR_ANY = re.compile(r"var\((--pk-[a-z0-9-]+)\)")
_HEX = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
_RGB = re.compile(
    r"^rgba?\(\s*(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})\s*(?:[,/]\s*([\d.]+%?))?\s*\)$"
)
_LENGTH = re.compile(r"^(-?\d+(?:\.\d+)?)(px|rem)$")
_KEYWORD = re.compile(r"^[a-z-]{1,32}$")
_NUMBER = re.compile(r"^\d+(?:\.\d+)?$")
_SELECTOR = re.compile(r'^[a-z0-9\[\]="\-_. ]{1,120}$')

TEXTS: dict[str, dict[str, str]] = {
    "de": {
        "title": "Musterseite",
        "primary": "Speichern",
        "secondary": "Abbrechen",
        "danger": "Löschen",
        "ghost": "Details",
        "small": "Klein",
        "edit": "Bearbeiten",
        "disabled": "Speichern (gesperrt: keine Änderung)",
        "focus": "Weiter",
        "control_input": "Textfeld",
        "control_select": "Auswahl",
        "control_textarea": "Mehrzeiliger Text",
        "control_checkbox": "Kontrollkästchen",
        "control_radio": "Optionsfeld",
        "state_rest": "in Ruhe",
        "state_hover": "unter dem Zeiger",
        "state_focus": "mit Fokus",
        "state_disabled": "gesperrt",
        "state_invalid": "fehlerhaft",
        "field_error_text": "Prüfen Sie diese Angabe.",
        "option_de": "Deutsch",
        "option_en": "Englisch",
        "table": "Beispieltabelle",
        "col_name": "Name",
        "col_state": "Zustand",
        "col_count": "Anzahl",
        "row1": "Rechnung prüfen",
        "row2": "Urlaubsantrag",
        "row3": "Bericht",
        "state_open": "Offen",
        "state_done": "Erledigt",
        "badge_error": "Gestört",
        "tasks": "Aufgaben",
        "dialog_title": "Änderungen verwerfen?",
        "dialog_text": "Ihre Eingaben auf dieser Seite gehen verloren.",
        "toast_success": "Gespeichert.",
        "toast_info": "Die Liste wurde aktualisiert.",
        "toast_warning": "Das dauert länger als üblich.",
        "toast_error": "Die Daten konnten nicht geladen werden.",
        "toast_deleted": "„Bericht“ wurde gelöscht.",
        "empty": "Hier erscheinen Ihre Aufgaben.",
        "loading": "Wird geladen …",
        "error_what": "Die Daten konnten nicht geladen werden.",
        "error_consequence": "Es wurde nichts geändert.",
        "error_todo": "Versuchen Sie es in einigen Minuten erneut.",
        "error_id": "Kennung:",
        "heading2": "Überschrift der zweiten Ebene",
        "heading3": "Überschrift der dritten Ebene",
        "body": "Fließtext der Musterseite in der Grundschrift.",
        "quote": "Ein Zitat ist eingerückt und am Anfang der Zeile markiert.",
        "link": "Verweis zur Hilfe",
        "code_label": "Kennung im Text:",
        "buttons": "Schaltflächen",
        "fields": "Formular",
        "messages": "Meldungen",
        "states": "Zustände",
        "text": "Text, Datum und Zahl",
        "layout": "Anordnung, Karten und Kacheln",
        "lead": "Einleitender Satz eines Bereichs.",
        "card_title": "Buchhaltung",
        "card_text": "Drei Personen, zwei offene Aufgaben.",
        "card_foot": "Geändert vor zwei Tagen",
        "card_linked": "Vertrieb",
        "tile_purpose": "Abläufe planen und starten.",
        "tile_example": "Rechnungen jeden Montag prüfen.",
        "tile_contact": "Leitung Buchhaltung",
        "lists": "Listen, Kennzeichen und Menü",
        "menu_export": "Als CSV exportieren",
        "dialogs": "Dialoge",
        "confirm_function": "Dokument ablegen",
        "confirm_object": "Rechnung 2026-0042",
        "restore_period": "30 Tage lang",
        "welcome_title": "Willkommen in Mein Bereich",
        "welcome_text": "Hier sehen Sie Ihre Aufgaben und Erinnerungen.",
    },
    "en": {
        "title": "Specimen",
        "primary": "Save",
        "secondary": "Cancel",
        "danger": "Delete",
        "ghost": "Details",
        "small": "Small",
        "edit": "Edit",
        "disabled": "Save (locked: no change)",
        "focus": "Next",
        "control_input": "Text field",
        "control_select": "Choice",
        "control_textarea": "Multi-line text",
        "control_checkbox": "Checkbox",
        "control_radio": "Radio button",
        "state_rest": "at rest",
        "state_hover": "under the pointer",
        "state_focus": "with focus",
        "state_disabled": "locked",
        "state_invalid": "invalid",
        "field_error_text": "Check this entry.",
        "option_de": "German",
        "option_en": "English",
        "table": "Sample table",
        "col_name": "Name",
        "col_state": "State",
        "col_count": "Count",
        "row1": "Check invoice",
        "row2": "Leave request",
        "row3": "Report",
        "state_open": "Open",
        "state_done": "Done",
        "badge_error": "Disrupted",
        "tasks": "Tasks",
        "dialog_title": "Discard changes?",
        "dialog_text": "Your entries on this page will be lost.",
        "toast_success": "Saved.",
        "toast_info": "The list was updated.",
        "toast_warning": "This is taking longer than usual.",
        "toast_error": "The data could not be loaded.",
        "toast_deleted": "\u201cReport\u201d was deleted.",
        "empty": "Your tasks appear here.",
        "loading": "Loading …",
        "error_what": "The data could not be loaded.",
        "error_consequence": "Nothing was changed.",
        "error_todo": "Try again in a few minutes.",
        "error_id": "ID:",
        "heading2": "Second level heading",
        "heading3": "Third level heading",
        "body": "Body text of the specimen page in the base font.",
        "quote": "A quote is indented and marked at the start of the line.",
        "link": "Link to the help",
        "code_label": "ID in the text:",
        "buttons": "Buttons",
        "fields": "Form",
        "messages": "Messages",
        "states": "States",
        "text": "Text, date and number",
        "layout": "Layout, cards and tiles",
        "lead": "Leading sentence of a section.",
        "card_title": "Accounting",
        "card_text": "Three people, two open tasks.",
        "card_foot": "Changed two days ago",
        "card_linked": "Sales",
        "tile_purpose": "Plan and start workflows.",
        "tile_example": "Check invoices every Monday.",
        "tile_contact": "Head of accounting",
        "lists": "Lists, badges and menu",
        "menu_export": "Export as CSV",
        "dialogs": "Dialogs",
        "confirm_function": "File document",
        "confirm_object": "Invoice 2026-0042",
        "restore_period": "30 days",
        "welcome_title": "Welcome to My area",
        "welcome_text": "Here you see your tasks and reminders.",
    },
}


class SpecimenError(ValueError):
    """The specimen contract or a request for the reference page is not valid."""


@dataclass(frozen=True)
class SpecimenElement:
    name: str
    state: str
    selector: str
    expect: Mapping[str, str]


@dataclass(frozen=True)
class Specimen:
    tools: Mapping[str, str]
    viewports: Mapping[str, Mapping[str, int]]
    elements: tuple[SpecimenElement, ...]


# --- contract ---------------------------------------------------------------------


def load_specimen(path: Path | None = None, tokens: TokenSet | None = None) -> Specimen:
    """Read ``contract/specimen.yaml`` (or ``path``) strictly."""
    source = path or contract_dir() / "specimen.yaml"
    raw = source.read_bytes()
    if len(raw) > MAX_FILE_BYTES:
        raise SpecimenError(f"{source.name}: larger than {MAX_FILE_BYTES} bytes")
    return parse_specimen(
        yaml.safe_load(raw.decode("utf-8")),
        tokens or load_tokens(tokens_dir() / "papaia.tokens.json"),
    )


def _keys(where: str, data: object, required: set[str], optional: frozenset[str]) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise SpecimenError(f"{where}: expected a mapping")
    unknown = set(data) - required - optional
    if unknown:
        raise SpecimenError(f"{where}: unknown field {sorted(map(str, unknown))[0]!r}")
    missing = required - set(data)
    if missing:
        raise SpecimenError(f"{where}: missing field {sorted(missing)[0]!r}")
    return data


def parse_specimen(doc: object, tokens: TokenSet) -> Specimen:
    """Check a decoded specimen contract against its format and the token names."""
    data = _keys("specimen", doc, {"format", "tools", "viewports", "elements"}, frozenset())
    if data["format"] != FORMAT:
        raise SpecimenError(f"specimen: format must be {FORMAT!r}")
    tools = _keys("tools", data["tools"], {"playwright", "axe_core"}, frozenset())
    for key, value in tools.items():
        if not isinstance(value, str) or not re.fullmatch(r"\d{1,4}\.\d{1,4}\.\d{1,4}", value):
            raise SpecimenError(f"tools/{key}: expected an exact version x.y.z")
    viewports = _keys("viewports", data["viewports"], {"desktop", "narrow"}, frozenset())
    for key, value in viewports.items():
        size = _keys(f"viewports/{key}", value, {"width", "height"}, frozenset())
        if not all(isinstance(v, int) and VIEWPORT_MIN <= v <= VIEWPORT_MAX for v in size.values()):
            raise SpecimenError(f"viewports/{key}: width and height between 200 and 4000")
    if not isinstance(data["elements"], list) or not data["elements"]:
        raise SpecimenError("elements: expected a non-empty list")
    known = _all_variables(tokens)
    elements: list[SpecimenElement] = []
    for index, item in enumerate(data["elements"]):
        element = _element(f"elements/{index}", item, known)
        if any(e.name == element.name for e in elements):
            raise SpecimenError(f"elements/{index}: duplicate element {element.name!r}")
        elements.append(element)
    return Specimen(tools=dict(tools), viewports=dict(viewports), elements=tuple(elements))


def _element(where: str, item: object, known: set[str]) -> SpecimenElement:
    entry = _keys(where, item, {"name", "state", "expect"}, frozenset({"selector"}))
    name = entry["name"]
    if not isinstance(name, str) or not _NAME.fullmatch(name) or len(name) > MAX_NAME:
        raise SpecimenError(f"{where}: name must be lower-case words joined by '-'")
    if entry["state"] not in STATES:
        raise SpecimenError(f"{where}: state must be one of {sorted(STATES)}")
    selector = entry.get("selector", f'[data-pk-specimen="{name}"]')
    if not isinstance(selector, str) or not _SELECTOR.fullmatch(selector):
        raise SpecimenError(f"{where}: selector has characters outside the allowed set")
    expect = entry["expect"]
    if not isinstance(expect, dict):
        raise SpecimenError(f"{where}/expect: expected a mapping")
    for prop, value in expect.items():
        if prop not in PROPERTIES:
            raise SpecimenError(f"{where}/expect: property {prop!r} is not read")
        if not isinstance(value, str) or len(value) > MAX_VALUE:
            raise SpecimenError(f"{where}/expect/{prop}: expected a short string")
        ref = _VAR.fullmatch(value)
        if ref and ref.group(1) not in known:
            raise SpecimenError(f"{where}/expect/{prop}: unknown variable {ref.group(1)}")
        if not ref:
            normalize_value(prop, value)
    return SpecimenElement(name, entry["state"], selector, dict(expect))


def _all_variables(tokens: TokenSet) -> set[str]:
    names = set(tokens.shared)
    for theme in tokens.themes.values():
        names |= set(theme.variables)
    return names


# --- comparison rule --------------------------------------------------------------


def _round_half(value: float) -> str:
    rounded = math.floor(value * 2 + 0.5) / 2
    return f"{int(rounded)}" if rounded == int(rounded) else f"{rounded}"


def _alpha(raw: str | None) -> float:
    if raw is None:
        return 1.0
    value = float(raw[:-1]) / 100 if raw.endswith("%") else float(raw)
    return round(min(max(value, 0.0), 1.0), 2)


def normalize_color(raw: str) -> str | None:
    """``rgba(r,g,b,a)`` for a hex or ``rgb()`` colour or ``transparent``; else ``None``."""
    text = raw.strip().lower()
    if text == "transparent":
        return "rgba(0,0,0,0)"
    hexa = _HEX.fullmatch(text)
    if hexa:
        digits = hexa.group(1)
        if len(digits) == 3:  # noqa: PLR2004 - short hex form #rgb
            digits = "".join(c * 2 for c in digits)
        r, g, b = (int(digits[i : i + 2], 16) for i in (0, 2, 4))
        return f"rgba({r},{g},{b},1)"
    rgb = _RGB.fullmatch(text)
    if rgb:
        r, g, b = (min(int(rgb.group(i)), 255) for i in (1, 2, 3))
        return f"rgba({r},{g},{b},{_number(_alpha(rgb.group(4)))})"
    return None


def _number(value: float) -> str:
    return f"{int(value)}" if value == int(value) else f"{value:g}"


def normalize_length(raw: str) -> str | None:
    match = _LENGTH.fullmatch(raw.strip())
    if not match:
        return None
    value = float(match.group(1)) * (ROOT_FONT_PX if match.group(2) == "rem" else 1)
    return f"{_round_half(value)}px"


def first_family(raw: str) -> str:
    return raw.split(",", 1)[0].strip().strip("\"'").lower()


def normalize_value(prop: str, raw: str) -> str:
    """Normalise one expected value with the comparison rule; refuses what it cannot read."""
    if prop in COLOR_PROPS:
        color = normalize_color(raw)
        if color is None:
            raise SpecimenError(f"{prop}: {raw!r} is not a colour")
        return color
    if prop in LENGTH_PROPS:
        length = normalize_length(raw)
        if length is None:
            raise SpecimenError(f"{prop}: {raw!r} is not a length in px or rem")
        return length
    if prop == "font-family":
        family = first_family(raw)
        if not family:
            raise SpecimenError("font-family: empty")
        return family
    if prop == "font-weight":
        if not re.fullmatch(r"[1-9]00", raw):
            raise SpecimenError(f"font-weight: {raw!r} is not a weight 100-900")
        return raw
    if prop == "opacity":
        if not _NUMBER.fullmatch(raw) or float(raw) > 1:
            raise SpecimenError(f"opacity: {raw!r} is not a number between 0 and 1")
        return _number(round(float(raw), 2))
    if not _KEYWORD.fullmatch(raw):
        raise SpecimenError(f"{prop}: {raw!r} is not a keyword")
    return raw


def normalize_token(name: str, raw: str) -> str:
    """Normalise a custom property value the way ``pk-conform`` reads ``:root``."""
    text = " ".join(raw.split())
    if name.startswith("--pk-font-"):
        return first_family(text)
    return normalize_color(text) or normalize_length(text) or text


def _variables(tokens: TokenSet, theme: str) -> dict[str, str]:
    merged = {**tokens.shared, **tokens.themes[theme].variables}
    resolved: dict[str, str] = {}

    def resolve(name: str, depth: int = 0) -> str:
        if depth > MAX_VAR_DEPTH:
            raise SpecimenError(f"{name}: variable references nest too deep")
        if name not in merged:
            raise SpecimenError(f"unknown variable {name}")
        return _VAR_ANY.sub(lambda m: resolve(m.group(1), depth + 1), merged[name])

    for name in merged:
        resolved[name] = resolve(name)
    return resolved


def expected_values(spec: Specimen, tokens: TokenSet, theme: str) -> dict[str, Any]:
    """Expected computed styles and ``:root`` variables of the specimen page for ``theme``."""
    if theme not in THEMES:
        raise SpecimenError(f"theme must be one of {list(THEMES)}")
    variables = _variables(tokens, theme)
    elements: dict[str, dict[str, str]] = {}
    for element in spec.elements:
        values: dict[str, str] = {}
        for prop, value in sorted(element.expect.items()):
            ref = _VAR.fullmatch(value)
            values[prop] = normalize_value(prop, variables[ref.group(1)] if ref else value)
        elements[element.name] = values
    return {
        "format": EXPECTED_FORMAT,
        "theme": theme,
        "tools": dict(spec.tools),
        "viewports": {k: dict(v) for k, v in spec.viewports.items()},
        "states": {e.name: e.state for e in spec.elements},
        "selectors": {e.name: e.selector for e in spec.elements},
        "elements": elements,
        "tokens": {n: normalize_token(n, v) for n, v in sorted(variables.items())},
    }


def expected_text(spec: Specimen, tokens: TokenSet, theme: str) -> str:
    return json.dumps(expected_values(spec, tokens, theme), indent=2, ensure_ascii=False) + "\n"


# --- reference page ---------------------------------------------------------------


def _texts(lang: str) -> dict[str, str]:
    if lang not in TEXTS:
        raise SpecimenError(f"lang must be one of {sorted(TEXTS)}")
    return TEXTS[lang]


def specimen_body(lang: str) -> Markup:
    """Reference content of ``/_kit/specimen`` (inside ``main``), autoescaped."""
    moment = formats.format_moment(
        datetime.fromisoformat("2026-03-07T14:05:00+01:00"),
        kind="due",
        lang=lang,
        time_zone="Europe/Berlin",
    )
    module = (
        reference_environment()
        .get_template("pk/specimen.html")
        .make_module({"pk_lang": lang, "pk_csrf": REFERENCE_CSRF})
    )
    body: Markup = module.specimen(  # type: ignore[attr-defined]
        _texts(lang),
        moment,
        formats.format_number("1234567.5", lang),
        f"{ASSET_ROOT}/icons/sprite.svg",
        messages.load_texts("patterns", lang),
    )
    return body


def reference_environment() -> jinja2.Environment:
    """Environment of the kit's reference pages: kit templates and the component macros."""
    env = shell_environment()
    extend_environment(env)
    return env


class _Hooks(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.names: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        for key, value in attrs:
            if key == "data-pk-specimen" and value:
                self.names.append(value)


def check_specimen_markup(html: str, spec: Specimen) -> list[str]:
    """Problems of a specimen page's markup: hooks missing, doubled or unknown."""
    parser = _Hooks()
    parser.feed(html)
    parser.close()
    # An element is hooked when its selector starts at its own hook (a section with the
    # component inside); the others are found inside the hook of another element.
    hooked = {
        e.name for e in spec.elements if e.selector.startswith(f'[data-pk-specimen="{e.name}"]')
    }
    problems = [f"missing: {n}" for n in sorted(hooked) if n not in parser.names]
    problems += [f"more than once: {n}" for n in sorted(hooked) if parser.names.count(n) > 1]
    names = {e.name for e in spec.elements}
    problems += [f"unknown: {n}" for n in sorted(set(parser.names) - names)]
    return problems


def specimen_page(*, module: str, lang: str, theme: str) -> str:
    """The whole reference document of ``/_kit/specimen`` for one module, language and theme.

    Built from the reference input of the kit (catalog of the reference stack,
    test branding of ``contract/shell/inputs/branding/``); used to produce the
    reference images in a kit release and by the browser self test.
    """
    texts = _texts(lang)
    if theme not in THEMES:
        raise SpecimenError(f"theme must be one of {list(THEMES)}")
    base = json.loads(
        (contract_dir() / "shell" / "inputs" / REFERENCE_INPUT).read_text(encoding="utf-8")
    )
    surfaces = {
        ui["id"]: ui for service in base["catalog"]["services"] for ui in service.get("ui", [])
    }
    if module not in surfaces or surfaces[module].get("opens_in") == "new_tab":
        shown = sorted(k for k, v in surfaces.items() if v.get("opens_in") != "new_tab")
        raise SpecimenError(f"module must be one of {shown}")
    doc = copy.deepcopy(base)
    surface = surfaces[module]
    doc["module"] = {"id": module, "title": surface["title"], "icon": surface["icon"]}
    doc.update(locale=lang, theme=theme)
    doc["page"] = {"title": texts["title"]}
    doc["nav"] = {"current": "/_kit/specimen", "groups": []}
    return render_shell(parse_shell_input(doc), specimen_body(lang))
