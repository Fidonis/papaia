# papaia-kit

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

Shared contract package of the papaia platform. Every module, add-on and server
reads the contract from here instead of keeping its own copy: schemas, readers
and writers for the shared formats, the license policy and the conformance
checks that run in each repository's CI.

The kit is a library. It runs no service of its own.

## Install

The kit is not on a package index. Every release `vX.Y.Z` on the releases page
of this repository carries these files (built by `make release`, see "Building
a release"):

| File | Content |
|---|---|
| `papaia_kit-<version>-py3-none-any.whl` | Python package with the command line tools `papaia-kit`, `pk-words`, `pk-check` |
| `papaia_kit-<version>.tar.gz` | Python source distribution, also the source of `contract/` for the browser checks |
| `papaia-kit-<version>.tgz` | npm package `@papaia/kit` with `pk-conform` and `pk-audit` |
| `papaia-kit-refimg-<version>.tar.gz` | Reference images of the release for `pk-conform` (`refimg/`) |
| `SHA256SUMS` | sha256 of the four files above |
| `kit.lock` | Version, commit and sha256 of the files, for consumers |

Download the files of one release into `vendor/papaia-kit/<version>/` and
check them before use:

```sh
cd vendor/papaia-kit/0.1.0
sha256sum -c SHA256SUMS            # macOS: shasum -a 256 -c SHA256SUMS
```

Python: bind the wheel as a path source, lock it and keep `kit.lock` next to
`pyproject.toml`. `uv.lock` then carries the same sha256 as `SHA256SUMS`.

```toml
[project]
dependencies = ["papaia-kit==0.1.0"]

[tool.uv.sources]
papaia-kit = { path = "vendor/papaia-kit/0.1.0/papaia_kit-0.1.0-py3-none-any.whl" }
```

```sh
uv lock && uv sync --locked
```

Browser checks: unpack the npm package outside `node_modules` (see "UI
conformance") and build the folder for `--kit-dir` from `contract/` of the
source distribution and the reference images:

```sh
mkdir -p .pk/kit
tar -xzf vendor/papaia-kit/0.1.0/papaia-kit-0.1.0.tgz -C .pk
tar -xzf vendor/papaia-kit/0.1.0/papaia_kit-0.1.0.tar.gz -C .pk/kit --strip-components=1 papaia_kit-0.1.0/contract
tar -xzf vendor/papaia-kit/0.1.0/papaia-kit-refimg-0.1.0.tar.gz -C .pk/kit
node .pk/package/bin/pk-conform.ts --kit-dir .pk/kit --base-url http://127.0.0.1:<port> --module me
```

`pk-conform` needs `playwright-core` and `axe-core` in the versions of
`contract/specimen.yaml` next to the package (`.pk/node_modules`).

## Layout

| Path | Content |
|---|---|
| `schemas/` | Contract schemas (JSON Schema 2020-12), see `schemas/README.md` |
| `policy/` | License policy shared by all repositories |
| `py/papaia_kit/` | Python package `papaia-kit` |
| `js/` | TypeScript package `@papaia/kit` for user interfaces |
| `contract/` | Normative prose accompanying the schemas |
| `glossary/` | Glossary binding for user-facing texts |
| `tokens/` | Design tokens (one source of all values), see `tokens/README.md` |
| `ui/` | Hand-written sources of the shell stylesheet and script (`shell.css`, `shell.js`), the edge pages (`edge.css`), the mail templates (`mail/`) and the login theme (`keycloak/`) |
| `dist/` | Files generated from `tokens/` and `ui/` (stylesheets, shell script, Tailwind preset, fonts, icons, proxy and signed-out pages, mail templates, login theme); never edited by hand |
| `tools/` | `build.py`, the generator of `dist/` |
| `testing/` | Test doubles, fixtures and shared test vectors (`testing/vectors/`) |
| `probe-addon/` | Probe add-on: small MCP server proving the contract end to end, see `probe-addon/README.md` |

Python subpackages: `catalog`, `exchange`, `authz`, `audit`, `erasure`,
`errors`, `assertion`, `conformance`, `halt`, `names`, `tasks`, `ui`, plus `licenses`
and `repo` for the repository checks below.

`papaia_kit.data_classes` reads the one data class scale
(`schemas/data-classes.json`) and compares classes by their order; see
`contract/data-classes.md`.

## Audit format and correlation id

Every write, send or delete produces one `papaia.audit/1` event that carries the
request's correlation id. The format is `schemas/audit.v1.schema.json`, the rules
are in `contract/audit.md`:

```python
from papaia_kit.audit import validate_event
from papaia_kit.correlation import correlation_headers, correlation_id_from_headers

correlation_id = correlation_id_from_headers(request.headers)  # keeps or replaces
outgoing = correlation_headers(correlation_id)  # for every follow-up call
validate_event(event)  # raises AuditEventError naming fields, never values
```

## Meine Aufgaben

Flow, Data and Studio serve the tasks of a person at `GET /api/v1/me/tasks`
and `GET /api/v1/me/tasks/summary` in `papaia.task-item/1`
(`schemas/task-item.v1.schema.json`). `papaia_kit.tasks.collect()` is the one
place that merges them, so every module shows the same list and count. Rules
and fields are in `contract/tasks.md`.

```python
from papaia_kit import tasks as pk_tasks

result = pk_tasks.collect(
    person_token, catalog=catalog, exchange=exchange_client, correlation_id=correlation_id
)
result.tasks  # sorted by due date, items without one last
result.count  # number for the counter
result.hints()  # "Flow ist gerade nicht erreichbar. ..." per unavailable source
```

A module passes its own tasks as `LocalSource` instead of calling itself. Only
the two task routes are called, each with a token exchanged for that source's
audience; nothing is cached between calls.

## Audit writer

`papaia_kit.audit.writer.AuditWriter` writes each event into the source's
outbox table `audit_outbox`, in the caller's own transaction, and a delivery
loop sends the outbox in order to `papaia-audit` over mutual TLS. Rows are
deleted only after `papaia-audit` acknowledged them. There is no read route:
events are read only from `papaia-audit`. Details and the ingest format are in
`contract/audit.md` ("Writer and ingest").

```python
import threading
from papaia_kit.audit.transport import HttpsIngestTransport
from papaia_kit.audit.writer import AuditWriter

transport = HttpsIngestTransport(
    cert_file="/run/secrets/audit-client.crt",  # client certificate of the platform PKI
    key_file="/run/secrets/audit-client.key",
    ca_file="/run/secrets/platform-ca.crt",
)  # https://papaia-audit:8443/v1/ingest by default; http:// is refused
writer = AuditWriter(pool.connection, transport, dialect="postgres")
writer.ensure_schema()  # or run papaia_kit.audit.outbox.outbox_ddl("postgres") in a migration

with pool.connection() as conn:  # the transaction of the effect
    apply_the_change(conn)
    writer.write(conn, event)  # same transaction; returns source_seq

stop = threading.Event()
threading.Thread(target=writer.run, args=(stop,), daemon=True).start()
```

For asyncio applications (FastAPI) use `AsyncAuditWriter` with an async
connection (psycopg `AsyncConnection`, aiosqlite) and
`ThreadedIngestTransport(transport)`; start `writer.run(stop)` as a task in the
lifespan handler and set `stop` on shutdown.

A source without a database of its own (an MCP server in front of a remote
service) keeps the outbox in a SQLite file on a persistent volume and writes
each row in a transaction of its own, right after the remote call returns:

```python
from papaia_kit.audit.writer import FileAuditWriter

writer = FileAuditWriter("/var/lib/mcp-paperless/audit/outbox.sqlite3", transport)
principal = chain.check(token, request)
result = call_the_remote_service()
writer.record({**row_of_the_operation, **principal.audit_fields()})  # committed on return
```

`principal.audit_fields()` adds the token times `token_iat`,
`token_auth_time` and `token_remaining_s` to the server's row, never the
token. An asyncio server calls `record` through `asyncio.to_thread`.

The `postgres` dialect works with psycopg 3 (sync and async) and psycopg2;
`sqlite` with `sqlite3` and aiosqlite. `write` locks the source's counter row
until the caller's transaction ends, so keep transactions that write audit
rows short.

## Development

Requirements: [uv](https://docs.astral.sh/uv/) and Node.js 22 or later.

```sh
make bootstrap   # uv sync --locked, npm ci
make lint        # ruff, mypy, yamllint, shellcheck, typecheck, wording, licenses, tokens
make test        # pytest, node --test
make release TAG=vX.Y.Z REGISTRY=/abs/path REFIMG=/abs/path/refimg   # see "Building a release"
```

## Design tokens

`tokens/papaia.tokens.json` holds every colour, radius, font and layout value
of the user interfaces, in both themes, with the values of the manager. Modules
include `dist/css/papaia-kit.css` (or use `dist/tailwind/preset.cjs`) and ship
the fonts and the icon sprite from `dist/`; nothing is loaded from another
host. Details, names and the media register are in `tokens/README.md`.

```sh
make tokens                                   # regenerate dist/ after a change in tokens/
make check-tokens                             # dist/ current, contrast pairs pass
uv run --locked papaia-kit tokens contrast    # WCAG contrast of tokens/contrast-pairs.yaml
```

```python
from papaia_kit import tokens_dir, ui_dist_dir
from papaia_kit.ui.tokens import load_tokens

tokens = load_tokens(tokens_dir() / "papaia.tokens.json")
tokens.themes["dark"].variables["--pk-color-primary"]  # "#2b6fa8"
css = ui_dist_dir() / "css" / "papaia-kit.css"
```

## Shell

Every module serves its HTML documents with the same frame: brand, module
switcher, navigation, footer with account menu and page header. The markup
contract, the measures and the reference inputs are in
`contract/shell/shell.md`; `contract/shell/expected/` holds the normalised
reference outputs (`contract/shell/normalize.md`).

```python
from markupsafe import Markup
from papaia_kit.ui import parse_shell_input, render_shell

shell_input = parse_shell_input(request_json)  # rejects unknown fields and unsafe links
html = render_shell(shell_input, Markup(page_body))  # a plain str is escaped
```

Jinja2 modules import the macro instead: build the environment with
`shell_environment(own_loader)` and write
`{% from "pk/shell.html" import shell %}{% call shell(pk) %}…{% endcall %}`
with `pk = shell_context(shell_input)`. The page loads
`/_kit/<version>/css/papaia-kit.css` and `/_kit/<version>/js/shell.js` from
`dist/`; the shell works without the script.

The appearance switch in the footer names the action, the appearance it turns
on: „Dunkler Modus“ / “Dark mode” while the light appearance shows, „Heller
Modus“ / “Light mode” while the dark one shows. The server renders it from the
stored choice; when the person follows the system setting, `shell.js` sets
label, symbol and value from `prefers-color-scheme` on load and on change. A
console with its own switch follows the same rule; `pk-conform --design`
reports a switch that names the appearance already shown (`appearance-label`).
Below 1024 px the menu button „Menü“ / “Menu” with the menu symbol opens the
navigation.

React consoles additionally load `/_kit/<version>/js/theme-sync.js`: the footer
button switches `data-theme` at once and writes the setting through
`POST /_kit/appearance` in the background (on failure the form is posted the
plain way); when the tab shows again, a new `pk_ui` cookie from another module
applies the appearance and fires the window event `pk:preferences` with
`{appearance, locale}`. `window.pkTheme.apply("dark")` switches the view after
the console changed the setting through its own server.

```sh
uv run --locked papaia-kit shell render --input contract/shell/inputs/rs-anna-de-light.json
uv run --locked papaia-kit shell normalize page.html
uv run --locked papaia-kit shell expected --check   # expected/ current for every input
```

### Language, appearance and time zone

The values come from the core service `prefs` only (`GET`/`PUT
/api/v1/preferences/me`, audience `papaia-prefs`); the token claims `locale`
and `zoneinfo` are not a source. `papaia_kit.ui.prefs` keeps them in the
module's session and renders them into the first byte of every document:

```python
from papaia_kit.ui import prefs

client = prefs.PreferencesClient("http://prefs:8080")

# At login, with the person's token for papaia-prefs:
prefs.load_on_login(session, client, prefs_token, correlation_id=cid)

# Every HTML document: reload first when pk_ui names another etag.
values = prefs.current_preferences(
    session, request.headers.get("cookie"), client=client, token=prefs_token, correlation_id=cid
)
view = prefs.rendering(values, accept_language=request.headers.get("accept-language"))
shell_input = parse_shell_input({**document, **view.shell_fields()})
# view.time_zone goes to format_moment(); "system" renders without data-theme.

# POST /_kit/appearance (after the module's CSRF and session checks):
result = prefs.write_preferences(
    session,
    client,
    prefs_token,
    prefs.appearance_change(form["appearance"]),
    sub=sub,
    azp="papaia-flow",
    writer="flow/web",
    audit=audit_sink,
    correlation_id=cid,
    domain="example.test",
)
response.headers["Set-Cookie"] = result.set_cookie
response.headers["Location"] = prefs.return_target(
    request.headers.get("referer"), origin="https://flow.example.test"
)  # with status 303
```

- `prefs_token` is a callable that returns the person's token for
  `papaia-prefs` (token exchange); it is called only when a request is sent.
- `pk_ui` (`<appearance>.<locale>.<etag>`, `Domain=<domain>`, `Path=/`,
  `Secure`, `SameSite=Lax`, no `Max-Age`) only signals a change; the values
  always come from `prefs`. An unreadable cookie is ignored.
- `locale = browser` resolves `Accept-Language` to `de` or `en` (highest
  weight, earlier entry on a tie), default `de`.
- `write_preferences` checks the change (only `locale`, `appearance`,
  `time_zone` and the own `welcome_seen` key, derived from `azp`
  `papaia-<surface>`), sends it with `If-Match`, retries once after `412` with
  the reloaded etag, and hands exactly one `papaia.audit/1` row (`operation`,
  `role: caller`, field names in `detail.objects`, never values) to `audit`.
  Refusals raise `PreferencesError` with error class and kit code.
- `welcome_change("flow", now)` marks the welcome hint of the own surface as
  seen (RE-44); `language_change()` takes `browser`, `de` or `en`,
  `appearance_change()` `light` or `dark`.
- `return_target()` returns the path of a same-origin `Referer`, else `/`.

The rights check stays the module's and `prefs`' own: the kit sends the
person's token and never decides who may write.

## Edge pages, mail and login theme

Pages outside the shell and the notification mail look and read like the
product (interface spec 2.3, 2.4, 3.5, 7; PLT-29, PLT-73, PLT-78):

| Generated file | Use |
|---|---|
| `dist/proxy/{404,503}.{de,en}.html` | Proxy pages for "not set up" and "not reachable": one embedded stylesheet with the kit values, no script, nothing from another host, no text of the proxy product. The core fills name and logo of the installation (and on 503 the link to My area) when it renders the catalog; the proxy picks the language from `Accept-Language`, default German. |
| `dist/signed-out.{de,en}.html` | The page `/_kit/signed-out` each module serves after signing out: no frame, no data, the fixed sentence and "Erneut anmelden" (link to `/`). |
| `dist/mail/notification.{html,txt}.j2` | Notification mail: sender name `<installation>` for every module, subject `<kind>: <title>` with the kinds `Erinnerung`/`Aufgabe` only, first line `Aus <module>`, one link to the object, footer with reason, module and the link to the notifications in My area. |
| `dist/keycloak/papaia/login/` | Login theme `papaia`: `theme.properties` (parent `keycloak.v2`) and `resources/css/papaia-login.css`, which maps the kit tokens onto the parent theme's variables; follows the system appearance. |

```python
from papaia_kit.ui import edge, mail

html = edge.fill_edge_page(page_html, name="Musterfirma", logo=logo_bytes, my_area_url=me_url)
style_src = edge.csp_style_source(html)  # 'sha256-…' for style-src, no unsafe-inline

notification = mail.render_notification(
    {
        "lang": "de",
        "kind": "task",
        "title": "Urlaubsantrag Cem",
        "module": "Flow",
        "installation": "Musterfirma",
        "object_url": task_url,
        "notifications_url": me_notifications,
    }
)
notification.sender_name, notification.subject, notification.text, notification.html
```

Every value is checked at the boundary: unknown fields, line breaks or hidden
characters in single-line fields (header injection), addresses other than
https or with credentials, and logos other than PNG or SVG without script are
refused. The fixed texts are in `contract/messages/{edge,mail}.{de,en}.yaml`;
reference cases in `contract/edge/` and `contract/mail/`. Sending the mail is
the core's mail outbound, not part of the kit.

## Patterns, formats and fixed texts

The nine patterns (table, form, saved, write into an integration, destructive
action, empty, loading, error message, date/time/number) are described in
`contract/patterns/README.md`, with example markup per state and language in
`contract/patterns/examples/` and their classes in `dist/css/patterns.css`
(layer `pk.patterns` of `papaia-kit.css`; source `tokens/patterns.css`). The
fixed texts of the patterns and of the five states (not installed, stopped,
no access, not found, session expired) are in
`contract/messages/{patterns,states}.{de,en}.yaml`. The undo window is 15 s in
every module (`papaia_kit.ui.messages.UNDO_WINDOW_S`, equal to the validity of
`undo_token`).

```python
from papaia_kit.ui import formats, messages

moment = formats.format_moment(due_at, kind="due", lang="de", time_zone="Europe/Berlin")
moment.text  # "Sa., 07.03.2026, 14:05"
formats.moment_html(moment)  # weekday in <span data-pk-weekday>, then <time>
formats.format_number("1234567.5", "en")  # "1,234,567.5"
messages.text("states", "de", "stopped.text", module="Data")
messages.no_access_texts("en", module="Flow", contact=None)
```

Pattern 9 uses fixed patterns and the kit's own month list from
`contract/vectors/formats.json`; the TypeScript binding (`formatMoment`,
`formatNumber`, `momentHtml` of `@papaia/kit`) runs the same vectors. Time zones
come from the system time zone database of the image.

```sh
uv run --locked papaia-kit messages check                 # the kit's message files
uv run --locked papaia-kit messages check --dir messages  # a module's message files
```

## TypeScript package

`js/` is the npm package `@papaia/kit` for React consoles. It carries the same
helpers as the Python package and runs the same vectors
(`contract/vectors/`); `tests/test_ts_parity.py` compares both outputs.

```ts
import { readCatalog, resolveFrom, visibleModules } from "@papaia/kit";

const catalog = readCatalog(catalogJson);  // checks ui[] strictly, throws CatalogShapeError
const switcher = visibleModules(catalog, idTokenClaims.roles);
const back = resolveFrom(catalog, new URLSearchParams(location.search).get("from"));
// back?.url, back?.title.de -> breadcrumb "Zurück zu <title>"; null: no breadcrumb
// back?.running === false: the module is stopped, show the locked link
```

The package ships TypeScript sources (`exports` points to `src/index.ts`, imports
inside carry `.ts` extensions): consumers build with a bundler and
`allowImportingTsExtensions`, as the Vite templates do. Visibility is display
only; every module checks rights server-side.

```sh
cd js && npm run typecheck && npm test
```

## UI conformance

Every module serves the specimen page `/_kit/specimen` and runs two checks of
the kit in its CI, normative in `contract/specimen.md`:

- `pk-conform` (Playwright): computed styles of every specimen element and the
  `--pk-*` variables of `:root` against `contract/specimen-expected.<theme>.json`
  (comparison rule: sRGB channels within 1, lengths to 0.5 px, first font
  family, weight as number), landmarks, page title, shell zones and widths,
  `<meta name="papaia-kit">`, no horizontal scrolling at 320 px, and the zones
  against the reference images of the kit release (at most 0.5 % differing
  pixels).
- `pk-audit` (axe-core): no `critical` or `serious` violation of WCAG 2.1 A/AA
  on the given pages, both themes, at rest and with menus or dialog open;
  every other violation listed with a ticket in the module's `a11y-known.yaml`.
- `pk-conform --design` (visual quality gate, `contract/design-review.md`) on
  any page of the module, both themes, at 1440 × 900 and 390 × 844: no text in
  a font outside the kit's, vertical gaps between siblings in `#pk-main` only
  in multiples of 0.25rem, no two interactive elements closer than 8 px, at
  most one primary button in `page-header`, paragraph lines of at most 80
  characters, no text squeezed into a sliver narrower than 120 px, no outline
  without focus, no horizontal scroll at 320 px, and the axe run of `pk-audit`.

The composed reference pages `contract/examples/pages/{overview,settings,list,state,data}.{de,en}.html`
show how a real page looks; they are rendered from the macros with the test
branding and synthetic data and are the visual target of a module pull request
(review list in `contract/design-review.md`).

Playwright and axe-core versions are pinned in `contract/specimen.yaml`; the
module installs exactly these (`playwright-core`, `axe-core`) and runs inside
the Playwright container of the same version. The kit's TypeScript sources run
with Node 22 type stripping, which Node refuses below `node_modules`, so the
module unpacks the vendored package outside it; `.pk/kit` holds `contract/`
and `refimg/` of the release (see "Install"):

```sh
mkdir -p .pk && tar -xzf vendor/papaia-kit/<v>/papaia-kit-<v>.tgz -C .pk
node .pk/package/bin/pk-conform.ts --base-url http://127.0.0.1:<port> --module me \
  --storage-state signed-in.json --kit-dir .pk/kit --report conform.json
node .pk/package/bin/pk-audit.ts --base-url http://127.0.0.1:<port> --page / --page /help \
  --page /_kit/specimen --known a11y-known.yaml --storage-state signed-in.json --report audit.json
```

A module's CI calls the design checks for the pages of its page list:

```sh
node .pk/package/bin/pk-conform.ts --design --base-url http://127.0.0.1:<port> --page / \
  --page /settings --known a11y-known.yaml --storage-state signed-in.json --report design.json
```

Exit codes of `pk-conform`: 0 passed, 1 deviation, 2 usage, 3 reference images
not checked (no set for this platform). `pk-audit`: 0 passed, 1 violation, 2
usage. Visibility checks are display only; every module still checks rights
server-side.

```sh
make check                                                # generated contract files current (expected values, composed pages)
uv run --locked papaia-kit specimen expected --check     # expected values current
uv run --locked papaia-kit specimen page --module flow    # reference document of /_kit/specimen
uv run --locked papaia-kit specimen page --page settings  # composed reference page (overview, settings, list, state)
uv run --locked papaia-kit specimen pages --check        # contract/examples/pages/ current
make shots                                                # local review images of the specimen and composed pages in shots/
uv run --locked papaia-kit base expected --check         # base layer expected values current (make check)
uv run --locked papaia-kit base page --lang de           # fixture page of the base layer (contract/base.md)
uv run --locked papaia-kit components page --lang de     # fixture page of the components: layout, section, card, tile, list, badge, dl, menu, welcome
make test-browser                                         # self test with seeded deviations (pinned Chromium)
make refimg TAG=v0.1.0                                    # kit release only, in the Playwright container
```

## Erasure journal

`papaia_kit.erasure` is the only writer of the erasure journal. Each module with
personal data keeps one journal so that deletions survive a restore.

```python
from papaia_kit.erasure import ErasureJournal, ErasureKey, Kind

journal = ErasureJournal(
    "assist",
    key=ErasureKey.from_file(Path("/run/secrets/erasure-hmac")),
    target_dir=Path("/backup/erasure-journal"),  # <backup target>/erasure-journal
    local_dir=Path("/var/lib/papaia-erasure"),  # volume papaia-erasure, backup: exclude
    mirror_dir=None,  # optional --erasure-mirror
    audit=audit_sink,  # papaia.audit/1 rows of the journal, see "Audit rows" below
    writer="assist",
)

with db.transaction() as tx:
    entry = journal.record(
        Kind.ERASE, object_ref="memory:41", sub=sub, reason="user_request", correlation_id=cid
    )
    tx.delete_memory(41)
    tx.set_applied_erasure_seq(entry.seq)
```

### Format and key

- One JSON line per entry in `<module>.jsonl`: `id`, `module`, `seq` (gap-free
  per module), `kind`, `object_ref`,
  `subject_ref`, `at` (UTC), `reason`, and `provisional_seq` only on a
  renumbered entry (below). Schema: `schemas/erasure-journal-entry.v1.schema.json`.
  Readers refuse unknown fields, duplicate JSON keys and malformed lines.
- `kind` per journal (`kinds_for(module)`; readers refuse any other kind):
  module journals hold `erase`, `erase_subject`, `delivery` and `revoke` (a
  delegation revoked at its holder; `erasure-replay` revokes it again). The core
  sources use the same format: `identity` holds `account_disable`,
  `account_delete`, `role_revoke`, `session_revoke` and `credential_reset`;
  `core-chat` holds `erase` and `erase_subject`; `model-gateway` holds those two
  and `key_revoke` (the key id, never the key value).
- `subject_ref` is `HMAC-SHA256(erasure-hmac, sub)`; the journal never holds the
  `sub` or the key. `ErasureKey.matches(sub, subject_ref)` resolves a reference
  only with the key.
- The key file `erasure-hmac` holds the key as hexadecimal text: 64 to 2048
  digits (32 to 1024 bytes), optionally followed by one line break. Generate it
  with `openssl rand -hex 32`. Raw binary content is refused, so every component
  that reads the key computes the same `subject_ref`.
- `object_ref` and `reason` are identifiers and short codes; spaces and free
  text are refused so that no content reaches the journal.

### Caller contract

- Call `record` in the same transaction as the deletion, before it commits, and
  store the returned `entry.seq` as the module's applied erasure seq in that
  transaction. Without it the module sits behind its own journal after the first
  deletion, and the start check and `doctor state_epoch` report it as older than
  the journal.
- If `record` raises, the deletion must not go ahead: the local copy is missing,
  not writable or damaged.
- If the deletion rolls back after `record` returned, the entry stays in the
  journal. It is not removed: a replay later deletes the object, which is safe
  because the person asked for the deletion. Retry the deletion; it writes a new
  entry.
- `record` writes the audit row of the journal write (below); the caller still
  writes the `papaia.audit/1` row of the deletion itself (`operation`, with the
  person's `sub`). Pass the request's correlation id to both.

### Audit rows

Every call that changes the journal hands one `papaia.audit/1` submission to
`audit` (PLT-19; rules in `contract/audit.md`, "Erasure journal rows"):

| Call | Event | `detail` |
|---|---|---|
| `record` | `erasure_journaled` | `kind`, `seq`, `delivered`, `renumbered` |
| `flush` | `erasure_journal_flushed` | `delivered`, `renumbered` |
| `entries` (only when it delivered an entry) | `erasure_journal_flushed` | `delivered`, `renumbered` |
| `acknowledge_renumbering` | `erasure_renumbering_acknowledged` | `renumbered_from` that was cleared |
| `retain` | `retention_run` | `count` (removed at the target), `seq` (highest removed), `delivered`, `renumbered` |

`delivered` counts the entries the backup target received in the call,
`renumbered` those that reached it under a later `seq`. `status()` writes no
row. A failed call writes its row with result `error` and an error code before
the exception propagates; invalid arguments raise before anything is written
and write no row. Rows name the module (`object_ref`
`{"type": "erasure_journal", "id": "<module>"}`), never the `sub`, the
`subject_ref`, the `object_ref` or the `reason` of an entry.

`audit` is called after the journal lock is released, with one argument (the
submission without `source_seq`). Bind it to the module's audit writer, for
example `lambda row: audit_writer.write(tx.conn, row)` inside the deletion's
transaction or `FileAuditWriter.record`. If it raises, the exception
propagates and the entry stays in the journal, as after a rolled-back
deletion. `writer` is the audit `writer` (`<source>` or
`<source>/<component>`). An invalid or missing `correlation_id` is replaced by
a new one. `StartGate` and `LifecycleHandler` (below) hand their rows to the
sink the caller passes.

### Places and backlog

- The backup target assigns the final `seq`. If the target is unreachable,
  read-only or holds a damaged file, the deletion goes ahead: the entry stays in
  the local copy with a provisional `seq` (the highest number the local copy and
  a reachable mirror know, plus one) and the next `record` or `flush()` delivers
  it. `status().ok` stays false until then.
- Delivery compares entries by `id`, never by `seq` alone. If the target already
  holds the provisional number for another entry (the local copy came from the
  same VM backup as the module, or was lost), the entry is delivered under the
  next free `seq` and carries `provisional_seq`; `status().renumbered_from` is
  set and `replay` rewinds behind that number, so deletions journaled at the
  target after the backup apply as well.
- The target's line of an entry is final. The local copy and the mirror append
  it when theirs differs (in one file the last line of an entry wins; files are
  never rewritten), and readers prefer it over any other place.
- Once the local copy holds the target's line of an entry, that line is final
  for the writer too (marker `.<module>.final` in the local copy: every line up
  to that `seq` is the target's). If the target later shows another `seq` for
  such an entry (for example two entries with swapped `seq`), the target is
  `conflict`: nothing is delivered to it, the local copy and the mirror keep
  their lines, deletions go ahead with the entry in the local copy and the
  mirror, and `entries()` refuses to read. Only an entry the local copy holds
  under a provisional `seq` may arrive at the target under another one.
- While the target is not usable, entries that only the mirror holds (the local
  copy was restored or lost) are taken into the local copy; one whose `seq` the
  local copy already uses gets the next free provisional `seq`. No write leaves
  two entries under one `seq` in a place; a line that would is held back and
  reported.
- `status()` never raises for a place: `local`, `target` and `mirror` are
  `ok`, `unreachable`, `corrupt` or `conflict`, with the backlog per place and
  `problems` (file and line number, never content). It runs the same check as
  `entries()` on the places as the next delivery leaves them, so `ok` is never
  true while a replay would fail. Entries of a damaged local copy or mirror
  count towards `target_pending`. It is the input of `doctor erasure_journal`
  and does not wait for the writer lock.
- The writer never creates the target or mirror directory, so a missing mount
  shows as unreachable. Journal files are opened without following symlinks.
  Concurrent writers of one module are serialised with a lock file in the local
  copy.

### Retention run

`retain(oldest_restore_point=..., offsite_retention_days=90)` removes entries
that no restore point and no copy outside the house can bring back
(sicherheit 4.9, BE-16, RE-86). The core calls it after each backup with the
time of the oldest restore point that exists at the target and the value of
`--offsite-retention`; without a restore point it does not call it.

- An entry goes when it is older than the oldest restore point plus 30 days
  **and** older than the offsite retention plus 30 days: the cutoff is the
  earlier of `oldest_restore_point - 30 days` and
  `now - (offsite_retention_days + 30) days`. `offsite_retention_days` is an
  integer from 0 to 3650; a naive or future `oldest_restore_point` is refused.
- Only a prefix by `seq` goes: the run stops at the first entry that is not
  old enough, so a retained journal has no gap. It never cuts between the
  `seq` and the `provisional_seq` of a renumbered entry, because `replay`
  rewinds to `provisional_seq - 1`.
- No file is emptied: the newest entry of every place stays, so the next
  provisional `seq` still follows it while the target is unreachable. Every
  line of a kept entry stays, the target's line included; all lines of a
  removed entry go. Files are replaced in one step (temporary file, fsync,
  rename) without following symlinks.
- The run needs the target. It delivers pending entries first and raises
  without removing anything when the target is unreachable, damaged or
  conflicting. It cleans the mirror, then the local copy, then the target. A
  mirror that is away or read-only is named in `skipped`.
- The cutoff is recorded at the target and in the local copy
  (`.<module>.retained`). Entries older than it that the target no longer
  holds are retired: a mirror that missed the run or a local copy from an
  older VM backup never delivers them again, they do not count as pending,
  and the next run removes them. A recorded cutoff later than 30 days ago
  never comes from a run and is ignored.
- A replay from a restore point inside the window works unchanged. A replay
  from a module state older than the window stops with `JournalGapError`.

### Mounts of the target and the mirror

`record` reads and appends to the target and the mirror inside the deletion. A
network mount that hangs instead of failing would hold up every deletion of the
module. Mount both so that a dead server returns an error within seconds:

- NFS: `soft,timeo=50,retrans=2`, never
  `hard` (nfs(5): linear back-off, an error after about 30 seconds).
- SMB/CIFS: `soft` (the default) with `echo_interval=10`.

These values come from the documentation (nfs(5), mount.cifs(8)) and have not
been tested against a dead server yet. Check the time until `record` returns
with the target stopped before relying on them.
- Anything else: mount it on the host, check it there and bind-mount the
  directory only while the check passes.

A place that returns an error counts as unreachable and the deletion goes ahead
with the entry in the local copy. `status()` takes no lock, but it still reads
each place, so the same mount options keep `doctor` from hanging.

### Operator repair

| `status()` shows | Effect | Repair |
|---|---|---|
| `target` or `mirror` `unreachable` | Deletions continue; entries wait in the local copy. | Mount the place or restore write access; run `flush()` (any deletion does it as well). |
| `target` or `mirror` `corrupt` | Deletions continue; nothing is written to that place; a replay refuses to run. | Move the file aside, keep a copy for inspection, remove the line named in `problems` (or two entries with one `seq`), put the file back; run `flush()`. |
| `local` `corrupt` | Deletions of the module are blocked. | Move `<module>.jsonl` out of the volume `papaia-erasure` for inspection; the next `flush()` rebuilds the local copy from target and mirror. Entries that existed only in the damaged copy must be delivered by hand. |
| `local` or `mirror` `conflict` | Deletions continue; a replay refuses to run. One entry differs in content between this place and the target (or the local copy), or two entries would share one `seq`. | Compare the files by `id` (`problems` names the places, not the content). Find out which line was changed; the target's file is not trustworthy by default, since every module can write it (residual risk below). Fix the changed line, run `flush()`. |
| `renumbered_from` set | The module state may be older than the journal. | Run `papaia-ctl recover-snapshot`; after a successful replay call `acknowledge_renumbering()`. |

### Replay after a restore

Module action `erasure-replay`:

```python
from papaia_kit.erasure import ReplayTrigger, replay

read = journal.entries()  # delivers pending entries, then target + mirror + local copy
if read.provisional:
    ...  # target unavailable: mark the run provisional (sicherheit 4.9 (2), (2a) (v))
result = replay(
    read.entries, applied_seq=db_applied_seq, handler=apply_entry, trigger=ReplayTrigger.RESTORE
)
```

Without a writer instance, `read_journal(module, [d for d in (target_dir, local_dir,
mirror_dir) if d is not None])` reads the configured places. Pass the target
first: for one entry the line of the first directory wins. It is strict: a
missing or unreadable directory raises `JournalUnavailableError` (an unmounted
target never looks like an empty journal); inside an existing directory a
missing file is an empty journal. Run `flush()` first if a place was down, or
use `journal.entries()`, which delivers before it reads. A stale local copy
that still holds an undelivered entry under a `seq` the target gave another
entry makes `read_journal` raise `JournalConflictError` until the next
`flush()`; a restore path should use `journal.entries()`. `read_journal` has
no final marker: it does not detect a `seq` rewritten at the target, while the
writer does.

`replay` applies every entry after the module's applied `seq` in order and
refuses a journal with a missing `seq`, two entries for one `seq` or one entry
with different content. The handler deletes (`erase`, `erase_subject`) or marks
a reminder delivered (`delivery`), is idempotent and stores the applied `seq` in
the same transaction. `ReplayResult` carries the counts per kind,
`replayed_from`, `journal_end` and `journal_behind` (the journal is shorter than
the module state, for example a target replaced by an older copy) for the audit
event and `doctor`. Write the row of a successful run with
`audit_sink(erasure_replayed_event(result, module="assist", writer="assist",
correlation_id=cid, service_account="papaia-ctl"))`; `LifecycleHandler` does it
for the core's requests. Only `papaia-ctl restore`, `rollback`, `recover-snapshot`
and the core start gate (`lifecycle`) trigger a replay; no module replays on its
own.

### State epoch check at module start

A module state can come back without `restore`: a hypervisor restores a VM
backup, or volumes are copied back by hand. No `erasure-replay` runs then. At
start each module compares the erasure `seq` it applied (kept in its own
database, see the caller contract) with the journal:

```python
from papaia_kit.erasure import LifecycleHandler, StartGate

gate = StartGate(journal, db.applied_erasure_seq, audit=audit_writer_sink, writer="assist")
gate.check()  # before serving anything; not ready until then

gate.require_ready()  # every request except POST /internal/lifecycle
if gate.background_allowed():  # before every step, schedule, delivery, erasure run
    ...
gate.check_if_due()  # every minute; rechecks a provisional result every 15 min
gate.health()  # body of GET /healthz: ok, degraded or down
```

Sources are the journal at the backup target with its `epoch` file, the mirror
and the local copy. `<backup target>/erasure-journal/epoch`
(`schemas/erasure-epoch.v1.schema.json`) is written by the core only
(`write_epoch`): `generation` of the installation and the last `seq` per module
and core source. Results (`doctor state_epoch`):

| State | When | Ready | `doctor` |
|---|---|---|---|
| `current` | target and `epoch` readable, no entry beyond the applied `seq` | yes | `pass` (`warn` if the journal is shorter than the module state) |
| `unverified` | target unreachable, damaged or `epoch` damaged; no source that could be read shows a backlog | yes, provisionally; checked again every 15 min | `warn`, audit `state_epoch_unverified` |
| `behind` | any source that could be read holds an entry beyond the applied `seq` (a damaged or conflicting target, mirror or local copy included: their intact lines count), `epoch` names a higher `seq`, or an entry was renumbered | no requests, no background work | `fail`, audit `state_epoch_behind` |
| `unknown` | neither target nor mirror nor local copy usable, or the applied `seq` is unreadable | no | `fail`, audit `state_epoch_unknown` |

Behind the journal the module shows: "Datenstand älter als das Löschjournal
(z. B. nach Rückspielen einer VM-Sicherung). Ausführen: papaia-ctl
recover-snapshot". It never replays on its own. Refused requests get the
envelope `PK-UPSTREAM-001` (503, `Retry-After: 60`) from
`ModuleNotReadyError.envelope(correlation_id)`.

`POST /internal/lifecycle` carries the core's actions `{"action":
"erasure-replay"}` and `{"action": "post-restore"}` (nothing else; at most
1 KiB). The module's server terminates mTLS and passes the caller from the
verified client certificate:

```python
handler = LifecycleHandler(
    journal=journal,
    gate=gate,
    applied_seq=db.applied_erasure_seq,
    apply_entry=apply_entry,  # idempotent, stores entry.seq in the same transaction
    post_restore=post_restore,  # returns counts only, or None for a module without one
    audit=audit_writer_sink,
    writer="assist",
)
response = handler.handle(body, caller=peer_identity, correlation_id=header_value)
```

Only `papaia-lifecycle` is served by default (`403 PK-ACCESS-001` otherwise);
a malformed body gets `400 PK-INPUT-001`, an unreachable journal `503
PK-UPSTREAM-001`, a damaged one `409 PK-CONFLICT-001`, a failing handler `500
PK-INTERNAL-001`. If clearing the renumbering marker or checking the gate
again fails after the entries were applied, the answer is `503
PK-UPSTREAM-001` (local copy not writable) or `500 PK-INTERNAL-001`, with an
`erasure_replayed` submission of result `error` that counts the applied
entries. A successful replay checks the gate again and answers with
counts only: `applied`, `applied_seq`, `by_kind`, `provisional`,
`journal_behind`, `state`, `ready`. Each request hands one `papaia.audit/1`
submission (without `source_seq`, which the audit writer assigns) to `audit`:
`erasure_replayed`, `post_restore_applied` or `lifecycle_request_rejected`.
Pass the audit writer as the sink, for example
`audit=lambda event: audit_writer.write(conn, event)` inside the module's
transaction.

### Residual risk

All modules mount the shared `erasure-journal` directory read-write, so a module
can change or delete the journal of another module and the core's `epoch` file
there. Two effects follow:

- Loss: a module can truncate or rewrite another module's journal. The writer
  limits the effect (a damaged file at the target or mirror blocks no deletion,
  the local copy re-delivers its own entries, a mirror keeps a second copy, a
  changed `seq` of an entry the local copy holds as final marks the target
  `conflict`), but entries recorded while a module's local copy was lost can be
  lost with it. Not detected: a `seq` rewritten for an entry the local copy
  holds only under a provisional `seq`, or while the local copy has no valid
  final marker (it was replaced without it); the local copy and the mirror then
  take the target's line over and a replay can skip a deletion.
- Injection: a compromised module can append a valid `erase` or
  `erase_subject` line to another module's journal at the next free `seq`. The
  line is a well-formed entry, so the writer accepts it and delivers it to the
  local copy; a later restore or rollback replays it and deletes data of the
  other module. The writer cannot tell such a line from a real one.

Until each module has its own mount at the target (its own journal read-write,
other modules' journals not mounted or read-only, `epoch` writable only for
the core), run the journal with one module per target directory, or treat it
as a single-module setup. A shared read-write directory is not fit for
production with several modules.

## Repository checks

The kit ships the checks every papaia repository runs in CI:

```sh
# Dependency licenses against the shared policy (Python environment of the
# project, npm lock files, or JSON records)
uv run --locked papaia-kit licenses check --python-project . --npm-lock js/package-lock.json

# Regenerate THIRD_PARTY_LICENSES.md (CI runs the same with --check)
uv run --locked papaia-kit licenses render --python-project . --npm-lock js/package-lock.json

# Denied terms in tracked and new files (optionally against a frozen
# baseline, see below)
uv run --locked papaia-kit repo words

# Author, committer, sign-off and wording of every commit in a range
# (optionally from a start boundary on, see below)
uv run --locked papaia-kit repo commits origin/main..HEAD
```

## Catalog reader

`papaia_kit.catalog` is the one reader of the platform catalog
(`platform/services.json`) and the group list (`platform/groups.json`). It
checks size, strict JSON, the schema, unique ids and every entry's
`content_hash` (RFC 8785), keeps the last valid state when a file is invalid,
reports added, changed and removed entries, derives the switcher with
`visible_modules(catalog, roles)` and link states with `link_state`, and
resolves the return path with `resolve_from(catalog, from)`. Behaviour
and shared vectors (`contract/vectors/`) are described in
`contract/catalog-reader.md`.

```python
from papaia_kit.catalog import ServicesReader, resolve_from, visible_modules

reader = ServicesReader("/etc/papaia/platform/services.json")
catalog = reader.get()  # checks the file at most every 30 s
if catalog is not None:
    switcher = visible_modules(catalog, id_token_claims["roles"])
    back = resolve_from(catalog, request.args.get("from"))  # None: no breadcrumb
    # back.running is False for a stopped module: show the locked link
```

Holders of delegations and the personal area take every expiry date they show
from the installation's setting in the catalog (`delegations`, defaults 90 days
without use and 180 days in all, at most 365 each, `kritis` at most 7 / 30),
never from a number of their own (`contract/platform-services.md` section 2.6):

```python
lifetime = catalog.delegation_lifetime  # published values, else profile defaults
card_until = lifetime.max_expires_at(now)  # latest end shown on the grant card
expires = lifetime.expires_at(delegation.granted_at, delegation.last_redeemed_at)
```

Every approval in every module follows the one four-eyes setting of the
installation (`approvals.four_eyes`, default `off`, always `on` in profile
`kritis`; `contract/platform-services.md` section 2.7). Modules keep no setting
of their own:

```python
from papaia_kit.catalog import four_eyes_required, review_decision

decision = review_decision(catalog, submitter=version.author_sub, approver=token.sub)
if not decision.allowed:
    raise_error(decision.error_code)  # PK-REVIEW-SELF, only while four eyes are on
audit_detail = dict(decision.audit_detail)  # {"selbstfreigabe": True} for a self-approval
```

`four_eyes_required(catalog)` is `True` in `kritis`, with `on`, and for a
missing catalog (fail closed). The approver's role is still checked
server-side.

## Check chain

`papaia_kit.authz.CheckChain` checks every bearer token on the server: RS256 or
ES256 signature against the realm keys, exact issuer, access token type, one audience (several
only for `trust: platform` and the chat client), `azp` in the allow list
`azp-allowlist.json` of the own audience (an empty list refuses every token),
identity kind, revocation list (`global_since`, revoked `sub`), module role and
the effect released for the `azp`. The `scope` claim is never a rights source.
A refusal raises `AuthzDenied` with an error envelope and hands one
`papaia.audit/1` row with result `denied` to the audit writer. `origin_azp`
comes from the configured upstream origins; the `X-Papaia-Origin-Azp` header is
information only, a mismatch is recorded as `origin_header_mismatch`. Details:
`contract/authz.md`.

## Platform halt

`papaia_kit.halt.HaltGuard` is the one reader of the platform halt
(`state/halt.json`, written only by the core's host command). Every module and
server that acts holds one guard on the read-only mounted folder
(`PAPAIA_HALT_DIR`) and asks it before each write, send, delete, model call,
flow step and delivery; a poll every 5 s covers the notice in every interface.
Any doubt about the file (unreadable, not the four fields, a link, a folder or
a pipe in its place, gone after it was seen, folder not mounted) counts as an
active halt. The guard only reads.

```python
from papaia_kit.halt import Action, HaltGuard, PlatformHalted

guard = HaltGuard.from_env(audit=writer.record, writer="mcp-paperless")
poller = guard.start_polling()  # poller.stop() on shutdown

try:
    guard.require(Action.WRITE, correlation_id=cid, principal=principal, request=request)
    guard.require(Action.MODEL, correlation_id=cid)  # before a model call
except PlatformHalted as halted:
    return error_response(halted.status, halted.envelope)  # PK-HALT-001, HTTP 503
```

A refused write, send or delete hands one `papaia.audit/1` row to the audit
writer: `result: denied`, `event: operation`, the identity fields of the
principal, `catalog_id`, `operation`, `effect` of the request and
`error_code: PK-HALT-001`, never the reason or author of the halt. Integration
points, the state table and the row: `contract/halt.md`. Modules prove their
check with `papaia-kit conformance halt` (with `--driver` around their own
reader).

## Conformance suites

`papaia-kit conformance <suite>` runs a conformance suite and writes JUnit XML
with `--junit`; every module runs the suites for the contract surfaces it
provides or consumes in its own CI. Checks, driver protocol and recording format
are described in `contract/conformance.md`. The `manifest` suite also reports
the entries marked `header_identity: true` (services that take a person's
identity from a request header); the core never publishes a port for them.

```sh
# Section exposes: of an add-on: schema, naming register, checks beyond the schema
uv run --locked papaia-kit conformance manifest papaia-app.yaml --compose docker-compose.yml --junit conformance-manifest.xml

# The exposes.yaml of core profiles (no module name)
uv run --locked papaia-kit conformance manifest --core-profile src/*/*/exposes.yaml --junit conformance-manifest.xml

# Shared catalog reader vectors against the kit reader, or a reader behind a driver command
uv run --locked papaia-kit conformance catalog-consumer --junit conformance-catalog.xml

# A provider recording against its format and the pinned digest
uv run --locked papaia-kit conformance recording tests/golden/probe/recording.json --pin sha256:<digest>

# Server code: no generated code execution, no built query text or scopes, no model names
uv run --locked papaia-kit conformance static src/ --junit conformance-static.xml

# Model requests recorded by the kit test model: declared aliases and allowed features only
uv run --locked papaia-kit conformance model recording/requests.jsonl --manifest papaia-app.yaml --junit conformance-model.xml
```

The kit test model (`testing/pruefmodell/`, test stacks only) answers chat
completion requests from a script, simulates missing features, errors and
slow answers, and records every request (without keys) for the `model`
suite; see [`testing/pruefmodell/README.md`](testing/pruefmodell/README.md).

The `static` suite takes exceptions only from the repository's
`static-exceptions.toml`: one entry per place (file, enclosing function or
class, subject, count) with reason, input source, expiry date and approval.
It reports how many files it left out per reason; `--include-dir` reads a
skipped directory such as `site-packages` of an image. The kit runs it over
its own package (`make check-static`). `--require-approved` rejects entries
whose `approved_by` does not name the security officer or still says
pending (a wording check; the joint acceptance, which runs the suite with
it, still reads the countersignatures).
The rules are heuristics; their known limits are listed in
[`contract/conformance.md`](contract/conformance.md).
`papaia-kit conformance realm` checks the separation rule of the realm: the
clients with token exchange and the audiences (including audiences from client
roles) intersect in exactly `{papaia-data}`. It reads a realm export or, with
the token of a read-only admin account, the admin API:

```sh
uv run --locked papaia-kit conformance realm --export realm-export.json --junit conformance-realm.xml
PAPAIA_KIT_ADMIN_TOKEN=... uv run --locked papaia-kit conformance realm --admin-url https://id.example.org --junit conformance-realm.xml
```

`papaia-kit conformance injection` runs the shared corpus of injected
instructions (`testing/injection/`, PLT-60) against a module with model
access. The module wraps its pipeline in a driver command that seeds each
case's foreign content, lets the test model follow the instruction and
reports what it executed, proposed, remembered and rendered; the suite fails
every case in which foreign content caused an effect without confirmation, a
memory entry, a foreign link or image, or a call under an identity the model
chose:

```sh
uv run --locked papaia-kit conformance injection --driver "python -m tests.security.injection_driver" \
  --cases tests/security/injection/module.yaml --junit conformance-injection.xml
```

`papaia-kit conformance server` checks a running MCP server against its
declaration in the CI of the server: `tools/list` against `operations[]`,
`describe_access` and `check_access` without content, the error envelope, one
audit row per write and the refusal of tokens for a foreign audience, of a
foreign `azp` and with several audiences. Tokens come from the kit test issuer
(`testing/issuer/`, CI only):

```sh
uv run --locked papaia-kit conformance server papaia-app.yaml --url http://127.0.0.1:8000/mcp \
  --issuer http://127.0.0.1:8080 --azp papaia-studio-gateway --role probe-user \
  --calls conformance-calls.json --audit-file audit/server.jsonl --junit conformance-server.xml
```

With `--record FILE --image-digest sha256:<digest>` the run is also written as
the provider recording (request and response pairs, schema version, image
digest, no credentials), but only when every check passed; otherwise a file
an earlier run left there is removed, so the file is valid only on exit 0. The
command prints
the digest of the recording; consumers pin it and check their copy with
`papaia-kit conformance recording FILE --pin sha256:<digest>`.

`papaia-kit conformance me-v2` checks a running personal-area module API
against its declaration (`personal_settings:`, contract version 2) in the CI of
every module with an entry of kind `me`, against its test instance: `401`,
read of all groups, `428`, `412`, idempotency, field errors, the demand for a
fresh sign-in and the deletion receipt. Tokens come from the kit test issuer;
`--record` writes the provider recording as for the server suite:

```sh
uv run --locked papaia-kit conformance me-v2 papaia-app.yaml --url http://127.0.0.1:8080/api/me \
  --issuer http://127.0.0.1:8081 --audience papaia-studio-me --junit conformance-me-v2.xml
```

`papaia-kit conformance handover` compares the digest of the handover schema
`papaia.data-handover/1` (Data's `schemas/data-handover-1.json` or Studio's
copy) with the digest Studio pins and the one of the bill of materials:

```sh
uv run --locked papaia-kit conformance handover schemas/data-handover-1.json \
  --pin-file tests/contract/data-handover-1.sha256 --bom suite-1.10.0.yaml --junit conformance-handover.xml
```

## Naming register

`papaia_kit.names` holds the binding names of audiences, exchange scopes,
clients, roles, service accounts, core services and core networks, each with its
owning repository, plus the rule for new names and the list of removed names.
`exchange_scope(audience)` is the only way to build `aud-<audience>`;
`person_id(claims)` applies the person identifier rule (`sub`). Rules, removed
names and the `papaia-kit names` commands are described in `contract/names.md`.

CI also scans the full history for secrets (`make secrets`, gitleaks) and the
lock files for known vulnerabilities (`make vulns`, osv-scanner); both tools are
pinned by version and sha256 in the workflow. The lint job runs the full
`make lint`; the browser suite (`make test-browser`) runs in its own job in the
Playwright container of the version in `contract/specimen.yaml`, pinned by
digest.

### Python dependencies

`--python-project` reads every third-party package of the project's `uv.lock`
and takes its license from the project's environment, so the command must run
in that environment (`uv run --locked` inside the project, or the environment
named by `UV_PROJECT_ENVIRONMENT`); otherwise it fails. It also fails for every
locked package that is missing from the environment or installed at another
version. A package that an environment marker excludes on the checking platform
needs a `[[verified]]` entry.

Scopes: the closure of the dependencies and of the extras is `runtime`;
dependency groups named `test`, `tests` or `testing` are `test`; every other
group, and extras named like a development group (`dev`, `lint`, `docs`,
`typing`, `test`), are `build`. A package reached from several of them takes
the strictest scope (runtime, then build, then test).

The license is read from `License-Expression`, then `License`, then the license
classifiers, plus the files in the `licenses/` folder of the dist-info. Several
license classifiers are combined with AND. A `License` field that is neither a
known name nor an SPDX expression is never dropped: next to classifiers it adds
`LicenseRef-unparsed-license-field`; only pure pointers such as `see LICENSE` or
`UNKNOWN` give way to the classifiers. GNU GPL, LGPL or AGPL named in the license
files (any letter case; fixed passages of the PSF and MPL-2.0 texts excepted)
adds `LicenseRef-GPL-family-text-in-license-files` unless every choice of the
expression already includes a GPL-family license. These parts, and classifiers
without a version (`BSD License`, `Apache Software License`), need a
`[[verified]]` entry.

### Denied terms

`repo words` reports tool and vendor names, private tooling and key prefixes.
A few fixed contexts that name no tool are allowed (HTTP header names, key
daemons, the CSS pointer-shape property and utility classes, attribute access
on code objects, and the English product name of the map of knowledge sources
from the glossary, exact case and as a whole name); see
`ALLOWED_CONTEXTS_B64` in `py/papaia_kit/repo`.

### Frozen baseline of the word check

A repository whose existing texts use a denied term as product vocabulary
freezes those places in a baseline file instead of rewriting them. The kit
itself has no baseline; its own term list stays encoded in the package.

```sh
# Once: list every current hit with one reason (refuses an existing file)
uv run --locked papaia-kit repo words --baseline words-baseline.toml \
    --write-baseline --reason "product term of the chat interface"

# In CI: listed hits pass, every other hit and every stale entry fails
uv run --locked papaia-kit repo words --baseline words-baseline.toml
```

Each `[[entry]]` holds `path` (relative to the repository root), `term` (as
found), `fingerprint` (SHA-256 of the line text without surrounding white
space), `count` (hits of this term on lines with this text in that file,
default 1; a line that holds the term twice counts twice) and `reason` (one
line, no denied term). Unknown keys, duplicate entries and malformed values
make the file unusable (exit 2). `--write-baseline` refuses (exit 2, no file)
what the check would reject: more than 10 000 entries, a `count` above 1 000,
more than 1 MiB, or a hit that is no valid `term`.

- A hit passes only when an entry has the same path, term and fingerprint. A
  line that moved or changed its indentation keeps its fingerprint; an edited
  line, the same text in another file, or one more copy of the line than
  `count` fails.
- An entry with fewer hits than its `count` is stale and fails until it is
  removed, so the list only shrinks.
- In the baseline file itself only the `term = "<term>"` lines of listed terms
  and the `path = "<path>"` lines of listed paths, exactly as `--write-baseline`
  writes them, are exempt; comments and every other line are checked. So the
  baseline can live in the repository even when a listed path holds a term.
- `--write-baseline` creates the file once. Afterwards entries are removed
  freely, but every added or changed entry needs a reviewed change with its own
  reason for that place.

### Start boundary of the commit check

A repository whose history begins before the commit rules applied names one
start commit in `commit-boundary.toml` at its root (another file with
`repo commits --boundary <file>`). That commit and all its ancestors are not
checked; every later commit in the range is checked as before. Without the
file the check is unchanged.

```toml
version = 1
commit = "<full SHA of the start commit>"
reason = "<why the earlier history is exempt>"
```

- `commit` is the full SHA (40 or 64 lower-case hexadecimal digits) of a
  commit of the repository; no abbreviation, branch name, wildcard or date.
- `reason` is required: one trimmed line of at most 300 characters without a
  denied term.
- The file has exactly these three keys; there are no exemptions by author,
  date or pattern.
- The start commit must be an ancestor of (or equal to) the end of the checked
  range (the right side of `A..B` or `A...B`, or the revision itself);
  otherwise the check fails (exit 1) and names both.
- A malformed file, a missing reason or a commit the repository does not hold
  is a usage error (exit 2).
- When the boundary is used, the check prints one line with the commit, the
  file and the reason.

## Glossary and word check

`glossary/glossary.yaml` is the binding German/English glossary of every
user-facing text (68 entries plus a `fixed` part), checked against
`glossary/glossary.schema.json`. Each entry has `id`, `nr`, `restricted`,
`scope` (`ui`, `admin`, `doc`), an optional `note` and per language `term`,
optional `plural` and `variants`, `definition`, `replaces` (outdated words as
patterns), optional `compound` (`head` default, or `any`), `allow_in_sentence`
and `restricted_words`. The `fixed` part holds the form of address (`Sie` and
the pattern of the informal form), the display names of the modules, the role
display (`Studio-Prüfer`, `Data Reviewer`, `role_display()`) and the list of
mandatory places.

Pattern rules (one implementation, Python `re` on `str`):

- A word boundary is `(?<!\w)...(?!\w)` (or the forms with `[\w-]`); `\w` is
  Unicode, so "Verfügbare Quellen" matches and "Datenquellen" does not. The
  schema rejects `\b` and `\p{...}`; the third-party `regex` package is not used.
- Upper and lower case are the same; `(?-i:...)` makes a part exact.
- At load the boundary is dropped by the compound mode: `head` also reports a
  hit at the end of a compound ("Sprachassistent"), `any` at every position
  ("Notabschaltungsseite"). A pattern that does not compile stops the load with
  the line of the file; so does a pattern that matches a term of the glossary.
- A word that is a term in another meaning ("Freigabe", "Katalog", "Konto")
  is never replaced; its entry is `restricted` and stage W3 limits it.

The word check (`papaia-kit words`, also installed as `pk-words`) reads a module
repository. Five sources are the five CI stages:

| Source | Files | Language |
|---|---|---|
| `ui` | `i18n/export/{de,en}.json`: JSON array of `{key, text, kind[, fuzzy]}`, `kind` in `nav`, `title`, `button`, `tab`, `text`, `message` | file name |
| `templates` | text nodes and `title`/`alt`/`placeholder`/`aria-label`/`label` of `*.html`, `*.tsx`, `*.jsx` (Jinja tags, scripts and code removed) | `.de.`/`.en.` in the name, a `de`/`en` directory, `<html lang>`; else both lists |
| `docs` | `docs/help/**/*.md` without code and link targets | as above |
| `mails` | `**/mail/**/*.j2`, `**/mails/**/*.j2` | as above |
| `messages` | string values of `**/messages/*.{de,en}.yaml`, `**/codes.{de,en}.yaml` | file name |

Files are what git would version (tracked plus new, not ignored), or every file
outside a git work tree; `node_modules`, `vendor`, `.venv`, `tests` and
`fixtures` are skipped (`--exclude GLOB` adds more).

| Check | Over | Fails on |
|---|---|---|
| W1 replaced words | every source | a `replaces` pattern of the file's language (the role word of `allow_in_sentence` passes in `text` and `message`); the informal address in German texts |
| W2 mandatory places | `ui` | a mandatory place without key or `nicht vorhanden` in `i18n/glossary-map.yaml`; a mapped text that differs from the glossary in either language. Navigation texts over 24 characters are a warning only |
| W3 restricted words | `ui`, kinds `nav`, `title`, `button`, `tab` | a word of a `restricted` entry in a key not mapped to exactly that entry |
| W4 completeness | `ui` | keys only in one language, empty texts, `fuzzy` entries |
| W5 forbidden patterns | `ui`, kinds `message`, `text`, `button` | `contract/forbidden-patterns.yaml` (placeholders removed first), hidden characters |

The map file of a module:

```yaml
version: 1
module: studio            # id from fixed.modules
map:
  module_title: nav.module
  mein_bereich: nav.me
  audit_log: [nav.audit, title.audit]
  benachrichtigung: nicht vorhanden
```

```sh
uv run --locked papaia-kit words glossary                  # schema and patterns
uv run --locked papaia-kit words check --report words.json  # all five sources
uv run --locked papaia-kit words check --source docs        # one stage
```

Every finding names the replacement from the glossary. Exit codes: 0 clean
(warnings allowed), 1 findings, 2 a missing or malformed input (unknown fields
are rejected).

Runtime stages on a running system: L2 hands the text nodes read by a test
script to the same patterns (`papaia_kit.ui.runtime.check_rendered`, or
`words rendered --lang de nodes.json` with an array of strings or
`{text, glossary_id?, kind?, exempt?}`); a node with a `glossary_id` must equal
the glossary term. L1 builds the check locale `x-pk` (`words pseudo
i18n/export/en.json --output x-pk.json`, every text as `⟦...⟧`) and
`words rendered --pseudo --keys i18n/export/en.json nodes.json` reports text
without marks and visible key names; nodes marked `exempt` (`person`,
`catalog_name`) and numbers pass.

## License policy

`policy/license-policy.toml` sorts SPDX identifiers into classes and decides
per scope (`runtime`, `build`, `test`, `service`) which classes are allowed,
allowed only with an exception, or denied. Its `[project]` table names the
license of the papaia repositories themselves (`MIT`); the loader accepts only
a permissive identifier there. In short:

1. Own code and own images use permissive licenses only (fonts OFL-1.1, data
   and icons CC-BY-4.0 with attribution).
2. Weak copyleft only unmodified, as a separate file or dynamically loaded,
   with an exception entry and an ADR per package.
3. GPL, AGPL, SSPL, BUSL, Elastic, RSAL, non-commercial or no-derivatives terms
   and unknown licenses never enter own code or images.
4. Third-party services that run separately (own container, network protocols
   only): permissive and weak copyleft freely; GPL and AGPL only unmodified with
   source provision; source-available licenses only with written approval of
   the owner; proprietary only in tests or when procured by the operator.
5. Build and test tools may carry any free license, fonts and attribution
   licenses included, as long as they never enter an artefact.

Exceptions live in each repository's `license-exceptions.toml`: one entry per
package and exact version with scope, reason, ADR, expiry date and approval. An
exception never lifts a denied class. Empty or ambiguous package metadata is
resolved with a `[[verified]]` entry naming the https source where the license
was checked.

## Error envelope

Every module answers errors with one envelope, `schemas/error.v1.schema.json`:
the body of an `application/problem+json` response (RFC 9457) or the
`error.data` of an MCP JSON-RPC error.

```json
{
  "type": "https://schemas.papaia.dev/errors/forbidden_or_not_found",
  "title": "Nicht gefunden oder nicht erlaubt",
  "status": 404,
  "code": "PK-ACCESS-001",
  "class": "forbidden_or_not_found",
  "message": "Der Inhalt ist nicht vorhanden oder nicht für Sie freigegeben.",
  "hint": "Fragen Sie Ihre Ansprechstelle, wenn Sie Zugriff brauchen.",
  "correlation_id": "c0a8-4e2f-91",
  "retryable": false
}
```

| Class | HTTP | Retryable |
|---|---|---|
| `unauthenticated` | 401 | no |
| `forbidden_or_not_found` | 404 (default) or 403; the target decides, the answer never tells whether the object exists | no |
| `invalid_input` | 422 (default) or 400 | no |
| `conflict` | 409 (default) or 412 | no |
| `rate_limited` | 429, `retry_after` and `Retry-After` required | yes |
| `upstream_unavailable` | 503 (default), 502 or 504; `retry_after` optional | yes |
| `identity_revoked` | 401 | no |
| `class_exceeded` | 403 | no |
| `contract_mismatch` | 409 | no |
| `budget_exceeded` | 429 | no |
| `internal_error` | 500; generic class of every unknown code | no |

Module codes (`<MODULE>-<AREA>-<NR>`, modules `FLOW`, `DATA`, `STUDIO`,
`ASSIST`, `ME`, `CONNECTIONS`, `MCP`; `PK` is the kit) map to exactly one class
in `contract/errors.yaml`. A well-formed code that is not listed keeps its name
and gets the class and texts of `PK-INTERNAL-001`; a malformed code is replaced
by `PK-INTERNAL-001`.

The connection register's codes are listed with their class:

| Class | `CONNECTIONS-…` codes |
|---|---|
| `unauthenticated` | `UNAUTHENTICATED` |
| `forbidden_or_not_found` | `FORBIDDEN`, `NOT-ALLOWED`, `NOT-FOUND` (the text of `PK-ACCESS-001`, so a refusal reads like a missing account or target); `CONSENT-MISSING`, `FOUR-EYES`, `TARGET-NOT-APPROVED` (own hint) |
| `invalid_input` | `INVALID`, `TOO-LARGE` |
| `conflict` | `STATE` |
| `rate_limited` | `RATE` |
| `budget_exceeded` | `SERVICE-HELD` |
| `upstream_unavailable` | `UNREACHABLE`, `KEYS`, `TLS`, `JOURNAL` |
| `contract_mismatch` | `SEALING` |
| `internal_error` | `ERROR`, `CLOSED` |

A code without an own hint is an alias of the kit code of its class and shows
its text. An envelope with one of these codes carries a status of its class
(`CLASSES[cls].statuses`).

```python
from papaia_kit.errors import build_envelope, display_text, display_text_for, parse_envelope

# Sending side
envelope = build_envelope("PK-ACCESS-001", correlation_id=request_correlation_id, lang="de")
response_body, response_headers = envelope.to_dict(), envelope.http_headers()

text = display_text(
    "PK-ACCESS-001", correlation_id=envelope.correlation_id, params={"contact": "die IT-Abteilung"}
)
text.parts()  # (what happened + consequence, what to do, "Kennung: c0a8-4e2f-91")

# Receiving side
received = parse_envelope(json_body)  # strict; raises ValueError
shown = display_text_for(received, lang="de")  # the only way to show it to a person
```

- On the sending side `title`, `message` and `hint` come only from
  `contract/messages/codes.{de,en}.yaml`; `build_envelope` takes no free text.
- On the receiving side, never show the received `title`, `message` or
  `hint`. `parse_envelope` rejects texts with a forbidden pattern or a control,
  format (bidi, zero-width), private-use or separator character, and a known
  code that carries another class; a well-formed unknown code may carry any
  class. Only `display_text_for(received)` produces text for a person: it
  rebuilds all three parts from `code` and `class` (an unknown code gets the
  texts of the kit code of its class). Together these keep source content,
  credentials and raw server or model output away from people, also when the
  other side is faulty or foreign.
- A missing or invalid correlation id (more than 64 characters, other than
  `[A-Za-z0-9-]`, or shaped like a token or prefixed key) is replaced by a new
  UUIDv7. The envelope uses the same rule as `papaia_kit.correlation` and the
  audit schema (`contract/audit.md`).
- Placeholder values (`{contact}`, `{role}`, `{n}`, `{step}`) come from
  configuration (`branding.contact`, role names of the interface) or from names
  the person may see anyway (a workflow step, a count), never from the content,
  title or owner of a source object. They are length-checked, must pass the
  forbidden patterns and must not contain control, format, private-use or
  separator characters. `check_params` raises on a bad value (use it when
  loading configuration); `display_text`, `display_text_for` and
  `build_envelope` drop bad values instead, so the error path never fails:
  `{contact}` falls back to `contact_default`, `{role}` to the reviewer role of
  the code's module (`Studio-Prüfer`, `Flow-Prüfer`, `Data-Prüfer`, else
  `Prüfer`). Parts 1 and 2 only use these two placeholders; a consequence
  sentence without its `{n}` or `{step}` falls back to its `_unnamed` variant
  or is left out.
- `contract/messages/consequences.{de,en}.yaml` holds the closed list of
  consequence sentences that a code may append to part 1. A code refers to a
  sentence only by its id (field `consequence`); free consequence text is
  rejected. `check_code_text(entry, lang=...)` applies the message schema to
  one code entry: part 1 (`what`) one sentence, optional `consequence` id from
  the list, part 2 (`todo`) exactly one action as one sentence, no other
  fields. The catalog loader applies the same check to every shipped code.
- The list grows only with a kit minor version.
  `contract/messages/consequences.register.json` names every id under the kit
  minor (`"major.minor"`) that added it; the loader rejects an id that the
  register does not name and a minor later than the kit version, and
  `make release` refuses a tag that changes the ids of an earlier minor or adds
  ids in a patch release (a major version may change the list).
- Review of one's own version: the kit code `PK-REVIEW-SELF` ("Sie können Ihre
  eigene Version nicht prüfen. Es wurde nichts geändert." / "Bitten Sie eine
  zweite Person mit der Rolle <Modul>-Prüfer um die Prüfung."). The module
  codes `STUDIO-REVIEW-001`, `FLOW-REVIEW-SELF` and `DATA-REVIEW-SELF` are
  aliases in `contract/errors.yaml` and render character for character the
  same text; only `{role}` names the module's reviewer role.
- `contract/forbidden-patterns.yaml` lists patterns that never appear in visible
  text (codes outside part 3, a status code on its own, identifiers and key
  names, stack traces, opaque values); `find_forbidden_patterns(text)` applies
  it, and the tests run it over every text of the catalog.

## Token exchange

`papaia_kit.exchange` is the only builder of token exchange requests: RFC 8693
with `audience=<a>` and `scope=aud-<a>`, exactly one audience per token. A
received token is exchanged further only for audiences declared as `downstream`
(chain holder only), with the informational header `X-Papaia-Origin-Azp`.
Exchanged tokens are cached per `sub` and audience and never beyond their
lifetime; a refusal after revocation is `identity_revoked`, and modules call
`forget(sub)` on the lifecycle signal. The chain holder never exchanges a token
of its own. Client authentication is `private_key_jwt`, a client secret only as
a fallback. Details in `contract/exchange.md`.

## Releases and pinning

- Versions follow Semantic Versioning; tags are `vX.Y.Z`. Every release has a
  dated entry in [`CHANGELOG.md`](CHANGELOG.md).
- The Python package and the TypeScript package always carry the same version.
- One version always means the same bytes: new content gets a new version,
  and a version is never rebuilt from another commit. The first release is
  0.1.0; there is no earlier release to install or upgrade from.
- Every consumer pins the kit by exact version **and** sha256 digest of the
  released artefact (wheel or source tarball). Without a package index the
  files are vendored under `vendor/papaia-kit/<version>/`, bound as a path
  source in `pyproject.toml` (`[tool.uv.sources]`) and listed in `kit.lock`
  with their sha256; `uv.lock` carries the same digest. Shape of `kit.lock`:
  [`release/kit.lock.example`](release/kit.lock.example). With an index the
  pin reads
  `papaia-kit @ https://<release host>/papaia_kit-0.1.0-py3-none-any.whl#sha256=<digest>`.
- Runtime dependencies take ranges so that consumers can apply security
  patches; `cryptography` has no upper bound, so no consumer needs an
  override for it.
- Images that contain the kit carry the label `de.fidonis.platform-kit=<version>`.

### Kit versions in one suite

Modules may carry different kit versions of one major version, but modules
that render kit UI only when no release between their versions changes how
existing markup renders. Every changelog entry that changes a variable's value
or the rendering of existing markup is marked `visual`, and the compatibility
matrix [`contract/versions.yaml`](contract/versions.yaml) lists every release
with that flag. A bill of materials names each module's kit version and
whether the module renders kit UI, in one of two forms:

- `papaia.kit-bom/1` ([`contract/kit-bom.schema.json`](contract/kit-bom.schema.json),
  example [`contract/examples/kit-bom.yaml`](contract/examples/kit-bom.yaml)):
  one entry per module with `name`, `kit` and `renders_ui`;
- the suite bill of materials `papaia.suite-bom/1` of the core, where each repo
  that vendors the kit carries `kit: {version, renders_ui}`
  ([`contract/suite-bom-kit.schema.json`](contract/suite-bom-kit.schema.json),
  field definition `$defs/module_kit`, excerpt
  [`contract/examples/suite-bom-kit.yaml`](contract/examples/suite-bom-kit.yaml)).
  Only `schema`, `repos[].name` and `repos[].kit` are read; the signature and
  every other field are checked by the core.

```sh
pk-check bom suite-kit.yaml      # same as: papaia-kit bom check suite-kit.yaml
pk-check bom suite-1.10.0.yaml   # the kit versions of a suite bill of materials
```

Rules:

- every module (contract rule): a version the matrix knows (check with the
  newest kit of the suite) and the same major version as the others;
- modules that render kit UI (visual rule): no `visual` release after the
  lower and up to the higher of two versions.

`renders_ui: false` marks a module without kit UI (core tools, connections,
MCP servers); it only lowers the visual rule, never the contract rule. A module
without the field renders kit UI. A refusal names the modules and the version
to move them to: the newest version among the modules that render kit UI.
Today the matrix holds one release, 0.1.0 (not visual: the first release has
nothing to differ from), so every module of a suite vendors 0.1.0; any other
version is refused by the contract rule. Exit 0 allowed, 1 refused or
malformed, 2 file not readable or larger than 1 MiB. A release cut adds its
row to the matrix; `tests/test_bom.py` keeps the rows equal to the changelog.

### Building a release

The reference images are an input of the build: after the release commit is
tagged, run `make refimg TAG=v0.1.0` on a checkout of the tag in the pinned
Playwright container of each platform (`linux-amd64`, `linux-arm64`) and
collect both platform folders in one `refimg/` folder. Then:

```sh
make release-dry-run TAG=v0.1.0 REGISTRY=/abs/path/to/registry REFIMG=/abs/path/to/refimg
make release TAG=v0.1.0 REGISTRY=/abs/path/to/registry REFIMG=/abs/path/to/refimg
make release-verify TAG=v0.1.0 REGISTRY=/abs/path/to/registry
```

`release/kit_release.py` exports exactly the tagged commit (`git archive`, not
the work tree), checks that the tag, `py/papaia_kit/__init__.py`,
`js/package.json` and `CHANGELOG.md` agree on the version, and builds wheel and
source tarball with `uv build --offline` and `SOURCE_DATE_EPOCH` set to the
commit time. The build backend and its dependencies are pinned with sha256 in
`release/build-constraints.txt` (`--require-hashes`); `make release-backend`
(part of `make bootstrap` and of the release targets) fetches them into the uv
cache beforehand, so the build itself fetches nothing. The tool packs the npm
package itself (`package/` with `package.json`, the folders of its `files`,
`LICENSE` and `THIRD_PARTY_LICENSES.md`, as `npm pack` lays it out) and the reference images
(`refimg/<playwright>/<platform>/...`). It takes the images only as exactly
the set that `js/src/conform/refimg.ts` of the tag names for the Playwright
version of the tag and both platforms, PNG files only, no symlinks; anything
else exits 2. Both archives have sorted entries, the commit time, owner 0 and
mode 0644, so the same input gives the same bytes. The result goes to:

```text
<registry>/papaia-kit/<version>/papaia_kit-<version>-py3-none-any.whl
<registry>/papaia-kit/<version>/papaia_kit-<version>.tar.gz
<registry>/papaia-kit/<version>/papaia-kit-<version>.tgz
<registry>/papaia-kit/<version>/papaia-kit-refimg-<version>.tar.gz
<registry>/papaia-kit/<version>/SHA256SUMS
<registry>/papaia-kit/<version>/kit.lock
```

The registry is a plain directory outside the repository (usable as
`--find-links`); its folder holds the files of the release page. A version
already there is never replaced: an identical rebuild changes nothing, other
content is refused (exit 1). `release-dry-run` builds and lists the same set
with its sha256 and `kit.lock` and writes nothing. `release-verify` checks the
files against `SHA256SUMS`, rebuilds wheel, source tarball and npm package from
the tag, checks that the image archive holds exactly the set of the tag packed
the same way, and fails (exit 1) when any digest differs. Invalid input (tag
not `vX.Y.Z`, unknown tag, relative path, registry inside the repository,
symlinked registry folder, incomplete or foreign image set) exits 2 before
anything is written.

## License

MIT, see [LICENSE](LICENSE). Third-party components are listed in
`THIRD_PARTY_LICENSES.md`. Name and logo: [TRADEMARK.md](TRADEMARK.md).

See [CONTRIBUTING.md](CONTRIBUTING.md) for the pull request workflow and
[SECURITY.md](SECURITY.md) for reporting a vulnerability.
