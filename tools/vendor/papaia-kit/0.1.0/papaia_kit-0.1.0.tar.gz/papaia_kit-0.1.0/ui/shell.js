/*
 * Progressive enhancement of the shell (contract/shell/shell.md).
 * No dependencies, no inline script, no stored state. Without this file the
 * shell stays usable: <details> menus, the #pk-sidebar drawer link and plain
 * form posts.
 */
(function () {
  "use strict";

  var DRAWER_QUERY = "(max-width: 1023.98px)";

  function menus() {
    return Array.prototype.slice.call(
      document.querySelectorAll("details.pk-switcher, details.pk-account, details.pk-menu")
    );
  }

  function links(details) {
    return Array.prototype.slice.call(
      details.querySelectorAll(":scope > ul a, :scope > ul button, :scope > ul summary")
    ).filter(function (el) {
      return el.offsetParent !== null;
    });
  }

  function closeMenu(details, returnFocus) {
    if (!details.open) {
      return;
    }
    details.open = false;
    if (returnFocus) {
      details.querySelector(":scope > summary").focus();
    }
  }

  /* Escape closes, arrow keys move, focus returns to the summary (APG disclosure navigation).
   * The same for the actions menus "Weitere Aktionen" (details.pk-menu) in the page header,
   * in table rows and in lists; without this file they open and close as plain details. */
  function enhanceMenu(details) {
    details.addEventListener("keydown", function (event) {
      var items = links(details);
      var index = items.indexOf(document.activeElement);
      if (event.key === "Escape" && details.open) {
        var inner = document.activeElement && document.activeElement.closest("details");
        if (inner && inner !== details && inner.open) {
          closeMenu(inner, true);
        } else {
          closeMenu(details, true);
        }
        event.preventDefault();
        event.stopPropagation();
      } else if ((event.key === "ArrowDown" || event.key === "ArrowUp") && details.open) {
        if (items.length === 0) {
          return;
        }
        var step = event.key === "ArrowDown" ? 1 : -1;
        var next = index < 0 ? 0 : (index + step + items.length) % items.length;
        items[next].focus();
        event.preventDefault();
      } else if ((event.key === "Home" || event.key === "End") && index >= 0) {
        items[event.key === "Home" ? 0 : items.length - 1].focus();
        event.preventDefault();
      }
    });
    details.addEventListener("focusout", function (event) {
      if (event.relatedTarget && !details.contains(event.relatedTarget)) {
        closeMenu(details, false);
      }
    });
  }

  document.addEventListener("click", function (event) {
    menus().forEach(function (details) {
      if (details.open && !details.contains(event.target)) {
        closeMenu(details, false);
      }
    });
  });

  /* Drawer below 1024px: modal, focus kept inside, rest inert, no history entry. */
  function enhanceDrawer(shell) {
    var button = document.querySelector(".pk-menu-button");
    var sidebar = document.getElementById("pk-sidebar");
    var closer = sidebar && sidebar.querySelector(".pk-drawer-close");
    if (!button || !sidebar) {
      return;
    }
    var outside = Array.prototype.slice.call(
      document.querySelectorAll(".pk-content, .pk-skip")
    );
    button.setAttribute("role", "button");
    button.setAttribute("aria-expanded", "false");

    function setOpen(open) {
      shell.setAttribute("data-pk-drawer", open ? "open" : "closed");
      button.setAttribute("aria-expanded", open ? "true" : "false");
      outside.forEach(function (el) {
        el.inert = open;
      });
      if (open) {
        var first = sidebar.querySelector("a, button, summary");
        if (first) {
          first.focus();
        }
      } else {
        button.focus();
      }
    }

    button.addEventListener("click", function (event) {
      event.preventDefault();
      setOpen(shell.getAttribute("data-pk-drawer") !== "open");
    });
    button.addEventListener("keydown", function (event) {
      if (event.key === " ") {
        event.preventDefault();
        setOpen(shell.getAttribute("data-pk-drawer") !== "open");
      }
    });
    if (closer) {
      closer.setAttribute("role", "button");
      closer.addEventListener("click", function (event) {
        event.preventDefault();
        setOpen(false);
      });
    }
    sidebar.addEventListener("keydown", function (event) {
      if (shell.getAttribute("data-pk-drawer") !== "open") {
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        setOpen(false);
        return;
      }
      if (event.key !== "Tab") {
        return;
      }
      var focusable = Array.prototype.slice.call(
        sidebar.querySelectorAll("a, button, summary")
      ).filter(function (el) {
        return el.offsetParent !== null;
      });
      if (focusable.length === 0) {
        return;
      }
      var first = focusable[0];
      var last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        last.focus();
        event.preventDefault();
      } else if (!event.shiftKey && document.activeElement === last) {
        first.focus();
        event.preventDefault();
      }
    });
    if (window.matchMedia) {
      window.matchMedia(DRAWER_QUERY).addEventListener("change", function (query) {
        if (!query.matches && shell.getAttribute("data-pk-drawer") === "open") {
          shell.setAttribute("data-pk-drawer", "closed");
          button.setAttribute("aria-expanded", "false");
          outside.forEach(function (el) {
            el.inert = false;
          });
        }
      });
    }
  }

  /* Appearance switch (footer form POST /_kit/appearance). Its label names the action: the
   * appearance it turns on, never the one that shows. With a stored choice (data-theme) the
   * server renders it; while the person follows the system setting the shown appearance is
   * prefers-color-scheme, read on load and on every change. Whatever sets data-theme later
   * (theme-sync.js, a console) is followed too. The labels come from the button
   * (data-pk-label-dark, data-pk-label-light); nothing is stored. Without this file the
   * server's label stays and the form posts as before. */
  var SCHEME_QUERY = "(prefers-color-scheme: dark)";

  function shownAppearance() {
    var theme = document.documentElement.getAttribute("data-theme");
    if (theme === "light" || theme === "dark") {
      return theme;
    }
    return window.matchMedia && window.matchMedia(SCHEME_QUERY).matches ? "dark" : "light";
  }

  function syncAppearance() {
    var offer = shownAppearance() === "dark" ? "light" : "dark";
    var buttons = document.querySelectorAll('form[action="/_kit/appearance"] button[name="appearance"]');
    Array.prototype.forEach.call(buttons, function (button) {
      var text = button.getAttribute("data-pk-label-" + offer);
      var label = button.querySelector(".pk-label");
      if (!text || !label) {
        return;
      }
      if (button.getAttribute("value") !== offer) {
        button.setAttribute("value", offer);
      }
      if (label.textContent !== text) {
        label.textContent = text;
      }
      var use = button.querySelector("use");
      var href = use && use.getAttribute("href");
      if (href && href.indexOf("#") >= 0) {
        var icon = href.slice(0, href.indexOf("#") + 1) + "pk-icon-" + (offer === "light" ? "sun" : "moon");
        if (icon !== href) {
          use.setAttribute("href", icon);
        }
      }
    });
  }

  function enhanceAppearance() {
    syncAppearance();
    if (window.matchMedia) {
      var query = window.matchMedia(SCHEME_QUERY);
      if (query.addEventListener) {
        query.addEventListener("change", syncAppearance);
      }
    }
    if (window.MutationObserver) {
      new window.MutationObserver(syncAppearance).observe(document.documentElement, {
        attributes: true,
        attributeFilter: ["data-theme"]
      });
    }
  }

  /* Height of the sticky page header for scroll padding and the toast position. */
  function trackHeader() {
    var header = document.querySelector(".pk-page-header");
    if (!header || !window.ResizeObserver) {
      return;
    }
    new window.ResizeObserver(function () {
      document.documentElement.style.setProperty(
        "--pk-page-header-height",
        header.getBoundingClientRect().height + "px"
      );
    }).observe(header);
  }

  /* Route change inside a React console: title, h1, active nav row, focus and announcement. */
  function update(state) {
    var h1 = document.querySelector(".pk-page-header h1");
    if (state && typeof state.title === "string" && h1) {
      h1.textContent = state.title;
      var parts = document.title.split(" – ");
      if (parts.length >= 3) {
        parts.splice(0, parts.length - 2, state.title);
        document.title = parts.join(" – ");
      }
    }
    if (state && typeof state.navCurrent === "string") {
      var rows = document.querySelectorAll('[data-pk-zone="nav"] a');
      Array.prototype.forEach.call(rows, function (row) {
        if (row.getAttribute("href") === state.navCurrent) {
          row.setAttribute("aria-current", "page");
        } else {
          row.removeAttribute("aria-current");
        }
      });
    }
    if (h1 && (!state || state.focus !== false)) {
      h1.setAttribute("tabindex", "-1");
      h1.focus();
      var status = document.querySelector('#pk-toasts [role="status"]');
      if (status && state && typeof state.title === "string") {
        status.textContent = state.title;
      }
    }
  }

  /* Close button of a toast or inline alert (data-pk-dismiss): the message leaves in
   * --pk-duration-base, at once under reduced motion; focus moves to the main content
   * when it was inside the message. */
  function dismiss(event) {
    var button = event.target.closest && event.target.closest("[data-pk-dismiss]");
    var message = button && button.closest(".pk-toast, .pk-alert");
    if (!message || message.hasAttribute("data-pk-leaving")) {
      return;
    }
    var still = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (message.contains(document.activeElement)) {
      var main = document.getElementById("pk-main");
      if (main) {
        main.focus();
      }
    }
    message.setAttribute("data-pk-leaving", "");
    if (still || !message.classList.contains("pk-toast")) {
      message.remove();
      return;
    }
    var done = function () {
      message.remove();
    };
    message.addEventListener("transitionend", done, { once: true });
    window.setTimeout(done, 400);
  }

  function start() {
    document.addEventListener("click", dismiss);
    menus().forEach(enhanceMenu);
    var shell = document.querySelector(".pk-shell");
    if (shell) {
      enhanceDrawer(shell);
    }
    trackHeader();
    enhanceAppearance();
  }

  window.pkShell = { update: update };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
