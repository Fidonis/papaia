# Kit test issuer

A minimal OIDC token issuer for CI test stacks: the server suite
(`papaia-kit conformance server`) gets its tokens here, and the server under
test trusts it in place of the identity provider. **CI only.** Anyone who can
reach the token endpoint gets any token, so the issuer runs only in a
disposable test stack, bound to loopback or an internal network. No product
image contains it or a switch to trust it.

| Endpoint | Answer |
|---|---|
| `GET /.well-known/openid-configuration` | `issuer`, `jwks_uri`, `token_endpoint` |
| `GET /jwks` | the public RSA key (`RS256`) |
| `POST /token` | `application/json` request, answer `{access_token, token_type, expires_in}` |

Token request (at most 4 KiB, unknown fields refused, status 400 with
`{"error": ...}` naming the field, never its value):

| Field | Rule |
|---|---|
| `sub` | required, 1 to 128 characters `[A-Za-z0-9._:@\|+-]` |
| `azp` | required, a client name (`[a-z][a-z0-9-]*`, at most 63) |
| `aud` | required, one name or a list of 1 to 4 distinct names |
| `roles` | optional list of at most 16 distinct names |
| `kind` | `person` (default: adds `sid`, `person_id` and `auth_time`) or `service` |
| `lifetime` | seconds, 1 to 3600, default 300 |
| `auth_age` | persons only: seconds, 0 to 86400, default 0; `auth_time` is `iat` minus this value (a sign-in that is no longer fresh, for the `me-v2` suite) |
| `preferred_username` | persons only (refused for `service`): 1 to 128 characters `[A-Za-z0-9._:@\|+-]`, the rule of `sub`; becomes the claim `preferred_username`. Without the field the token has no such claim |

The tokens carry `iss`, `sub`, `azp`, `aud`, `iat`, `exp`, `typ: Bearer`,
`roles`, `jti` and, for persons, `sid`, `person_id`, `auth_time` and, when
requested, `preferred_username`, like the access tokens of the platform realm,
so they pass the kit check chain (`papaia_kit.authz`) of a server configured
with this issuer. The signing key is generated at start, held in memory only
and lost on exit; restart the issuer and the server under test together.

## Container

```sh
docker build -t papaia-kit-test-issuer:0.1.0 testing/issuer
docker run --rm -p 127.0.0.1:8080:8080 papaia-kit-test-issuer:0.1.0 \
  --issuer https://issuer.kit.test/realms/papaia --public-url http://issuer:8080
```

The image pins its base image by digest and installs `pyjwt` and
`cryptography` from `requirements.txt` with hashes (the versions of the kit's
`uv.lock`). It runs as an unprivileged user. Inside the container it listens on
`0.0.0.0:8080`; publish the port on `127.0.0.1` only. `--issuer` is the `iss`
claim (an `https` URL; the server under test compares it exactly) and
`--public-url` the base URL under which the server under test fetches
`/jwks`. `--public-url` is mandatory for the container: the issuer refuses to
start without it whenever it binds a non-loopback address, because it would
otherwise advertise the unusable `http://0.0.0.0:8080` as `jwks_uri` and
`token_endpoint`.

CI builds the image (so the digest and hash pins are exercised) and lints the
`Dockerfile` with hadolint (job `issuer-image`).

Without a container: `python testing/issuer/issuer.py --port 8080` (binds
`127.0.0.1` and advertises that address).
